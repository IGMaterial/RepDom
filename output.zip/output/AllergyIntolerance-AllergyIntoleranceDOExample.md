# Ejemplo de AllergyIntoleranceDO - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Ejemplo de AllergyIntoleranceDO**

## Example AllergyIntolerance: Ejemplo de AllergyIntoleranceDO

Perfil: [Alergia o Intolerancia DO](StructureDefinition-AllergyIntoleranceDO.md)

**clinicalStatus**: active

**verificationStatus**: confirmed

**type**: Allergy

**category**: Food

**criticality**: High Risk

**code**: Penicillic acid

**patient**: `PatientDO/PatientDOExample`

**onset**: 2026-08-10

**recordedDate**: 2026-08-10

**recorder**: `PractitionerDO/PractitionerDOExample`



## Resource Content

```json
{
  "resourceType" : "AllergyIntolerance",
  "id" : "AllergyIntoleranceDOExample",
  "meta" : {
    "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/AllergyIntoleranceDO"]
  },
  "clinicalStatus" : {
    "coding" : [{
      "code" : "active"
    }]
  },
  "verificationStatus" : {
    "coding" : [{
      "code" : "confirmed"
    }]
  },
  "type" : "allergy",
  "category" : ["food"],
  "criticality" : "high",
  "code" : {
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "code" : "3145006",
      "display" : "Penicillic acid"
    }]
  },
  "patient" : {
    "reference" : "PatientDO/PatientDOExample"
  },
  "onsetDateTime" : "2026-08-10",
  "recordedDate" : "2026-08-10",
  "recorder" : {
    "reference" : "PractitionerDO/PractitionerDOExample"
  }
}

```
