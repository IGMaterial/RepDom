# Metadatos del PDF de laboratorio - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Metadatos del PDF de laboratorio**

## Example Binary: Metadatos del PDF de laboratorio

[The Content Type 'application/pdf' is not rendered in this context]



## Resource Binary Content

application/pdf:

```
{snip}
```
