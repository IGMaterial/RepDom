# Ejemplo de BundleNPSDO - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Ejemplo de BundleNPSDO**

## Example Bundle: Ejemplo de BundleNPSDO



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "BundleNPSDOExample",
  "meta" : {
    "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/BundleNPSDO"]
  },
  "identifier" : {
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:uuid:bundle-nps-do-example"
  },
  "type" : "document",
  "timestamp" : "2026-08-19T10:30:00Z",
  "entry" : [{
    "fullUrl" : "urn:uuid:CompositionDOExample",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "CompositionDOExample",
      "meta" : {
        "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/CompositionDO"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Composition_CompositionDOExample\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composición CompositionDOExample</b></p><a name=\"CompositionDOExample\"> </a><a name=\"hcCompositionDOExample\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-CompositionDO.html\">Documento Clínico DO</a></p></div><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{http://loinc.org 60591-5}\">Patient summary Document</span></p><p><b>date</b>: 2026-08-19</p><p><b>author</b>: <code>PractitionerDO/PractitionerDOExample</code></p><p><b>title</b>: Resumen clínico del paciente</p><p><b>custodian</b>: <code>OrganizationDO/OrganizationDOExample</code></p></div>"
      },
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "60591-5",
          "display" : "Patient summary Document"
        }]
      },
      "subject" : {
        "reference" : "PatientDO/PatientDOExample"
      },
      "date" : "2026-08-19",
      "author" : [{
        "reference" : "PractitionerDO/PractitionerDOExample"
      }],
      "title" : "Resumen clínico del paciente",
      "custodian" : {
        "reference" : "OrganizationDO/OrganizationDOExample"
      },
      "section" : [{
        "title" : "Condiciones del Paciente",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "11450-4",
            "display" : "Problem list Reported"
          }]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">CONDICIONES</div>"
        },
        "entry" : [{
          "reference" : "Condition/ConditionDOEjemplo"
        }]
      },
      {
        "title" : "Medicamentos",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "10160-0",
            "display" : "Hx of Medication use"
          }]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">MEDICAMENTOS</div>"
        },
        "entry" : [{
          "reference" : "MedicationStatement/MedicationStatementDOEjemplo"
        }]
      },
      {
        "title" : "Alergias",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "48765-2",
            "display" : "Allergies and adverse reactions Document."
          }]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">ALERGIAS</div>"
        },
        "entry" : [{
          "reference" : "AllergyIntolerance/AllergyIntoleranceDOExample"
        }]
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:PatientDOExample",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "PatientDOExample",
      "meta" : {
        "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/PatientDO"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_PatientDOExample\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Paciente PatientDOExample</b></p><a name=\"PatientDOExample\"> </a><a name=\"hcPatientDOExample\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-PatientDO.html\">Paciente DO</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">María Pérez  Female, DoB: 1990-05-15 ( Cédula: 00000000000)</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Ways to contact the Patient\">Contact Detail</td><td colspan=\"3\"><ul><li><a href=\"tel:+1-809-555-6789\">+1-809-555-6789</a></li><li><a href=\"mailto:maria.perez@example.do\">maria.perez@example.do</a></li><li>Calle Principal 456 Santo Domingo Distrito Nacional 10102 DO </li></ul></td></tr></table></div>"
      },
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSIdentificadoresPersona",
            "code" : "CED"
          }]
        },
        "system" : "https://digital.msp.gob.do/fhir/sid/cedula",
        "value" : "00000000000"
      }],
      "name" : [{
        "extension" : [{
          "url" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/SegundoApellidoDO",
          "valueString" : "Gómez"
        }],
        "family" : "Pérez",
        "given" : ["María"]
      }],
      "telecom" : [{
        "system" : "phone",
        "value" : "+1-809-555-6789"
      },
      {
        "system" : "email",
        "value" : "maria.perez@example.do"
      }],
      "gender" : "female",
      "birthDate" : "1990-05-15",
      "address" : [{
        "line" : ["Calle Principal 456"],
        "city" : "Santo Domingo",
        "state" : "Distrito Nacional",
        "postalCode" : "10102",
        "country" : "DO"
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:OrganizationDOExample",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "OrganizationDOExample",
      "meta" : {
        "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/OrganizationDO"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_OrganizationDOExample\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organización OrganizationDOExample</b></p><a name=\"OrganizationDOExample\"> </a><a name=\"hcOrganizationDOExample\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-OrganizationDO.html\">Organización DO</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Centro de Salud DO Ejemplo (Healthcare Provider) (https://digital.msp.gob.do/identifiers/organization#ORG-001)</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Record is active\">Active:</td><td colspan=\"3\">true</td></tr><tr><td style=\"background-color: #f3f5da\" title=\"The kind(s) of organization that this is\">Type:</td><td colspan=\"3\"><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/organization-type prov}\">Healthcare Provider</span></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Ways to contact the organization\">Contact Detail</td><td colspan=\"3\"><ul><li><a href=\"tel:+1-809-555-1234\">+1-809-555-1234</a></li><li><a href=\"mailto:contacto@centrosaluddo.do\">contacto@centrosaluddo.do</a></li><li>Av. Principal 123 Santo Domingo Distrito Nacional 10101 DO </li></ul></td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "https://digital.msp.gob.do/identifiers/organization",
        "value" : "ORG-001"
      }],
      "active" : true,
      "type" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/organization-type",
          "code" : "prov",
          "display" : "Healthcare Provider"
        }]
      }],
      "name" : "Centro de Salud DO Ejemplo",
      "telecom" : [{
        "system" : "phone",
        "value" : "+1-809-555-1234"
      },
      {
        "system" : "email",
        "value" : "contacto@centrosaluddo.do"
      }],
      "address" : [{
        "line" : ["Av. Principal 123"],
        "city" : "Santo Domingo",
        "state" : "Distrito Nacional",
        "postalCode" : "10101",
        "country" : "DO"
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:PractitionerDOExample",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "PractitionerDOExample",
      "meta" : {
        "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/PractitionerDO"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Practitioner_PractitionerDOExample\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Practicante / Profesional PractitionerDOExample</b></p><a name=\"PractitionerDOExample\"> </a><a name=\"hcPractitionerDOExample\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-PractitionerDO.html\">Profesional DO</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Laura Rodríguez (PRN: PROF-0001)</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Ways to contact the Practitioner\">Contact Detail</td><td colspan=\"3\"><ul><li><a href=\"tel:+1-809-555-9012\">+1-809-555-9012</a></li><li><a href=\"mailto:laura.rodriguez@example.do\">laura.rodriguez@example.do</a></li><li>Calle Salud 789 Santiago Santiago 51000 DO </li></ul></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Certification, licensure, or training pertaining to the provision of care\">Qualification:</td><td colspan=\"3\"><span title=\"Codes:{https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSEspecialidadesMedicas MG}\">Medicina general</span></td></tr></table></div>"
      },
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSIdentificadoresPersona",
            "code" : "PRN"
          }]
        },
        "value" : "PROF-0001"
      }],
      "name" : [{
        "extension" : [{
          "url" : "http://digital.msp.gob.do/fhir/StructureDefinition/SegundoApellidoDO",
          "valueString" : "Martínez"
        }],
        "family" : "Rodríguez",
        "given" : ["Laura"]
      }],
      "telecom" : [{
        "system" : "phone",
        "value" : "+1-809-555-9012"
      },
      {
        "system" : "email",
        "value" : "laura.rodriguez@example.do"
      }],
      "address" : [{
        "line" : ["Calle Salud 789"],
        "city" : "Santiago",
        "state" : "Santiago",
        "postalCode" : "51000",
        "country" : "DO"
      }],
      "qualification" : [{
        "code" : {
          "coding" : [{
            "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSEspecialidadesMedicas",
            "code" : "MG",
            "display" : "Medicina general"
          }]
        }
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:ConditionDOEjemplo",
    "resource" : {
      "resourceType" : "Condition",
      "id" : "ConditionDOEjemplo",
      "meta" : {
        "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/ConditionDO"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Condition_ConditionDOEjemplo\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Condición ConditionDOEjemplo</b></p><a name=\"ConditionDOEjemplo\"> </a><a name=\"hcConditionDOEjemplo\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-ConditionDO.html\">Condición DO</a></p></div><p><b>clinicalStatus</b>: <span title=\"Codes:\">active</span></p><p><b>verificationStatus</b>: <span title=\"Codes:\">confirmed</span></p><p><b>severity</b>: <span title=\"Codes:{http://snomed.info/sct 6736007}\">Moderate</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 404684003}\">Clinical finding</span></p><p><b>subject</b>: <code>PatientDO/PatientDOExample</code></p><p><b>onset</b>: 2026-08-10</p><p><b>recordedDate</b>: 2026-08-10</p><p><b>recorder</b>: <code>PractitionerDO/PractitionerDOExample</code></p><p><b>note</b>: </p><blockquote><div><p>Paciente con diagnóstico registrado en consulta.</p>\n</div></blockquote></div>"
      },
      "clinicalStatus" : {
        "coding" : [{
          "code" : "active"
        }]
      },
      "verificationStatus" : {
        "coding" : [{
          "code" : "confirmed"
        }]
      },
      "severity" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "6736007",
          "display" : "Moderate"
        }]
      },
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "404684003",
          "display" : "Clinical finding"
        }]
      },
      "subject" : {
        "reference" : "PatientDO/PatientDOExample"
      },
      "onsetDateTime" : "2026-08-10",
      "recordedDate" : "2026-08-10",
      "recorder" : {
        "reference" : "PractitionerDO/PractitionerDOExample"
      },
      "note" : [{
        "text" : "Paciente con diagnóstico registrado en consulta."
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:AllergyIntoleranceDOExample",
    "resource" : {
      "resourceType" : "AllergyIntolerance",
      "id" : "AllergyIntoleranceDOExample",
      "meta" : {
        "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/AllergyIntoleranceDO"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"AllergyIntolerance_AllergyIntoleranceDOExample\"> </a><p class=\"res-header-id\"><b>Generated Narrative: AllergiaIntolerancia AllergyIntoleranceDOExample</b></p><a name=\"AllergyIntoleranceDOExample\"> </a><a name=\"hcAllergyIntoleranceDOExample\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-AllergyIntoleranceDO.html\">Alergia o Intolerancia DO</a></p></div><p><b>clinicalStatus</b>: <span title=\"Codes:\">active</span></p><p><b>verificationStatus</b>: <span title=\"Codes:\">confirmed</span></p><p><b>type</b>: Allergy</p><p><b>category</b>: Food</p><p><b>criticality</b>: High Risk</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 3145006}\">Penicillic acid</span></p><p><b>patient</b>: <code>PatientDO/PatientDOExample</code></p><p><b>onset</b>: 2026-08-10</p><p><b>recordedDate</b>: 2026-08-10</p><p><b>recorder</b>: <code>PractitionerDO/PractitionerDOExample</code></p></div>"
      },
      "clinicalStatus" : {
        "coding" : [{
          "code" : "active"
        }]
      },
      "verificationStatus" : {
        "coding" : [{
          "code" : "confirmed"
        }]
      },
      "type" : "allergy",
      "category" : ["food"],
      "criticality" : "high",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "3145006",
          "display" : "Penicillic acid"
        }]
      },
      "patient" : {
        "reference" : "PatientDO/PatientDOExample"
      },
      "onsetDateTime" : "2026-08-10",
      "recordedDate" : "2026-08-10",
      "recorder" : {
        "reference" : "PractitionerDO/PractitionerDOExample"
      }
    }
  }]
}

```
