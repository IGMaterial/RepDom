# Bundle de notificación de caso de dengue - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Bundle de notificación de caso de dengue**

## Example Bundle: Bundle de notificación de caso de dengue



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "BundleNotifDOExample",
  "meta" : {
    "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/BundleNotifDO"]
  },
  "identifier" : {
    "system" : "https://example.org/identifiers/notificaciones",
    "value" : "DENGUE-2026-0001"
  },
  "type" : "document",
  "timestamp" : "2026-10-26T10:00:00-04:00",
  "entry" : [{
    "fullUrl" : "urn:uuid:composition-notif-dengue-example",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "CompositionDONotifExample",
      "meta" : {
        "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/CompositionDONotif"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Composition_CompositionDONotifExample\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composición CompositionDONotifExample</b></p><a name=\"CompositionDONotifExample\"> </a><a name=\"hcCompositionDONotifExample\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-CompositionDONotif.html\">Documento Clínico Notificación de Caso</a></p></div><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{http://loinc.org 68991-9}\">Case notification panel</span></p><p><b>date</b>: 2026-10-26 10:00:00-0400</p><p><b>author</b>: <a href=\"Organization-OrganizationDOExample.html\">Centro de Salud DO Ejemplo (Healthcare Provider) (https://digital.msp.gob.do/identifiers/organization#ORG-001)</a></p><p><b>title</b>: Notificación individual de caso confirmado de dengue</p><p><b>custodian</b>: <a href=\"Organization-OrganizationDOExample.html\">Centro de Salud DO Ejemplo (Healthcare Provider) (https://digital.msp.gob.do/identifiers/organization#ORG-001)</a></p></div>"
      },
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "68991-9",
          "display" : "Case notification panel"
        }]
      },
      "subject" : {
        "reference" : "Patient/PatientDOExample"
      },
      "date" : "2026-10-26T10:00:00-04:00",
      "author" : [{
        "reference" : "Organization/OrganizationDOExample"
      }],
      "title" : "Notificación individual de caso confirmado de dengue",
      "custodian" : {
        "reference" : "Organization/OrganizationDOExample"
      },
      "section" : [{
        "title" : "Datos de la enfermedad",
        "code" : {
          "coding" : [{
            "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSSeccionesNotificacionDO",
            "code" : "evento"
          }]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">Caso confirmado de dengue.</div>"
        },
        "entry" : [{
          "reference" : "Condition/ConditionCasoEpidemiologicoDOExample"
        }]
      },
      {
        "title" : "Signos y síntomas",
        "code" : {
          "coding" : [{
            "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSSeccionesNotificacionDO",
            "code" : "observaciones"
          }]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">Fiebre y cefalea de inicio reciente.</div>"
        },
        "entry" : [{
          "reference" : "Observation/ObservationSignoSintomaDOExample"
        }]
      },
      {
        "title" : "Estado de embarazo",
        "code" : {
          "coding" : [{
            "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSSeccionesNotificacionDO",
            "code" : "observaciones"
          }]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">Embarazo de 18 semanas.</div>"
        },
        "entry" : [{
          "reference" : "Observation/ObservationEstadoEmbarazoDOExample"
        }]
      },
      {
        "title" : "Viajes y exposición",
        "code" : {
          "coding" : [{
            "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSSeccionesNotificacionDO",
            "code" : "observaciones"
          }]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">Antecedente de viaje y exposición a picaduras de mosquitos.</div>"
        },
        "entry" : [{
          "reference" : "Observation/ObservationViajesExposicionDOExample"
        }]
      },
      {
        "title" : "Conclusión epidemiológica",
        "code" : {
          "coding" : [{
            "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSSeccionesNotificacionDO",
            "code" : "conclusion"
          }]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">Caso confirmado de dengue.</div>"
        },
        "entry" : [{
          "reference" : "Condition/ConditionConclusionDOExample"
        }]
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:patient-do-example",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "PatientDOExample",
      "meta" : {
        "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/PatientDO"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_PatientDOExample\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Paciente PatientDOExample</b></p><a name=\"PatientDOExample\"> </a><a name=\"hcPatientDOExample\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-PatientDO.html\">Paciente DO</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">María Pérez  Female, DoB: 1990-05-15 ( Cédula: 00000000000)</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Ways to contact the Patient\">Contact Detail</td><td colspan=\"3\"><ul><li><a href=\"tel:+1-809-555-6789\">+1-809-555-6789</a></li><li><a href=\"mailto:maria.perez@example.do\">maria.perez@example.do</a></li><li>Calle Principal 456 Santo Domingo Distrito Nacional 10102 DO </li></ul></td></tr></table></div>"
      },
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSIdentificadoresPersona",
            "code" : "CED"
          }]
        },
        "system" : "https://digital.msp.gob.do/fhir/sid/cedula",
        "value" : "00000000000"
      }],
      "name" : [{
        "extension" : [{
          "url" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/SegundoApellidoDO",
          "valueString" : "Gómez"
        }],
        "family" : "Pérez",
        "given" : ["María"]
      }],
      "telecom" : [{
        "system" : "phone",
        "value" : "+1-809-555-6789"
      },
      {
        "system" : "email",
        "value" : "maria.perez@example.do"
      }],
      "gender" : "female",
      "birthDate" : "1990-05-15",
      "address" : [{
        "line" : ["Calle Principal 456"],
        "city" : "Santo Domingo",
        "state" : "Distrito Nacional",
        "postalCode" : "10102",
        "country" : "DO"
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:organization-do-example",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "OrganizationDOExample",
      "meta" : {
        "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/OrganizationDO"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_OrganizationDOExample\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organización OrganizationDOExample</b></p><a name=\"OrganizationDOExample\"> </a><a name=\"hcOrganizationDOExample\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-OrganizationDO.html\">Organización DO</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Centro de Salud DO Ejemplo (Healthcare Provider) (https://digital.msp.gob.do/identifiers/organization#ORG-001)</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Record is active\">Active:</td><td colspan=\"3\">true</td></tr><tr><td style=\"background-color: #f3f5da\" title=\"The kind(s) of organization that this is\">Type:</td><td colspan=\"3\"><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/organization-type prov}\">Healthcare Provider</span></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Ways to contact the organization\">Contact Detail</td><td colspan=\"3\"><ul><li><a href=\"tel:+1-809-555-1234\">+1-809-555-1234</a></li><li><a href=\"mailto:contacto@centrosaluddo.do\">contacto@centrosaluddo.do</a></li><li>Av. Principal 123 Santo Domingo Distrito Nacional 10101 DO </li></ul></td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "https://digital.msp.gob.do/identifiers/organization",
        "value" : "ORG-001"
      }],
      "active" : true,
      "type" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/organization-type",
          "code" : "prov",
          "display" : "Healthcare Provider"
        }]
      }],
      "name" : "Centro de Salud DO Ejemplo",
      "telecom" : [{
        "system" : "phone",
        "value" : "+1-809-555-1234"
      },
      {
        "system" : "email",
        "value" : "contacto@centrosaluddo.do"
      }],
      "address" : [{
        "line" : ["Av. Principal 123"],
        "city" : "Santo Domingo",
        "state" : "Distrito Nacional",
        "postalCode" : "10101",
        "country" : "DO"
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:case-dengue-example",
    "resource" : {
      "resourceType" : "Condition",
      "id" : "ConditionCasoEpidemiologicoDOExample",
      "meta" : {
        "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/ConditionCasoEpidemiologicoDO"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Condition_ConditionCasoEpidemiologicoDOExample\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Condición ConditionCasoEpidemiologicoDOExample</b></p><a name=\"ConditionCasoEpidemiologicoDOExample\"> </a><a name=\"hcConditionCasoEpidemiologicoDOExample\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-ConditionCasoEpidemiologicoDO.html\">Caso epidemiológico DO</a></p></div><p><b>clinicalStatus</b>: <span title=\"Codes:\">active</span></p><p><b>verificationStatus</b>: <span title=\"Codes:\">confirmed</span></p><p><b>category</b>: <span title=\"Codes:{https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSCategoriaNotificacionDO evento-epidemiologico}\">Evento epidemiológico</span></p><p><b>code</b>: <span title=\"Codes:{http://hl7.org/fhir/sid/icd-10 A90}\">Dengue</span></p><p><b>subject</b>: <a href=\"Patient-PatientDOExample.html\">María Pérez  Female, DoB: 1990-05-15 ( Cédula: 00000000000)</a></p><p><b>onset</b>: 2026-10-25</p><p><b>recordedDate</b>: 2026-10-26</p><blockquote><p><b>evidence</b></p><p><b>detail</b>: </p><ul><li><a href=\"Observation-ObservationSignoSintomaDOExample.html\">Observation Fever</a></li><li><a href=\"Observation-ObservationEstadoEmbarazoDOExample.html\">Observation Pregnancy status</a></li><li><a href=\"Observation-ObservationViajesExposicionDOExample.html\">Observation Travel history</a></li></ul></blockquote><p><b>note</b>: </p><blockquote><div><p>Caso sintético; datos utilizados únicamente con fines de ejemplo.</p>\n</div></blockquote></div>"
      },
      "clinicalStatus" : {
        "coding" : [{
          "code" : "active"
        }]
      },
      "verificationStatus" : {
        "coding" : [{
          "code" : "confirmed"
        }]
      },
      "category" : [{
        "coding" : [{
          "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSCategoriaNotificacionDO",
          "code" : "evento-epidemiologico"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/sid/icd-10",
          "code" : "A90",
          "display" : "Dengue"
        }]
      },
      "subject" : {
        "reference" : "Patient/PatientDOExample"
      },
      "onsetDateTime" : "2026-10-25",
      "recordedDate" : "2026-10-26",
      "evidence" : [{
        "detail" : [{
          "reference" : "Observation/ObservationSignoSintomaDOExample"
        },
        {
          "reference" : "Observation/ObservationEstadoEmbarazoDOExample"
        },
        {
          "reference" : "Observation/ObservationViajesExposicionDOExample"
        }]
      }],
      "note" : [{
        "text" : "Caso sintético; datos utilizados únicamente con fines de ejemplo."
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:observation-signs-dengue-example",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "ObservationSignoSintomaDOExample",
      "meta" : {
        "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/ObservationSignoSintomaDO"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_ObservationSignoSintomaDOExample\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observación ObservationSignoSintomaDOExample</b></p><a name=\"ObservationSignoSintomaDOExample\"> </a><a name=\"hcObservationSignoSintomaDOExample\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-ObservationSignoSintomaDO.html\">Signo o síntoma DO</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 386661006}\">Fever</span></p><p><b>subject</b>: <a href=\"Patient-PatientDOExample.html\">María Pérez  Female, DoB: 1990-05-15 ( Cédula: 00000000000)</a></p><p><b>effective</b>: 2026-10-25 08:00:00-0400</p><p><b>value</b>: <span title=\"Codes:{http://snomed.info/sct 52101004}\">Present</span></p><p><b>note</b>: </p><blockquote><div><p>La paciente refiere fiebre y cefalea de inicio reciente.</p>\n</div></blockquote></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "386661006",
          "display" : "Fever"
        }]
      },
      "subject" : {
        "reference" : "Patient/PatientDOExample"
      },
      "effectiveDateTime" : "2026-10-25T08:00:00-04:00",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "52101004",
          "display" : "Present"
        }]
      },
      "note" : [{
        "text" : "La paciente refiere fiebre y cefalea de inicio reciente."
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:observation-pregnancy-dengue-example",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "ObservationEstadoEmbarazoDOExample",
      "meta" : {
        "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/ObservationEstadoEmbarazoDO"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_ObservationEstadoEmbarazoDOExample\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observación ObservationEstadoEmbarazoDOExample</b></p><a name=\"ObservationEstadoEmbarazoDOExample\"> </a><a name=\"hcObservationEstadoEmbarazoDOExample\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-ObservationEstadoEmbarazoDO.html\">Estado de embarazo DO</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 82810-3}\">Pregnancy status</span></p><p><b>subject</b>: <a href=\"Patient-PatientDOExample.html\">María Pérez  Female, DoB: 1990-05-15 ( Cédula: 00000000000)</a></p><p><b>effective</b>: 2026-10-26 09:00:00-0400</p><p><b>value</b>: <span title=\"Codes:{http://snomed.info/sct 77386006}\">Pregnant</span></p><p><b>note</b>: </p><blockquote><div><p>Paciente con embarazo de 18 semanas referido durante la evaluación epidemiológica.</p>\n</div></blockquote></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "82810-3",
          "display" : "Pregnancy status"
        }]
      },
      "subject" : {
        "reference" : "Patient/PatientDOExample"
      },
      "effectiveDateTime" : "2026-10-26T09:00:00-04:00",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "77386006",
          "display" : "Pregnant"
        }]
      },
      "note" : [{
        "text" : "Paciente con embarazo de 18 semanas referido durante la evaluación epidemiológica."
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:observation-travel-dengue-example",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "ObservationViajesExposicionDOExample",
      "meta" : {
        "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/ObservationViajesExposicionDO"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_ObservationViajesExposicionDOExample\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observación ObservationViajesExposicionDOExample</b></p><a name=\"ObservationViajesExposicionDOExample\"> </a><a name=\"hcObservationViajesExposicionDOExample\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-ObservationViajesExposicionDO.html\">Viajes y exposición DO</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 10180-6}\">Travel history</span></p><p><b>subject</b>: <a href=\"Patient-PatientDOExample.html\">María Pérez  Female, DoB: 1990-05-15 ( Cédula: 00000000000)</a></p><p><b>effective</b>: 2026-10-18 --&gt; 2026-10-24</p><p><b>value</b>: Viaje a una zona con transmisión de dengue y exposición a picaduras de mosquitos.</p><p><b>note</b>: </p><blockquote><div><p>La paciente regresó a Santo Domingo un día antes del inicio de los síntomas.</p>\n</div></blockquote></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "10180-6",
          "display" : "Travel history"
        }]
      },
      "subject" : {
        "reference" : "Patient/PatientDOExample"
      },
      "effectivePeriod" : {
        "start" : "2026-10-18",
        "end" : "2026-10-24"
      },
      "valueString" : "Viaje a una zona con transmisión de dengue y exposición a picaduras de mosquitos.",
      "note" : [{
        "text" : "La paciente regresó a Santo Domingo un día antes del inicio de los síntomas."
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:conclusion-dengue-example",
    "resource" : {
      "resourceType" : "Condition",
      "id" : "ConditionConclusionDOExample",
      "meta" : {
        "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/ConditionConclusionDO"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Condition_ConditionConclusionDOExample\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Condición ConditionConclusionDOExample</b></p><a name=\"ConditionConclusionDOExample\"> </a><a name=\"hcConditionConclusionDOExample\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-ConditionConclusionDO.html\">Conclusión epidemiológica DO</a></p></div><p><b>clinicalStatus</b>: <span title=\"Codes:\">active</span></p><p><b>verificationStatus</b>: <span title=\"Codes:\">confirmed</span></p><p><b>category</b>: <span title=\"Codes:{https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSCategoriaNotificacionDO conclusion-epidemiologica}\">Conclusión epidemiológica</span></p><p><b>code</b>: <span title=\"Codes:{http://hl7.org/fhir/sid/icd-10 A90}\">Dengue</span></p><p><b>subject</b>: <a href=\"Patient-PatientDOExample.html\">María Pérez  Female, DoB: 1990-05-15 ( Cédula: 00000000000)</a></p><p><b>recordedDate</b>: 2026-10-26</p><p><b>note</b>: </p><blockquote><div><p>Caso confirmado de dengue. Se recomienda seguimiento clínico estrecho por embarazo.</p>\n</div></blockquote></div>"
      },
      "clinicalStatus" : {
        "coding" : [{
          "code" : "active"
        }]
      },
      "verificationStatus" : {
        "coding" : [{
          "code" : "confirmed"
        }]
      },
      "category" : [{
        "coding" : [{
          "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSCategoriaNotificacionDO",
          "code" : "conclusion-epidemiologica"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/sid/icd-10",
          "code" : "A90",
          "display" : "Dengue"
        }]
      },
      "subject" : {
        "reference" : "Patient/PatientDOExample"
      },
      "recordedDate" : "2026-10-26",
      "note" : [{
        "text" : "Caso confirmado de dengue. Se recomienda seguimiento clínico estrecho por embarazo."
      }]
    }
  }]
}

```
