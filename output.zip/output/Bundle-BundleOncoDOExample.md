# Bundle oncológico de ejemplo - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Bundle oncológico de ejemplo**

## Example Bundle: Bundle oncológico de ejemplo



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "BundleOncoDOExample",
  "meta" : {
    "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/BundleOncoDO"]
  },
  "identifier" : {
    "system" : "https://example.org/identifiers/documentos",
    "value" : "ONCO-2026-0001"
  },
  "type" : "document",
  "timestamp" : "2026-09-15T10:05:00-04:00",
  "entry" : [{
    "fullUrl" : "https://example.org/fhir/Composition/CompositionDOOncoExample",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "CompositionDOOncoExample",
      "meta" : {
        "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/CompositionDOOnco"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Composition_CompositionDOOncoExample\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composición CompositionDOOncoExample</b></p><a name=\"CompositionDOOncoExample\"> </a><a name=\"hcCompositionDOOncoExample\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-CompositionDOOnco.html\">Documento Clínico Oncologico</a></p></div><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{http://loinc.org 115562-1}\">Oncology Clinical Document</span></p><p><b>date</b>: 2026-09-15 10:00:00-0400</p><p><b>author</b>: <a href=\"Organization-OrganizationDOExample.html\">Centro de Salud DO Ejemplo (Healthcare Provider) (https://digital.msp.gob.do/identifiers/organization#ORG-001)</a></p><p><b>title</b>: Notificación de caso al Registro Nacional de Cáncer</p><p><b>custodian</b>: <a href=\"Organization-OrganizationDOExample.html\">Centro de Salud DO Ejemplo (Healthcare Provider) (https://digital.msp.gob.do/identifiers/organization#ORG-001)</a></p></div>"
      },
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "115562-1",
          "display" : "Oncology Clinical Document"
        }]
      },
      "subject" : {
        "reference" : "Patient/PatientDOExample"
      },
      "date" : "2026-09-15T10:00:00-04:00",
      "author" : [{
        "reference" : "Organization/OrganizationDOExample"
      }],
      "title" : "Notificación de caso al Registro Nacional de Cáncer",
      "custodian" : {
        "reference" : "Organization/OrganizationDOExample"
      },
      "section" : [{
        "title" : "Diagnóstico",
        "code" : {
          "coding" : [{
            "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSSeccionesOncoDO",
            "code" : "diagnostico",
            "display" : "Diagnóstico de cáncer primario"
          }]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">Carcinoma ductal infiltrante de mama izquierda (C50.4, 8500/3).</div>"
        },
        "entry" : [{
          "reference" : "Condition/PrimaryCancerConditionDOExample"
        }]
      },
      {
        "title" : "Patología y biomarcadores",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "30954-2",
            "display" : "Relevant diagnostic tests/laboratory data Narrative"
          }]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">Grado 2. RE positivo, RP positivo, HER2 negativo. Variante PIK3CA.</div>"
        },
        "entry" : [{
          "reference" : "DiagnosticReport/PathologyReportDOExample"
        }]
      },
      {
        "title" : "Estadificación",
        "code" : {
          "coding" : [{
            "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSSeccionesOncoDO",
            "code" : "estadificacion",
            "display" : "Estadificación y riesgo"
          }]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">Estadio II (AJCC TNM 8.ª edición).</div>"
        },
        "entry" : [{
          "reference" : "Observation/CancerStageDOExample"
        }]
      },
      {
        "title" : "Tratamientos",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "47519-4",
            "display" : "History of Procedures Document"
          }]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">Mastectomía parcial. Hormonoterapia con tamoxifeno.</div>"
        },
        "entry" : [{
          "reference" : "Procedure/SurgicalProcedureDOExample"
        },
        {
          "reference" : "MedicationStatement/CancerMedicationStatementDOExample"
        }]
      }]
    }
  },
  {
    "fullUrl" : "https://example.org/fhir/Patient/PatientDOExample",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "PatientDOExample",
      "meta" : {
        "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/PatientDO"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_PatientDOExample\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Paciente PatientDOExample</b></p><a name=\"PatientDOExample\"> </a><a name=\"hcPatientDOExample\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-PatientDO.html\">Paciente DO</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">María Pérez  Female, DoB: 1990-05-15 ( Cédula: 00000000000)</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Ways to contact the Patient\">Contact Detail</td><td colspan=\"3\"><ul><li><a href=\"tel:+1-809-555-6789\">+1-809-555-6789</a></li><li><a href=\"mailto:maria.perez@example.do\">maria.perez@example.do</a></li><li>Calle Principal 456 Santo Domingo Distrito Nacional 10102 DO </li></ul></td></tr></table></div>"
      },
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSIdentificadoresPersona",
            "code" : "CED"
          }]
        },
        "system" : "https://digital.msp.gob.do/fhir/sid/cedula",
        "value" : "00000000000"
      }],
      "name" : [{
        "extension" : [{
          "url" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/SegundoApellidoDO",
          "valueString" : "Gómez"
        }],
        "family" : "Pérez",
        "given" : ["María"]
      }],
      "telecom" : [{
        "system" : "phone",
        "value" : "+1-809-555-6789"
      },
      {
        "system" : "email",
        "value" : "maria.perez@example.do"
      }],
      "gender" : "female",
      "birthDate" : "1990-05-15",
      "address" : [{
        "line" : ["Calle Principal 456"],
        "city" : "Santo Domingo",
        "state" : "Distrito Nacional",
        "postalCode" : "10102",
        "country" : "DO"
      }]
    }
  },
  {
    "fullUrl" : "https://example.org/fhir/Organization/OrganizationDOExample",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "OrganizationDOExample",
      "meta" : {
        "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/OrganizationDO"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_OrganizationDOExample\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organización OrganizationDOExample</b></p><a name=\"OrganizationDOExample\"> </a><a name=\"hcOrganizationDOExample\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-OrganizationDO.html\">Organización DO</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Centro de Salud DO Ejemplo (Healthcare Provider) (https://digital.msp.gob.do/identifiers/organization#ORG-001)</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Record is active\">Active:</td><td colspan=\"3\">true</td></tr><tr><td style=\"background-color: #f3f5da\" title=\"The kind(s) of organization that this is\">Type:</td><td colspan=\"3\"><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/organization-type prov}\">Healthcare Provider</span></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Ways to contact the organization\">Contact Detail</td><td colspan=\"3\"><ul><li><a href=\"tel:+1-809-555-1234\">+1-809-555-1234</a></li><li><a href=\"mailto:contacto@centrosaluddo.do\">contacto@centrosaluddo.do</a></li><li>Av. Principal 123 Santo Domingo Distrito Nacional 10101 DO </li></ul></td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "https://digital.msp.gob.do/identifiers/organization",
        "value" : "ORG-001"
      }],
      "active" : true,
      "type" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/organization-type",
          "code" : "prov",
          "display" : "Healthcare Provider"
        }]
      }],
      "name" : "Centro de Salud DO Ejemplo",
      "telecom" : [{
        "system" : "phone",
        "value" : "+1-809-555-1234"
      },
      {
        "system" : "email",
        "value" : "contacto@centrosaluddo.do"
      }],
      "address" : [{
        "line" : ["Av. Principal 123"],
        "city" : "Santo Domingo",
        "state" : "Distrito Nacional",
        "postalCode" : "10101",
        "country" : "DO"
      }]
    }
  },
  {
    "fullUrl" : "https://example.org/fhir/Condition/PrimaryCancerConditionDOExample",
    "resource" : {
      "resourceType" : "Condition",
      "id" : "PrimaryCancerConditionDOExample",
      "meta" : {
        "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/PrimaryCancerConditionDO"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Condition_PrimaryCancerConditionDOExample\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Condición PrimaryCancerConditionDOExample</b></p><a name=\"PrimaryCancerConditionDOExample\"> </a><a name=\"hcPrimaryCancerConditionDOExample\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-PrimaryCancerConditionDO.html\">Cáncer Primario DO</a></p></div><p><b>Morfología y comportamiento histológico DO</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/icd-o-3 8500/3}\">Carcinoma ductal infiltrante, SAI</span></p><p><b>clinicalStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-clinical active}\">Active</span></p><p><b>verificationStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-ver-status confirmed}\">Confirmed</span></p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-category problem-list-item}\">Problem List Item</span></p><p><b>code</b>: <span title=\"Codes:{http://hl7.org/fhir/sid/icd-10 C50.4}\">Neoplasia maligna del cuadrante superior externo de la mama</span></p><p><b>bodySite</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/icd-o-3 C50.4}\">Cuadrante superior externo de la mama</span></p><p><b>subject</b>: <a href=\"Patient-PatientDOExample.html\">María Pérez  Female, DoB: 1990-05-15 ( Cédula: 00000000000)</a></p><p><b>onset</b>: 2026-07-20</p><p><b>recordedDate</b>: 2026-07-28</p><h3>Evidences</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Detail</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"DiagnosticReport-PathologyReportDOExample.html\">Diagnostic Report for 'Pathology study' for '-&gt;María Pérez  Female, DoB: 1990-05-15 ( Cédula: 00000000000)'</a></td></tr></table></div>"
      },
      "extension" : [{
        "url" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/HistologyMorphologyBehaviorDO",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/icd-o-3",
            "code" : "8500/3",
            "display" : "Carcinoma ductal infiltrante, SAI"
          }]
        }
      }],
      "clinicalStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-clinical",
          "code" : "active"
        }]
      },
      "verificationStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-ver-status",
          "code" : "confirmed"
        }]
      },
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-category",
          "code" : "problem-list-item"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/sid/icd-10",
          "code" : "C50.4",
          "display" : "Neoplasia maligna del cuadrante superior externo de la mama"
        }]
      },
      "bodySite" : [{
        "extension" : [{
          "url" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/LateralidadDO",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://snomed.info/sct",
              "code" : "7771000",
              "display" : "Left"
            }]
          }
        }],
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/icd-o-3",
          "code" : "C50.4",
          "display" : "Cuadrante superior externo de la mama"
        }]
      }],
      "subject" : {
        "reference" : "Patient/PatientDOExample"
      },
      "onsetDateTime" : "2026-07-20",
      "recordedDate" : "2026-07-28",
      "evidence" : [{
        "detail" : [{
          "reference" : "DiagnosticReport/PathologyReportDOExample"
        }]
      }]
    }
  },
  {
    "fullUrl" : "https://example.org/fhir/DiagnosticReport/PathologyReportDOExample",
    "resource" : {
      "resourceType" : "DiagnosticReport",
      "id" : "PathologyReportDOExample",
      "meta" : {
        "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/PathologyReportDO"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"DiagnosticReport_PathologyReportDOExample\"> </a><p class=\"res-header-id\"><b>Generated Narrative: InformeDiagnostico PathologyReportDOExample</b></p><a name=\"PathologyReportDOExample\"> </a><a name=\"hcPathologyReportDOExample\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-PathologyReportDO.html\">Informe de Patología DO</a></p></div><h2><span title=\"Codes:{http://loinc.org 11526-1}\">Pathology study</span> </h2><table class=\"grid\"><tr><td>Asunto</td><td>María Pérez  Female, DoB: 1990-05-15 ( Cédula: 00000000000)</td></tr><tr><td>Relevant Time</td><td>2026-07-15</td></tr><tr><td>Reported</td><td>2026-07-20 12:00:00-0400</td></tr><tr><td>Performer</td><td> <a href=\"Organization-OrganizationDOExample.html\">Centro de Salud DO Ejemplo (Healthcare Provider) (https://digital.msp.gob.do/identifiers/organization#ORG-001)</a></td></tr></table><p><b>Report Details</b></p><table class=\"grid\"><tr><td><b>Code</b></td><td><b>Valor</b></td><td><b>Flags</b></td></tr><tr><td><a href=\"Observation-PathologyResultDOExample.html\"><span title=\"Codes:{https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSObservacionesOncoDO variante-genomica}\">Variante genómica</span></a></td><td/><td>Final</td></tr></table><p>Carcinoma ductal infiltrante, grado 2. RE positivo, RP positivo, HER2 negativo.</p><p><b>Coded Conclusions:</b></p><ul><li><span title=\"Codes:{https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSResultadosOncoDO G2}\">Grado 2</span></li><li><span title=\"Codes:{https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSResultadosOncoDO re-positivo}\">Receptor de estrógeno positivo</span></li><li><span title=\"Codes:{https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSResultadosOncoDO rp-positivo}\">Receptor de progesterona positivo</span></li><li><span title=\"Codes:{https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSResultadosOncoDO her2-negativo}\">HER2 negativo</span></li></ul></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "11526-1",
          "display" : "Pathology study"
        }]
      },
      "subject" : {
        "reference" : "Patient/PatientDOExample"
      },
      "effectiveDateTime" : "2026-07-15",
      "issued" : "2026-07-20T12:00:00-04:00",
      "performer" : [{
        "reference" : "Organization/OrganizationDOExample"
      }],
      "result" : [{
        "reference" : "Observation/PathologyResultDOExample"
      }],
      "conclusion" : "Carcinoma ductal infiltrante, grado 2. RE positivo, RP positivo, HER2 negativo.",
      "conclusionCode" : [{
        "coding" : [{
          "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSResultadosOncoDO",
          "code" : "G2",
          "display" : "Grado 2"
        }]
      },
      {
        "coding" : [{
          "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSResultadosOncoDO",
          "code" : "re-positivo",
          "display" : "Receptor de estrógeno positivo"
        }]
      },
      {
        "coding" : [{
          "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSResultadosOncoDO",
          "code" : "rp-positivo",
          "display" : "Receptor de progesterona positivo"
        }]
      },
      {
        "coding" : [{
          "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSResultadosOncoDO",
          "code" : "her2-negativo",
          "display" : "HER2 negativo"
        }]
      }]
    }
  },
  {
    "fullUrl" : "https://example.org/fhir/Observation/PathologyResultDOExample",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "PathologyResultDOExample",
      "meta" : {
        "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/PathologyResultDO"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_PathologyResultDOExample\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observación PathologyResultDOExample</b></p><a name=\"PathologyResultDOExample\"> </a><a name=\"hcPathologyResultDOExample\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-PathologyResultDO.html\">Resultado de Patología DO</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSObservacionesOncoDO variante-genomica}\">Variante genómica</span></p><p><b>subject</b>: <a href=\"Patient-PatientDOExample.html\">María Pérez  Female, DoB: 1990-05-15 ( Cédula: 00000000000)</a></p><p><b>focus</b>: <a href=\"Condition-PrimaryCancerConditionDOExample.html\">Condition Neoplasia maligna del cuadrante superior externo de la mama</a></p><p><b>effective</b>: 2026-07-15</p><p><b>performer</b>: <a href=\"Organization-OrganizationDOExample.html\">Centro de Salud DO Ejemplo (Healthcare Provider) (https://digital.msp.gob.do/identifiers/organization#ORG-001)</a></p><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSObservacionesOncoDO gen}\">Gen</span></p><p><b>value</b>: <span title=\"Codes:\">PIK3CA</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSObservacionesOncoDO hgvs}\">Nomenclatura HGVS</span></p><p><b>value</b>: <span title=\"Codes:\">NM_006218.4:c.3140A&gt;G</span></p></blockquote></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSObservacionesOncoDO",
          "code" : "variante-genomica",
          "display" : "Variante genómica"
        }]
      },
      "subject" : {
        "reference" : "Patient/PatientDOExample"
      },
      "focus" : [{
        "reference" : "Condition/PrimaryCancerConditionDOExample"
      }],
      "effectiveDateTime" : "2026-07-15",
      "performer" : [{
        "reference" : "Organization/OrganizationDOExample"
      }],
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSObservacionesOncoDO",
            "code" : "gen"
          }]
        },
        "valueCodeableConcept" : {
          "text" : "PIK3CA"
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSObservacionesOncoDO",
            "code" : "hgvs"
          }]
        },
        "valueCodeableConcept" : {
          "text" : "NM_006218.4:c.3140A>G"
        }
      }]
    }
  },
  {
    "fullUrl" : "https://example.org/fhir/Observation/CancerStageDOExample",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "CancerStageDOExample",
      "meta" : {
        "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/CancerStageDO"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_CancerStageDOExample\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observación CancerStageDOExample</b></p><a name=\"CancerStageDOExample\"> </a><a name=\"hcCancerStageDOExample\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-CancerStageDO.html\">Estadio del Cáncer DO</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSObservacionesOncoDO estadio}\">Estadio del cáncer</span></p><p><b>subject</b>: <a href=\"Patient-PatientDOExample.html\">María Pérez  Female, DoB: 1990-05-15 ( Cédula: 00000000000)</a></p><p><b>focus</b>: <a href=\"Condition-PrimaryCancerConditionDOExample.html\">Condition Neoplasia maligna del cuadrante superior externo de la mama</a></p><p><b>effective</b>: 2026-07-25</p><p><b>performer</b>: <a href=\"Organization-OrganizationDOExample.html\">Centro de Salud DO Ejemplo (Healthcare Provider) (https://digital.msp.gob.do/identifiers/organization#ORG-001)</a></p><p><b>value</b>: <span title=\"Codes:{https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSResultadosOncoDO estadio-II}\">Estadio II</span></p><p><b>method</b>: <span title=\"Codes:\">AJCC TNM 8.ª edición</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSObservacionesOncoDO",
          "code" : "estadio",
          "display" : "Estadio del cáncer"
        }]
      },
      "subject" : {
        "reference" : "Patient/PatientDOExample"
      },
      "focus" : [{
        "reference" : "Condition/PrimaryCancerConditionDOExample"
      }],
      "effectiveDateTime" : "2026-07-25",
      "performer" : [{
        "reference" : "Organization/OrganizationDOExample"
      }],
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSResultadosOncoDO",
          "code" : "estadio-II",
          "display" : "Estadio II"
        }]
      },
      "method" : {
        "text" : "AJCC TNM 8.ª edición"
      }
    }
  },
  {
    "fullUrl" : "https://example.org/fhir/Procedure/SurgicalProcedureDOExample",
    "resource" : {
      "resourceType" : "Procedure",
      "id" : "SurgicalProcedureDOExample",
      "meta" : {
        "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/SurgicalProcedureDO"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Procedure_SurgicalProcedureDOExample\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Procedimiento SurgicalProcedureDOExample</b></p><a name=\"SurgicalProcedureDOExample\"> </a><a name=\"hcSurgicalProcedureDOExample\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-SurgicalProcedureDO.html\">Cirugía Oncológica DO</a></p></div><p><b>status</b>: Completed</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 387713003}\">Surgical procedure</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 64368001}\">Partial mastectomy</span></p><p><b>subject</b>: <a href=\"Patient-PatientDOExample.html\">María Pérez  Female, DoB: 1990-05-15 ( Cédula: 00000000000)</a></p><p><b>performed</b>: 2026-08-05</p><h3>Performers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Actor</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Organization-OrganizationDOExample.html\">Centro de Salud DO Ejemplo (Healthcare Provider) (https://digital.msp.gob.do/identifiers/organization#ORG-001)</a></td></tr></table><p><b>reasonReference</b>: <a href=\"Condition-PrimaryCancerConditionDOExample.html\">Condition Neoplasia maligna del cuadrante superior externo de la mama</a></p></div>"
      },
      "status" : "completed",
      "category" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "387713003",
          "display" : "Surgical procedure"
        }]
      },
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "64368001",
          "display" : "Partial mastectomy"
        }]
      },
      "subject" : {
        "reference" : "Patient/PatientDOExample"
      },
      "performedDateTime" : "2026-08-05",
      "performer" : [{
        "actor" : {
          "reference" : "Organization/OrganizationDOExample"
        }
      }],
      "reasonReference" : [{
        "reference" : "Condition/PrimaryCancerConditionDOExample"
      }]
    }
  },
  {
    "fullUrl" : "https://example.org/fhir/MedicationStatement/CancerMedicationStatementDOExample",
    "resource" : {
      "resourceType" : "MedicationStatement",
      "id" : "CancerMedicationStatementDOExample",
      "meta" : {
        "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/CancerMedicationStatementDO"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationStatement_CancerMedicationStatementDOExample\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ResumenMedicación /ResumenMedicamento CancerMedicationStatementDOExample</b></p><a name=\"CancerMedicationStatementDOExample\"> </a><a name=\"hcCancerMedicationStatementDOExample\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-CancerMedicationStatementDO.html\">Tratamiento Farmacológico Oncológico DO</a></p></div><p><b>status</b>: Active</p><p><b>medication</b>: <span title=\"Codes:{http://www.whocc.no/atc L02BA01}\">tamoxifen</span></p><p><b>subject</b>: <a href=\"Patient-PatientDOExample.html\">María Pérez  Female, DoB: 1990-05-15 ( Cédula: 00000000000)</a></p><p><b>effective</b>: 2026-09-01 --&gt; (ongoing)</p><p><b>dateAsserted</b>: 2026-09-15</p><p><b>informationSource</b>: <a href=\"Organization-OrganizationDOExample.html\">Centro de Salud DO Ejemplo (Healthcare Provider) (https://digital.msp.gob.do/identifiers/organization#ORG-001)</a></p><p><b>reasonReference</b>: <a href=\"Condition-PrimaryCancerConditionDOExample.html\">Condition Neoplasia maligna del cuadrante superior externo de la mama</a></p><h3>Dosages</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Text</b></td></tr><tr><td style=\"display: none\">*</td><td>20 mg vía oral una vez al día.</td></tr></table></div>"
      },
      "status" : "active",
      "medicationCodeableConcept" : {
        "coding" : [{
          "system" : "http://www.whocc.no/atc",
          "code" : "L02BA01",
          "display" : "tamoxifen"
        }]
      },
      "subject" : {
        "reference" : "Patient/PatientDOExample"
      },
      "effectivePeriod" : {
        "start" : "2026-09-01"
      },
      "dateAsserted" : "2026-09-15",
      "informationSource" : {
        "reference" : "Organization/OrganizationDOExample"
      },
      "reasonReference" : [{
        "reference" : "Condition/PrimaryCancerConditionDOExample"
      }],
      "dosage" : [{
        "text" : "20 mg vía oral una vez al día."
      }]
    }
  }]
}

```
