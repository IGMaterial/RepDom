# Ejemplo de Bundle transaccional DO - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Ejemplo de Bundle transaccional DO**

## Example Bundle: Ejemplo de Bundle transaccional DO



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "BundleTransaccDOExample",
  "meta" : {
    "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/BundleTransaccDO"]
  },
  "type" : "transaction",
  "timestamp" : "2026-08-19T10:30:00Z",
  "entry" : [{
    "fullUrl" : "urn:uuid:list-do-example",
    "resource" : {
      "resourceType" : "List",
      "id" : "ListDOExample",
      "meta" : {
        "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/ListDO"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"List_ListDOExample\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Lista ListDOExample</b></p><a name=\"ListDOExample\"> </a><a name=\"hcListDOExample\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-ListDO.html\">ListDO</a></p></div><table class=\"clstu\"><tr><td>Date: 2026-08-19 10:30:00+0000 </td><td>Mode: Working List </td><td>Status: Current </td><td>Code: SubmissionSet as a FHIR List </td></tr><tr><td>Asunto: <code>PatientDO/PatientDOExample</code></td></tr></table><table class=\"grid\"><tr style=\"backgound-color: #eeeeee\"><td><b>Items</b></td></tr><tr><td><code>DocumentReferenceDO/DocumentReferenceDOExample</code></td></tr></table></div>"
      },
      "extension" : [{
        "url" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/ihe-sourceId",
        "valueIdentifier" : {
          "value" : "urn:oid:1.2.3.4"
        }
      }],
      "status" : "current",
      "mode" : "working",
      "code" : {
        "coding" : [{
          "system" : "https://profiles.ihe.net/ITI/MHD/CodeSystem/MHDlistTypes",
          "code" : "submissionset"
        }]
      },
      "subject" : {
        "reference" : "PatientDO/PatientDOExample"
      },
      "date" : "2026-08-19T10:30:00Z",
      "entry" : [{
        "item" : {
          "reference" : "DocumentReferenceDO/DocumentReferenceDOExample"
        }
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "List"
    }
  },
  {
    "fullUrl" : "urn:uuid:document-reference-do-example",
    "resource" : {
      "resourceType" : "DocumentReference",
      "id" : "DocumentReferenceDOExample",
      "meta" : {
        "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/DocumentReferenceDO"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"DocumentReference_DocumentReferenceDOExample\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ReferenciaDocumento DocumentReferenceDOExample</b></p><a name=\"DocumentReferenceDOExample\"> </a><a name=\"hcDocumentReferenceDOExample\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-DocumentReferenceDO.html\">DocumentReferenceDO</a></p></div><p><b>masterIdentifier</b>: <a href=\"http://terminology.hl7.org/7.5.0/NamingSystem-uri.html\" title=\"As defined by RFC 3986 (http://www.ietf.org/rfc/rfc3986.txt)(with many schemes defined in many RFCs). For OIDs and UUIDs, use the URN form (urn:oid:(note: lowercase) and urn:uuid:). See http://www.ietf.org/rfc/rfc3001.txt and http://www.ietf.org/rfc/rfc4122.txt \r\n\r\nThis oid is used as an identifier II.root to indicate the the extension is an absolute URI (technically, an IRI). Typically, this is used for OIDs and GUIDs. Note that when this OID is used with OIDs and GUIDs, the II.extension should start with urn:oid or urn:uuid: \r\n\r\nNote that this OID is created to aid with interconversion between CDA and FHIR - FHIR uses urn:ietf:rfc:3986 as equivalent to this OID. URIs as identifiers appear more commonly in FHIR.\r\n\r\nThis OID may also be used in CD.codeSystem.\">Uniform Resource Identifier (URI)</a>/urn:uuid:document-reference-do-example</p><p><b>status</b>: Current</p><p><b>type</b>: <span title=\"Codes:{http://loinc.org 34105-7}\">Summarization of episode note</span></p><p><b>subject</b>: <code>PatientDO/PatientDOExample</code></p><p><b>date</b>: 2026-08-19 10:30:00+0000</p><p><b>custodian</b>: <code>OrganizationDO/OrganizationDOExample</code></p><blockquote><p><b>content</b></p><h3>Attachments</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>ContentType</b></td><td><b>Url</b></td></tr><tr><td style=\"display: none\">*</td><td>application/fhir+json</td><td><a href=\"Bundle-BundleTransaccDOExample.html#urn-uuid-bundle-nps-do-example\">Bundle: identifier = UUID:bundle-nps-do-example; type = document; timestamp = 2026-08-19 10:30:00+0000</a></td></tr></table></blockquote></div>"
      },
      "masterIdentifier" : {
        "system" : "urn:ietf:rfc:3986",
        "value" : "urn:uuid:document-reference-do-example"
      },
      "status" : "current",
      "type" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "34105-7",
          "display" : "Summarization of episode note"
        }]
      },
      "subject" : {
        "reference" : "PatientDO/PatientDOExample"
      },
      "date" : "2026-08-19T10:30:00Z",
      "custodian" : {
        "reference" : "OrganizationDO/OrganizationDOExample"
      },
      "content" : [{
        "attachment" : {
          "contentType" : "application/fhir+json",
          "url" : "urn:uuid:bundle-nps-do-example"
        }
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "DocumentReference"
    }
  },
  {
    "fullUrl" : "urn:uuid:bundle-nps-do-example",
    "resource" : {
      "resourceType" : "Bundle",
      "id" : "BundleNPSDOExample",
      "meta" : {
        "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/BundleNPSDO"]
      },
      "identifier" : {
        "system" : "urn:ietf:rfc:3986",
        "value" : "urn:uuid:bundle-nps-do-example"
      },
      "type" : "document",
      "timestamp" : "2026-08-19T10:30:00Z",
      "entry" : [{
        "fullUrl" : "urn:uuid:CompositionDOExample",
        "resource" : {
          "resourceType" : "Composition",
          "id" : "CompositionDOExample",
          "meta" : {
            "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/CompositionDO"]
          },
          "status" : "final",
          "type" : {
            "coding" : [{
              "system" : "http://loinc.org",
              "code" : "60591-5",
              "display" : "Patient summary Document"
            }]
          },
          "subject" : {
            "reference" : "PatientDO/PatientDOExample"
          },
          "date" : "2026-08-19",
          "author" : [{
            "reference" : "PractitionerDO/PractitionerDOExample"
          }],
          "title" : "Resumen clínico del paciente",
          "custodian" : {
            "reference" : "OrganizationDO/OrganizationDOExample"
          },
          "section" : [{
            "title" : "Condiciones del Paciente",
            "code" : {
              "coding" : [{
                "system" : "http://loinc.org",
                "code" : "11450-4",
                "display" : "Problem list Reported"
              }]
            },
            "text" : {
              "status" : "generated",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">CONDICIONES</div>"
            },
            "entry" : [{
              "reference" : "Condition/ConditionDOEjemplo"
            }]
          },
          {
            "title" : "Medicamentos",
            "code" : {
              "coding" : [{
                "system" : "http://loinc.org",
                "code" : "10160-0",
                "display" : "Hx of Medication use"
              }]
            },
            "text" : {
              "status" : "generated",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">MEDICAMENTOS</div>"
            },
            "entry" : [{
              "reference" : "MedicationStatement/MedicationStatementDOEjemplo"
            }]
          },
          {
            "title" : "Alergias",
            "code" : {
              "coding" : [{
                "system" : "http://loinc.org",
                "code" : "48765-2",
                "display" : "Allergies and adverse reactions Document."
              }]
            },
            "text" : {
              "status" : "generated",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">ALERGIAS</div>"
            },
            "entry" : [{
              "reference" : "AllergyIntolerance/AllergyIntoleranceDOExample"
            }]
          }]
        }
      },
      {
        "fullUrl" : "urn:uuid:PatientDOExample",
        "resource" : {
          "resourceType" : "Patient",
          "id" : "PatientDOExample",
          "meta" : {
            "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/PatientDO"]
          },
          "identifier" : [{
            "type" : {
              "coding" : [{
                "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSIdentificadoresPersona",
                "code" : "CED"
              }]
            },
            "system" : "https://digital.msp.gob.do/fhir/sid/cedula",
            "value" : "00000000000"
          }],
          "name" : [{
            "extension" : [{
              "url" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/SegundoApellidoDO",
              "valueString" : "Gómez"
            }],
            "family" : "Pérez",
            "given" : ["María"]
          }],
          "telecom" : [{
            "system" : "phone",
            "value" : "+1-809-555-6789"
          },
          {
            "system" : "email",
            "value" : "maria.perez@example.do"
          }],
          "gender" : "female",
          "birthDate" : "1990-05-15",
          "address" : [{
            "line" : ["Calle Principal 456"],
            "city" : "Santo Domingo",
            "state" : "Distrito Nacional",
            "postalCode" : "10102",
            "country" : "DO"
          }]
        }
      },
      {
        "fullUrl" : "urn:uuid:OrganizationDOExample",
        "resource" : {
          "resourceType" : "Organization",
          "id" : "OrganizationDOExample",
          "meta" : {
            "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/OrganizationDO"]
          },
          "identifier" : [{
            "system" : "https://digital.msp.gob.do/identifiers/organization",
            "value" : "ORG-001"
          }],
          "active" : true,
          "type" : [{
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/organization-type",
              "code" : "prov",
              "display" : "Healthcare Provider"
            }]
          }],
          "name" : "Centro de Salud DO Ejemplo",
          "telecom" : [{
            "system" : "phone",
            "value" : "+1-809-555-1234"
          },
          {
            "system" : "email",
            "value" : "contacto@centrosaluddo.do"
          }],
          "address" : [{
            "line" : ["Av. Principal 123"],
            "city" : "Santo Domingo",
            "state" : "Distrito Nacional",
            "postalCode" : "10101",
            "country" : "DO"
          }]
        }
      },
      {
        "fullUrl" : "urn:uuid:PractitionerDOExample",
        "resource" : {
          "resourceType" : "Practitioner",
          "id" : "PractitionerDOExample",
          "meta" : {
            "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/PractitionerDO"]
          },
          "identifier" : [{
            "type" : {
              "coding" : [{
                "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSIdentificadoresPersona",
                "code" : "PRN"
              }]
            },
            "value" : "PROF-0001"
          }],
          "name" : [{
            "extension" : [{
              "url" : "http://digital.msp.gob.do/fhir/StructureDefinition/SegundoApellidoDO",
              "valueString" : "Martínez"
            }],
            "family" : "Rodríguez",
            "given" : ["Laura"]
          }],
          "telecom" : [{
            "system" : "phone",
            "value" : "+1-809-555-9012"
          },
          {
            "system" : "email",
            "value" : "laura.rodriguez@example.do"
          }],
          "address" : [{
            "line" : ["Calle Salud 789"],
            "city" : "Santiago",
            "state" : "Santiago",
            "postalCode" : "51000",
            "country" : "DO"
          }],
          "qualification" : [{
            "code" : {
              "coding" : [{
                "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSEspecialidadesMedicas",
                "code" : "MG",
                "display" : "Medicina general"
              }]
            }
          }]
        }
      },
      {
        "fullUrl" : "urn:uuid:ConditionDOEjemplo",
        "resource" : {
          "resourceType" : "Condition",
          "id" : "ConditionDOEjemplo",
          "meta" : {
            "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/ConditionDO"]
          },
          "clinicalStatus" : {
            "coding" : [{
              "code" : "active"
            }]
          },
          "verificationStatus" : {
            "coding" : [{
              "code" : "confirmed"
            }]
          },
          "severity" : {
            "coding" : [{
              "system" : "http://snomed.info/sct",
              "code" : "6736007",
              "display" : "Moderate"
            }]
          },
          "code" : {
            "coding" : [{
              "system" : "http://snomed.info/sct",
              "code" : "404684003",
              "display" : "Clinical finding"
            }]
          },
          "subject" : {
            "reference" : "PatientDO/PatientDOExample"
          },
          "onsetDateTime" : "2026-08-10",
          "recordedDate" : "2026-08-10",
          "recorder" : {
            "reference" : "PractitionerDO/PractitionerDOExample"
          },
          "note" : [{
            "text" : "Paciente con diagnóstico registrado en consulta."
          }]
        }
      },
      {
        "fullUrl" : "urn:uuid:AllergyIntoleranceDOExample",
        "resource" : {
          "resourceType" : "AllergyIntolerance",
          "id" : "AllergyIntoleranceDOExample",
          "meta" : {
            "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/AllergyIntoleranceDO"]
          },
          "clinicalStatus" : {
            "coding" : [{
              "code" : "active"
            }]
          },
          "verificationStatus" : {
            "coding" : [{
              "code" : "confirmed"
            }]
          },
          "type" : "allergy",
          "category" : ["food"],
          "criticality" : "high",
          "code" : {
            "coding" : [{
              "system" : "http://snomed.info/sct",
              "code" : "3145006",
              "display" : "Penicillic acid"
            }]
          },
          "patient" : {
            "reference" : "PatientDO/PatientDOExample"
          },
          "onsetDateTime" : "2026-08-10",
          "recordedDate" : "2026-08-10",
          "recorder" : {
            "reference" : "PractitionerDO/PractitionerDOExample"
          }
        }
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "Bundle"
    }
  },
  {
    "fullUrl" : "urn:uuid:patient-do-example",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "PatientDOExample",
      "meta" : {
        "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/PatientDO"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_PatientDOExample\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Paciente PatientDOExample</b></p><a name=\"PatientDOExample\"> </a><a name=\"hcPatientDOExample\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-PatientDO.html\">Paciente DO</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">María Pérez  Female, DoB: 1990-05-15 ( Cédula: 00000000000)</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Ways to contact the Patient\">Contact Detail</td><td colspan=\"3\"><ul><li><a href=\"tel:+1-809-555-6789\">+1-809-555-6789</a></li><li><a href=\"mailto:maria.perez@example.do\">maria.perez@example.do</a></li><li>Calle Principal 456 Santo Domingo Distrito Nacional 10102 DO </li></ul></td></tr></table></div>"
      },
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSIdentificadoresPersona",
            "code" : "CED"
          }]
        },
        "system" : "https://digital.msp.gob.do/fhir/sid/cedula",
        "value" : "00000000000"
      }],
      "name" : [{
        "extension" : [{
          "url" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/SegundoApellidoDO",
          "valueString" : "Gómez"
        }],
        "family" : "Pérez",
        "given" : ["María"]
      }],
      "telecom" : [{
        "system" : "phone",
        "value" : "+1-809-555-6789"
      },
      {
        "system" : "email",
        "value" : "maria.perez@example.do"
      }],
      "gender" : "female",
      "birthDate" : "1990-05-15",
      "address" : [{
        "line" : ["Calle Principal 456"],
        "city" : "Santo Domingo",
        "state" : "Distrito Nacional",
        "postalCode" : "10102",
        "country" : "DO"
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "Patient"
    }
  }]
}

```
