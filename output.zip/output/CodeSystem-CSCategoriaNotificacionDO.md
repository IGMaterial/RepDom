# Categorías de condiciones de notificación - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Categorías de condiciones de notificación**

## CodeSystem: Categorías de condiciones de notificación (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSCategoriaNotificacionDO | *Version*:0.2.2 |
| Draft as of 2026-11-17 | *Computable Name*:CSCategoriaNotificacionDO |

 
Categorías locales propuestas; no constituyen un catálogo nacional aprobado. 

 This Code system is referenced in the content logical definition of the following value sets: 

* This CodeSystem is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "CSCategoriaNotificacionDO",
  "url" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSCategoriaNotificacionDO",
  "version" : "0.2.2",
  "name" : "CSCategoriaNotificacionDO",
  "title" : "Categorías de condiciones de notificación",
  "status" : "draft",
  "experimental" : true,
  "date" : "2026-11-17T15:46:26-03:00",
  "publisher" : "Ministerio de Salud Pública y Asistencia Social",
  "contact" : [{
    "name" : "Ministerio de Salud Pública y Asistencia Social",
    "telecom" : [{
      "system" : "url",
      "value" : "https://msp.gob.do"
    }]
  }],
  "description" : "Categorías locales propuestas; no constituyen un catálogo nacional aprobado.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DO",
      "display" : "Dominican Republic"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 2,
  "concept" : [{
    "code" : "evento-epidemiologico",
    "display" : "Evento epidemiológico"
  },
  {
    "code" : "conclusion-epidemiologica",
    "display" : "Conclusión epidemiológica"
  }]
}

```
