# Especialidades Profesionales DO - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Especialidades Profesionales DO**

## CodeSystem: Especialidades Profesionales DO 

| | |
| :--- | :--- |
| *Official URL*:https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSEspecialidadDO | *Version*:0.2.2 |
| Draft as of 2026-11-17 | *Computable Name*:CSEspecialidadDO |

 
Catálogo inicial de especialidades profesionales para Practitioner. 

 This Code system is referenced in the content logical definition of the following value sets: 

* [Especialidades Profesionales DO](ValueSet-VSEspecialidadDO.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "CSEspecialidadDO",
  "url" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSEspecialidadDO",
  "version" : "0.2.2",
  "name" : "CSEspecialidadDO",
  "title" : "Especialidades Profesionales DO",
  "status" : "draft",
  "date" : "2026-11-17T15:46:26-03:00",
  "publisher" : "Ministerio de Salud Pública y Asistencia Social",
  "contact" : [{
    "name" : "Ministerio de Salud Pública y Asistencia Social",
    "telecom" : [{
      "system" : "url",
      "value" : "https://msp.gob.do"
    }]
  }],
  "description" : "Catálogo inicial de especialidades profesionales para Practitioner.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DO",
      "display" : "Dominican Republic"
    }]
  }],
  "content" : "fragment",
  "concept" : [{
    "code" : "MG",
    "display" : "Medicina general"
  },
  {
    "code" : "MI",
    "display" : "Medicina interna"
  },
  {
    "code" : "PED",
    "display" : "Pediatría"
  },
  {
    "code" : "GINOBS",
    "display" : "Ginecología y obstetricia"
  },
  {
    "code" : "CARD",
    "display" : "Cardiología"
  },
  {
    "code" : "ENF",
    "display" : "Enfermería"
  },
  {
    "code" : "FARM",
    "display" : "Farmacia"
  }]
}

```
