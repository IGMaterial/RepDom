# Observaciones oncológicas - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Observaciones oncológicas**

## CodeSystem: Observaciones oncológicas 

| | |
| :--- | :--- |
| *Official URL*:https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSObservacionesOncoDO | *Version*:0.2.2 |
| Draft as of 2026-11-17 | *Computable Name*:CSObservacionesOncoDO |

 
Códigos locales para el nombre de las observaciones oncológicas y sus componentes. 

 This Code system is referenced in the content logical definition of the following value sets: 

* [Resultados estructurados de patología](ValueSet-VSCodigoResultadoPatologiaDO.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "CSObservacionesOncoDO",
  "url" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSObservacionesOncoDO",
  "version" : "0.2.2",
  "name" : "CSObservacionesOncoDO",
  "title" : "Observaciones oncológicas",
  "status" : "draft",
  "experimental" : false,
  "date" : "2026-11-17T15:46:26-03:00",
  "publisher" : "Ministerio de Salud Pública y Asistencia Social",
  "contact" : [{
    "name" : "Ministerio de Salud Pública y Asistencia Social",
    "telecom" : [{
      "system" : "url",
      "value" : "https://msp.gob.do"
    }]
  }],
  "description" : "Códigos locales para el nombre de las observaciones oncológicas y sus componentes.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DO",
      "display" : "Dominican Republic"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 6,
  "concept" : [{
    "code" : "estadio",
    "display" : "Estadio del cáncer",
    "definition" : "Grupo de estadio del cáncer primario."
  },
  {
    "code" : "riesgo",
    "display" : "Grupo de riesgo",
    "definition" : "Clasificación de riesgo del cáncer infantil."
  },
  {
    "code" : "breslow",
    "display" : "Profundidad de Breslow",
    "definition" : "Profundidad de invasión del melanoma, en milímetros."
  },
  {
    "code" : "variante-genomica",
    "display" : "Variante genómica",
    "definition" : "Variante genómica detectada en el tumor."
  },
  {
    "code" : "gen",
    "display" : "Gen",
    "definition" : "Gen estudiado (componente de la variante genómica)."
  },
  {
    "code" : "hgvs",
    "display" : "Nomenclatura HGVS",
    "definition" : "Descripción de la variante en nomenclatura HGVS."
  }]
}

```
