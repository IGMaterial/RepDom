# Resultados oncológicos - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Resultados oncológicos**

## CodeSystem: Resultados oncológicos 

| | |
| :--- | :--- |
| *Official URL*:https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSResultadosOncoDO | *Version*:0.2.2 |
| Draft as of 2026-11-17 | *Computable Name*:CSResultadosOncoDO |

 
Códigos locales para valores cualitativos de patología, estadificación y riesgo. 

 This Code system is referenced in the content logical definition of the following value sets: 

* [Grupo de estadio](ValueSet-VSEstadioDO.md)
* [Grado histológico](ValueSet-VSGradoHistologicoDO.md)
* [HER2](ValueSet-VSHER2DO.md)
* [Receptor de estrógeno](ValueSet-VSReceptorEstrogenoDO.md)
* [Receptor de progesterona](ValueSet-VSReceptorProgesteronaDO.md)
* [Grupo de riesgo infantil](ValueSet-VSRiesgoInfantilDO.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "CSResultadosOncoDO",
  "url" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSResultadosOncoDO",
  "version" : "0.2.2",
  "name" : "CSResultadosOncoDO",
  "title" : "Resultados oncológicos",
  "status" : "draft",
  "experimental" : false,
  "date" : "2026-11-17T15:46:26-03:00",
  "publisher" : "Ministerio de Salud Pública y Asistencia Social",
  "contact" : [{
    "name" : "Ministerio de Salud Pública y Asistencia Social",
    "telecom" : [{
      "system" : "url",
      "value" : "https://msp.gob.do"
    }]
  }],
  "description" : "Códigos locales para valores cualitativos de patología, estadificación y riesgo.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DO",
      "display" : "Dominican Republic"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 21,
  "concept" : [{
    "code" : "G1",
    "display" : "Grado 1",
    "definition" : "Bien diferenciado."
  },
  {
    "code" : "G2",
    "display" : "Grado 2",
    "definition" : "Moderadamente diferenciado."
  },
  {
    "code" : "G3",
    "display" : "Grado 3",
    "definition" : "Poco diferenciado."
  },
  {
    "code" : "G4",
    "display" : "Grado 4",
    "definition" : "Indiferenciado."
  },
  {
    "code" : "GX",
    "display" : "Grado X",
    "definition" : "Grado no evaluable."
  },
  {
    "code" : "re-positivo",
    "display" : "Receptor de estrógeno positivo",
    "definition" : "Receptor de estrógeno positivo."
  },
  {
    "code" : "re-negativo",
    "display" : "Receptor de estrógeno negativo",
    "definition" : "Receptor de estrógeno negativo."
  },
  {
    "code" : "rp-positivo",
    "display" : "Receptor de progesterona positivo",
    "definition" : "Receptor de progesterona positivo."
  },
  {
    "code" : "rp-negativo",
    "display" : "Receptor de progesterona negativo",
    "definition" : "Receptor de progesterona negativo."
  },
  {
    "code" : "her2-positivo",
    "display" : "HER2 positivo",
    "definition" : "HER2 positivo."
  },
  {
    "code" : "her2-negativo",
    "display" : "HER2 negativo",
    "definition" : "HER2 negativo."
  },
  {
    "code" : "her2-equivoco",
    "display" : "HER2 equívoco",
    "definition" : "HER2 equívoco."
  },
  {
    "code" : "estadio-0",
    "display" : "Estadio 0",
    "definition" : "Estadio 0."
  },
  {
    "code" : "estadio-I",
    "display" : "Estadio I",
    "definition" : "Estadio I."
  },
  {
    "code" : "estadio-II",
    "display" : "Estadio II",
    "definition" : "Estadio II."
  },
  {
    "code" : "estadio-III",
    "display" : "Estadio III",
    "definition" : "Estadio III."
  },
  {
    "code" : "estadio-IV",
    "display" : "Estadio IV",
    "definition" : "Estadio IV."
  },
  {
    "code" : "estadio-desconocido",
    "display" : "Estadio desconocido",
    "definition" : "Estadio no determinado."
  },
  {
    "code" : "riesgo-bajo",
    "display" : "Riesgo bajo",
    "definition" : "Riesgo bajo."
  },
  {
    "code" : "riesgo-intermedio",
    "display" : "Riesgo intermedio",
    "definition" : "Riesgo intermedio."
  },
  {
    "code" : "riesgo-alto",
    "display" : "Riesgo alto",
    "definition" : "Riesgo alto."
  }]
}

```
