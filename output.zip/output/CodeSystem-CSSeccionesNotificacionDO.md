# Secciones de notificación epidemiológica - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Secciones de notificación epidemiológica**

## CodeSystem: Secciones de notificación epidemiológica (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSSeccionesNotificacionDO | *Version*:0.2.2 |
| Draft as of 2026-11-17 | *Computable Name*:CSSeccionesNotificacionDO |

 
Códigos locales propuestos para organizar la notificación individual. 

 This Code system is referenced in the content logical definition of the following value sets: 

* This CodeSystem is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "CSSeccionesNotificacionDO",
  "url" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSSeccionesNotificacionDO",
  "version" : "0.2.2",
  "name" : "CSSeccionesNotificacionDO",
  "title" : "Secciones de notificación epidemiológica",
  "status" : "draft",
  "experimental" : true,
  "date" : "2026-11-17T15:46:26-03:00",
  "publisher" : "Ministerio de Salud Pública y Asistencia Social",
  "contact" : [{
    "name" : "Ministerio de Salud Pública y Asistencia Social",
    "telecom" : [{
      "system" : "url",
      "value" : "https://msp.gob.do"
    }]
  }],
  "description" : "Códigos locales propuestos para organizar la notificación individual.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DO",
      "display" : "Dominican Republic"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 5,
  "concept" : [{
    "code" : "evento",
    "display" : "Evento epidemiológico"
  },
  {
    "code" : "observaciones",
    "display" : "Observaciones"
  },
  {
    "code" : "laboratorio",
    "display" : "Laboratorio"
  },
  {
    "code" : "conclusion",
    "display" : "Conclusión del caso"
  },
  {
    "code" : "documento-pdf",
    "display" : "Documento completo PDF"
  }]
}

```
