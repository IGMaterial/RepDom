# Secciones del documento oncológico - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Secciones del documento oncológico**

## CodeSystem: Secciones del documento oncológico 

| | |
| :--- | :--- |
| *Official URL*:https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSSeccionesOncoDO | *Version*:0.2.2 |
| Draft as of 2026-11-17 | *Computable Name*:CSSeccionesOncoDO |

 
Códigos locales para las secciones del documento oncológico que no tienen un código LOINC acordado. 

 This Code system is referenced in the content logical definition of the following value sets: 

* This CodeSystem is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "CSSeccionesOncoDO",
  "url" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSSeccionesOncoDO",
  "version" : "0.2.2",
  "name" : "CSSeccionesOncoDO",
  "title" : "Secciones del documento oncológico",
  "status" : "draft",
  "experimental" : false,
  "date" : "2026-11-17T15:46:26-03:00",
  "publisher" : "Ministerio de Salud Pública y Asistencia Social",
  "contact" : [{
    "name" : "Ministerio de Salud Pública y Asistencia Social",
    "telecom" : [{
      "system" : "url",
      "value" : "https://msp.gob.do"
    }]
  }],
  "description" : "Códigos locales para las secciones del documento oncológico que no tienen un código LOINC acordado.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DO",
      "display" : "Dominican Republic"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 2,
  "concept" : [{
    "code" : "diagnostico",
    "display" : "Diagnóstico de cáncer primario",
    "definition" : "Sección con la condición de cáncer primario del caso."
  },
  {
    "code" : "estadificacion",
    "display" : "Estadificación y riesgo",
    "definition" : "Sección con la estadificación y la clasificación de riesgo."
  }]
}

```
