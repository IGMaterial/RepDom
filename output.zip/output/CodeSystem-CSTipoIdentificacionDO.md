# Tipo de Identificación DO - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Tipo de Identificación DO**

## CodeSystem: Tipo de Identificación DO 

| | |
| :--- | :--- |
| *Official URL*:https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSIdentificadoresPersona | *Version*:0.2.2 |
| Draft as of 2026-11-17 | *Computable Name*:CSTipoIdentificacionDO |

 
Tipos de documentos de identificación usados en República Dominicana o por la implementación nacional. 

 This Code system is referenced in the content logical definition of the following value sets: 

* [Identificadores de Paciente](ValueSet-VSTipoIdentifPacDO.md)
* [Identificadores de Profesional](ValueSet-VSTipoIdentifProfDO.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "CSTipoIdentificacionDO",
  "url" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSIdentificadoresPersona",
  "version" : "0.2.2",
  "name" : "CSTipoIdentificacionDO",
  "title" : "Tipo de Identificación DO",
  "status" : "draft",
  "date" : "2026-11-17T15:46:26-03:00",
  "publisher" : "Ministerio de Salud Pública y Asistencia Social",
  "contact" : [{
    "name" : "Ministerio de Salud Pública y Asistencia Social",
    "telecom" : [{
      "system" : "url",
      "value" : "https://msp.gob.do"
    }]
  }],
  "description" : "Tipos de documentos de identificación usados en República Dominicana o por la implementación nacional.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DO",
      "display" : "Dominican Republic"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 6,
  "concept" : [{
    "code" : "CED",
    "display" : "Cédula",
    "definition" : "Cédula de identidad y electoral."
  },
  {
    "code" : "PAS",
    "display" : "Pasaporte",
    "definition" : "Pasaporte."
  },
  {
    "code" : "NSS",
    "display" : "Número de Seguridad Social",
    "definition" : "Número de seguridad social."
  },
  {
    "code" : "RN",
    "display" : "Registro Nacional",
    "definition" : "Identificador nacional o institucional."
  },
  {
    "code" : "MR",
    "display" : "Record médico",
    "definition" : "Número de expediente o record médico."
  },
  {
    "code" : "EX",
    "display" : "Exequátur",
    "definition" : "Exequátur de profesional de la salud."
  }]
}

```
