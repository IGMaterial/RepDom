# Ejemplo de CompositionDO - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Ejemplo de CompositionDO**

## Example Composition: Ejemplo de CompositionDO

Perfil: [Documento Clínico DO](StructureDefinition-CompositionDO.md)

**status**: Final

**type**: Patient summary Document

**date**: 2026-08-19

**author**: `PractitionerDO/PractitionerDOExample`

**title**: Resumen clínico del paciente

**custodian**: `OrganizationDO/OrganizationDOExample`



## Resource Content

```json
{
  "resourceType" : "Composition",
  "id" : "CompositionDOExample",
  "meta" : {
    "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/CompositionDO"]
  },
  "status" : "final",
  "type" : {
    "coding" : [{
      "system" : "http://loinc.org",
      "code" : "60591-5",
      "display" : "Patient summary Document"
    }]
  },
  "subject" : {
    "reference" : "PatientDO/PatientDOExample"
  },
  "date" : "2026-08-19",
  "author" : [{
    "reference" : "PractitionerDO/PractitionerDOExample"
  }],
  "title" : "Resumen clínico del paciente",
  "custodian" : {
    "reference" : "OrganizationDO/OrganizationDOExample"
  },
  "section" : [{
    "title" : "Condiciones del Paciente",
    "code" : {
      "coding" : [{
        "system" : "http://loinc.org",
        "code" : "11450-4",
        "display" : "Problem list Reported"
      }]
    },
    "text" : {
      "status" : "generated",
      "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">CONDICIONES</div>"
    },
    "entry" : [{
      "reference" : "Condition/ConditionDOEjemplo"
    }]
  },
  {
    "title" : "Medicamentos",
    "code" : {
      "coding" : [{
        "system" : "http://loinc.org",
        "code" : "10160-0",
        "display" : "Hx of Medication use"
      }]
    },
    "text" : {
      "status" : "generated",
      "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">MEDICAMENTOS</div>"
    },
    "entry" : [{
      "reference" : "MedicationStatement/MedicationStatementDOEjemplo"
    }]
  },
  {
    "title" : "Alergias",
    "code" : {
      "coding" : [{
        "system" : "http://loinc.org",
        "code" : "48765-2",
        "display" : "Allergies and adverse reactions Document."
      }]
    },
    "text" : {
      "status" : "generated",
      "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">ALERGIAS</div>"
    },
    "entry" : [{
      "reference" : "AllergyIntolerance/AllergyIntoleranceDOExample"
    }]
  }]
}

```
