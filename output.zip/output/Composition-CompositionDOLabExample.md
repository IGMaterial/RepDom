# Documento de laboratorio de ejemplo - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Documento de laboratorio de ejemplo**

## Example Composition: Documento de laboratorio de ejemplo

Perfil: [Documento Clínico Laboratorio](StructureDefinition-CompositionDOLab.md)

**status**: Final

**type**: Laboratory report

**date**: 2026-08-19 10:00:00-0400

**author**: [Centro de Salud DO Ejemplo (Healthcare Provider) (https://digital.msp.gob.do/identifiers/organization#ORG-001)](Organization-OrganizationDOExample.md)

**title**: Informe de laboratorio sintetico

**custodian**: [Centro de Salud DO Ejemplo (Healthcare Provider) (https://digital.msp.gob.do/identifiers/organization#ORG-001)](Organization-OrganizationDOExample.md)



## Resource Content

```json
{
  "resourceType" : "Composition",
  "id" : "CompositionDOLabExample",
  "meta" : {
    "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/CompositionDOLab"]
  },
  "status" : "final",
  "type" : {
    "coding" : [{
      "system" : "http://loinc.org",
      "code" : "11502-2",
      "display" : "Laboratory report"
    }]
  },
  "subject" : {
    "reference" : "Patient/PatientDOExample"
  },
  "date" : "2026-08-19T10:00:00-04:00",
  "author" : [{
    "reference" : "Organization/OrganizationDOExample"
  }],
  "title" : "Informe de laboratorio sintetico",
  "custodian" : {
    "reference" : "Organization/OrganizationDOExample"
  },
  "section" : [{
    "title" : "Informe de laboratorio",
    "code" : {
      "coding" : [{
        "system" : "http://loinc.org",
        "code" : "11502-2",
        "display" : "Laboratory report"
      }]
    },
    "text" : {
      "status" : "generated",
      "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">Informe final sintetico de laboratorio. Ver DiagnosticReportDOExample.</div>"
    },
    "entry" : [{
      "reference" : "DiagnosticReport/DiagnosticReportDOExample"
    }]
  },
  {
    "title" : "Documento PDF",
    "code" : {
      "coding" : [{
        "system" : "http://loinc.org",
        "code" : "99999-9"
      }]
    },
    "text" : {
      "status" : "generated",
      "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">Metadatos del PDF de ejemplo. El contenido binario no se incluye.</div>"
    },
    "entry" : [{
      "reference" : "Binary/BinaryDOLabExample"
    }]
  }]
}

```
