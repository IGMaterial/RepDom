# Notificación individual de caso de dengue - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Notificación individual de caso de dengue**

## Example Composition: Notificación individual de caso de dengue

Perfil: [Documento Clínico Notificación de Caso](StructureDefinition-CompositionDONotif.md)

**status**: Final

**type**: Case notification panel

**date**: 2026-10-26 10:00:00-0400

**author**: [Centro de Salud DO Ejemplo (Healthcare Provider) (https://digital.msp.gob.do/identifiers/organization#ORG-001)](Organization-OrganizationDOExample.md)

**title**: Notificación individual de caso confirmado de dengue

**custodian**: [Centro de Salud DO Ejemplo (Healthcare Provider) (https://digital.msp.gob.do/identifiers/organization#ORG-001)](Organization-OrganizationDOExample.md)



## Resource Content

```json
{
  "resourceType" : "Composition",
  "id" : "CompositionDONotifExample",
  "meta" : {
    "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/CompositionDONotif"]
  },
  "status" : "final",
  "type" : {
    "coding" : [{
      "system" : "http://loinc.org",
      "code" : "68991-9",
      "display" : "Case notification panel"
    }]
  },
  "subject" : {
    "reference" : "Patient/PatientDOExample"
  },
  "date" : "2026-10-26T10:00:00-04:00",
  "author" : [{
    "reference" : "Organization/OrganizationDOExample"
  }],
  "title" : "Notificación individual de caso confirmado de dengue",
  "custodian" : {
    "reference" : "Organization/OrganizationDOExample"
  },
  "section" : [{
    "title" : "Datos de la enfermedad",
    "code" : {
      "coding" : [{
        "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSSeccionesNotificacionDO",
        "code" : "evento"
      }]
    },
    "text" : {
      "status" : "generated",
      "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">Caso confirmado de dengue.</div>"
    },
    "entry" : [{
      "reference" : "Condition/ConditionCasoEpidemiologicoDOExample"
    }]
  },
  {
    "title" : "Signos y síntomas",
    "code" : {
      "coding" : [{
        "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSSeccionesNotificacionDO",
        "code" : "observaciones"
      }]
    },
    "text" : {
      "status" : "generated",
      "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">Fiebre y cefalea de inicio reciente.</div>"
    },
    "entry" : [{
      "reference" : "Observation/ObservationSignoSintomaDOExample"
    }]
  },
  {
    "title" : "Estado de embarazo",
    "code" : {
      "coding" : [{
        "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSSeccionesNotificacionDO",
        "code" : "observaciones"
      }]
    },
    "text" : {
      "status" : "generated",
      "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">Embarazo de 18 semanas.</div>"
    },
    "entry" : [{
      "reference" : "Observation/ObservationEstadoEmbarazoDOExample"
    }]
  },
  {
    "title" : "Viajes y exposición",
    "code" : {
      "coding" : [{
        "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSSeccionesNotificacionDO",
        "code" : "observaciones"
      }]
    },
    "text" : {
      "status" : "generated",
      "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">Antecedente de viaje y exposición a picaduras de mosquitos.</div>"
    },
    "entry" : [{
      "reference" : "Observation/ObservationViajesExposicionDOExample"
    }]
  },
  {
    "title" : "Conclusión epidemiológica",
    "code" : {
      "coding" : [{
        "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSSeccionesNotificacionDO",
        "code" : "conclusion"
      }]
    },
    "text" : {
      "status" : "generated",
      "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">Caso confirmado de dengue.</div>"
    },
    "entry" : [{
      "reference" : "Condition/ConditionConclusionDOExample"
    }]
  }]
}

```
