# Documento oncológico de ejemplo - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Documento oncológico de ejemplo**

## Example Composition: Documento oncológico de ejemplo

Perfil: [Documento Clínico Oncologico](StructureDefinition-CompositionDOOnco.md)

**status**: Final

**type**: Oncology Clinical Document

**date**: 2026-09-15 10:00:00-0400

**author**: [Centro de Salud DO Ejemplo (Healthcare Provider) (https://digital.msp.gob.do/identifiers/organization#ORG-001)](Organization-OrganizationDOExample.md)

**title**: Notificación de caso al Registro Nacional de Cáncer

**custodian**: [Centro de Salud DO Ejemplo (Healthcare Provider) (https://digital.msp.gob.do/identifiers/organization#ORG-001)](Organization-OrganizationDOExample.md)



## Resource Content

```json
{
  "resourceType" : "Composition",
  "id" : "CompositionDOOncoExample",
  "meta" : {
    "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/CompositionDOOnco"]
  },
  "status" : "final",
  "type" : {
    "coding" : [{
      "system" : "http://loinc.org",
      "code" : "115562-1",
      "display" : "Oncology Clinical Document"
    }]
  },
  "subject" : {
    "reference" : "Patient/PatientDOExample"
  },
  "date" : "2026-09-15T10:00:00-04:00",
  "author" : [{
    "reference" : "Organization/OrganizationDOExample"
  }],
  "title" : "Notificación de caso al Registro Nacional de Cáncer",
  "custodian" : {
    "reference" : "Organization/OrganizationDOExample"
  },
  "section" : [{
    "title" : "Diagnóstico",
    "code" : {
      "coding" : [{
        "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSSeccionesOncoDO",
        "code" : "diagnostico",
        "display" : "Diagnóstico de cáncer primario"
      }]
    },
    "text" : {
      "status" : "generated",
      "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">Carcinoma ductal infiltrante de mama izquierda (C50.4, 8500/3).</div>"
    },
    "entry" : [{
      "reference" : "Condition/PrimaryCancerConditionDOExample"
    }]
  },
  {
    "title" : "Patología y biomarcadores",
    "code" : {
      "coding" : [{
        "system" : "http://loinc.org",
        "code" : "30954-2",
        "display" : "Relevant diagnostic tests/laboratory data Narrative"
      }]
    },
    "text" : {
      "status" : "generated",
      "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">Grado 2. RE positivo, RP positivo, HER2 negativo. Variante PIK3CA.</div>"
    },
    "entry" : [{
      "reference" : "DiagnosticReport/PathologyReportDOExample"
    }]
  },
  {
    "title" : "Estadificación",
    "code" : {
      "coding" : [{
        "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSSeccionesOncoDO",
        "code" : "estadificacion",
        "display" : "Estadificación y riesgo"
      }]
    },
    "text" : {
      "status" : "generated",
      "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">Estadio II (AJCC TNM 8.ª edición).</div>"
    },
    "entry" : [{
      "reference" : "Observation/CancerStageDOExample"
    }]
  },
  {
    "title" : "Tratamientos",
    "code" : {
      "coding" : [{
        "system" : "http://loinc.org",
        "code" : "47519-4",
        "display" : "History of Procedures Document"
      }]
    },
    "text" : {
      "status" : "generated",
      "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">Mastectomía parcial. Hormonoterapia con tamoxifeno.</div>"
    },
    "entry" : [{
      "reference" : "Procedure/SurgicalProcedureDOExample"
    },
    {
      "reference" : "MedicationStatement/CancerMedicationStatementDOExample"
    }]
  }]
}

```
