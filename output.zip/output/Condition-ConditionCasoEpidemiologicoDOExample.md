# Caso epidemiológico de dengue - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Caso epidemiológico de dengue**

## Example Condition: Caso epidemiológico de dengue

Perfil: [Caso epidemiológico DO](StructureDefinition-ConditionCasoEpidemiologicoDO.md)

**clinicalStatus**: active

**verificationStatus**: confirmed

**category**: Evento epidemiológico

**code**: Dengue

**subject**: [María Pérez Female, DoB: 1990-05-15 ( Cédula: 00000000000)](Patient-PatientDOExample.md)

**onset**: 2026-10-25

**recordedDate**: 2026-10-26

> **evidence****detail**: 
* [Observation Fever](Observation-ObservationSignoSintomaDOExample.md)
* [Observation Pregnancy status](Observation-ObservationEstadoEmbarazoDOExample.md)
* [Observation Travel history](Observation-ObservationViajesExposicionDOExample.md)

**note**: 

> 

Caso sintético; datos utilizados únicamente con fines de ejemplo.




## Resource Content

```json
{
  "resourceType" : "Condition",
  "id" : "ConditionCasoEpidemiologicoDOExample",
  "meta" : {
    "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/ConditionCasoEpidemiologicoDO"]
  },
  "clinicalStatus" : {
    "coding" : [{
      "code" : "active"
    }]
  },
  "verificationStatus" : {
    "coding" : [{
      "code" : "confirmed"
    }]
  },
  "category" : [{
    "coding" : [{
      "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSCategoriaNotificacionDO",
      "code" : "evento-epidemiologico"
    }]
  }],
  "code" : {
    "coding" : [{
      "system" : "http://hl7.org/fhir/sid/icd-10",
      "code" : "A90",
      "display" : "Dengue"
    }]
  },
  "subject" : {
    "reference" : "Patient/PatientDOExample"
  },
  "onsetDateTime" : "2026-10-25",
  "recordedDate" : "2026-10-26",
  "evidence" : [{
    "detail" : [{
      "reference" : "Observation/ObservationSignoSintomaDOExample"
    },
    {
      "reference" : "Observation/ObservationEstadoEmbarazoDOExample"
    },
    {
      "reference" : "Observation/ObservationViajesExposicionDOExample"
    }]
  }],
  "note" : [{
    "text" : "Caso sintético; datos utilizados únicamente con fines de ejemplo."
  }]
}

```
