# Conclusión epidemiológica de dengue - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Conclusión epidemiológica de dengue**

## Example Condition: Conclusión epidemiológica de dengue

Perfil: [Conclusión epidemiológica DO](StructureDefinition-ConditionConclusionDO.md)

**clinicalStatus**: active

**verificationStatus**: confirmed

**category**: Conclusión epidemiológica

**code**: Dengue

**subject**: [María Pérez Female, DoB: 1990-05-15 ( Cédula: 00000000000)](Patient-PatientDOExample.md)

**recordedDate**: 2026-10-26

**note**: 

> 

Caso confirmado de dengue. Se recomienda seguimiento clínico estrecho por embarazo.




## Resource Content

```json
{
  "resourceType" : "Condition",
  "id" : "ConditionConclusionDOExample",
  "meta" : {
    "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/ConditionConclusionDO"]
  },
  "clinicalStatus" : {
    "coding" : [{
      "code" : "active"
    }]
  },
  "verificationStatus" : {
    "coding" : [{
      "code" : "confirmed"
    }]
  },
  "category" : [{
    "coding" : [{
      "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSCategoriaNotificacionDO",
      "code" : "conclusion-epidemiologica"
    }]
  }],
  "code" : {
    "coding" : [{
      "system" : "http://hl7.org/fhir/sid/icd-10",
      "code" : "A90",
      "display" : "Dengue"
    }]
  },
  "subject" : {
    "reference" : "Patient/PatientDOExample"
  },
  "recordedDate" : "2026-10-26",
  "note" : [{
    "text" : "Caso confirmado de dengue. Se recomienda seguimiento clínico estrecho por embarazo."
  }]
}

```
