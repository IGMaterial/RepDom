# Ejemplo de ConditionDO - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Ejemplo de ConditionDO**

## Example Condition: Ejemplo de ConditionDO

Perfil: [Condición DO](StructureDefinition-ConditionDO.md)

**clinicalStatus**: active

**verificationStatus**: confirmed

**severity**: Moderate

**code**: Clinical finding

**subject**: `PatientDO/PatientDOExample`

**onset**: 2026-08-10

**recordedDate**: 2026-08-10

**recorder**: `PractitionerDO/PractitionerDOExample`

**note**: 

> 

Paciente con diagnóstico registrado en consulta.




## Resource Content

```json
{
  "resourceType" : "Condition",
  "id" : "ConditionDOEjemplo",
  "meta" : {
    "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/ConditionDO"]
  },
  "clinicalStatus" : {
    "coding" : [{
      "code" : "active"
    }]
  },
  "verificationStatus" : {
    "coding" : [{
      "code" : "confirmed"
    }]
  },
  "severity" : {
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "code" : "6736007",
      "display" : "Moderate"
    }]
  },
  "code" : {
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "code" : "404684003",
      "display" : "Clinical finding"
    }]
  },
  "subject" : {
    "reference" : "PatientDO/PatientDOExample"
  },
  "onsetDateTime" : "2026-08-10",
  "recordedDate" : "2026-08-10",
  "recorder" : {
    "reference" : "PractitionerDO/PractitionerDOExample"
  },
  "note" : [{
    "text" : "Paciente con diagnóstico registrado en consulta."
  }]
}

```
