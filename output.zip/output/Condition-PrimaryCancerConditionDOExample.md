# Cáncer primario de ejemplo - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Cáncer primario de ejemplo**

## Example Condition: Cáncer primario de ejemplo

Perfil: [Cáncer Primario DO](StructureDefinition-PrimaryCancerConditionDO.md)

**Morfología y comportamiento histológico DO**: Carcinoma ductal infiltrante, SAI

**clinicalStatus**: Active

**verificationStatus**: Confirmed

**category**: Problem List Item

**code**: Neoplasia maligna del cuadrante superior externo de la mama

**bodySite**: Cuadrante superior externo de la mama

**subject**: [María Pérez Female, DoB: 1990-05-15 ( Cédula: 00000000000)](Patient-PatientDOExample.md)

**onset**: 2026-07-20

**recordedDate**: 2026-07-28

### Evidences

| | |
| :--- | :--- |
| - | **Detail** |
| * | [Diagnostic Report for 'Pathology study' for '->María Pérez Female, DoB: 1990-05-15 ( Cédula: 00000000000)'](DiagnosticReport-PathologyReportDOExample.md) |



## Resource Content

```json
{
  "resourceType" : "Condition",
  "id" : "PrimaryCancerConditionDOExample",
  "meta" : {
    "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/PrimaryCancerConditionDO"]
  },
  "extension" : [{
    "url" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/HistologyMorphologyBehaviorDO",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/icd-o-3",
        "code" : "8500/3",
        "display" : "Carcinoma ductal infiltrante, SAI"
      }]
    }
  }],
  "clinicalStatus" : {
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/condition-clinical",
      "code" : "active"
    }]
  },
  "verificationStatus" : {
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/condition-ver-status",
      "code" : "confirmed"
    }]
  },
  "category" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/condition-category",
      "code" : "problem-list-item"
    }]
  }],
  "code" : {
    "coding" : [{
      "system" : "http://hl7.org/fhir/sid/icd-10",
      "code" : "C50.4",
      "display" : "Neoplasia maligna del cuadrante superior externo de la mama"
    }]
  },
  "bodySite" : [{
    "extension" : [{
      "url" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/LateralidadDO",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "7771000",
          "display" : "Left"
        }]
      }
    }],
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/icd-o-3",
      "code" : "C50.4",
      "display" : "Cuadrante superior externo de la mama"
    }]
  }],
  "subject" : {
    "reference" : "Patient/PatientDOExample"
  },
  "onsetDateTime" : "2026-07-20",
  "recordedDate" : "2026-07-28",
  "evidence" : [{
    "detail" : [{
      "reference" : "DiagnosticReport/PathologyReportDOExample"
    }]
  }]
}

```
