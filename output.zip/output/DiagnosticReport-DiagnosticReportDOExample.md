# Informe de laboratorio de ejemplo - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Informe de laboratorio de ejemplo**

## Example DiagnosticReport: Informe de laboratorio de ejemplo

Perfil: [DiagnosticReportDO](StructureDefinition-DiagnosticReportDO.md)

### Laboratory report 

| | |
| :--- | :--- |
| Asunto | María Pérez Female, DoB: 1990-05-15 ( Cédula: 00000000000) |
| Relevant Time | 2026-08-19 09:00:00-0400 |
| Reported | 2026-08-19 10:00:00-0400 |
| Performer | [Centro de Salud DO Ejemplo (Healthcare Provider) (https://digital.msp.gob.do/identifiers/organization#ORG-001)](Organization-OrganizationDOExample.md) |
| Presented Form | application/pdf @[https://example.org/fhir/Binary/BinaryDOLabExample ![](external.png)](https://example.org/fhir/Binary/BinaryDOLabExample) |

**Report Details**



## Resource Content

```json
{
  "resourceType" : "DiagnosticReport",
  "id" : "DiagnosticReportDOExample",
  "meta" : {
    "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/DiagnosticReportDO"]
  },
  "status" : "final",
  "code" : {
    "coding" : [{
      "system" : "http://loinc.org",
      "code" : "11502-2",
      "display" : "Laboratory report"
    }]
  },
  "subject" : {
    "reference" : "Patient/PatientDOExample"
  },
  "effectiveDateTime" : "2026-08-19T09:00:00-04:00",
  "issued" : "2026-08-19T10:00:00-04:00",
  "performer" : [{
    "reference" : "Organization/OrganizationDOExample"
  }],
  "presentedForm" : [{
    "contentType" : "application/pdf",
    "language" : "es",
    "url" : "https://example.org/fhir/Binary/BinaryDOLabExample",
    "title" : "Informe de laboratorio sintetico",
    "creation" : "2026-08-19T10:00:00-04:00"
  }]
}

```
