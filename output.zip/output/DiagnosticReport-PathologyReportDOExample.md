# Informe de patología de ejemplo - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Informe de patología de ejemplo**

## Example DiagnosticReport: Informe de patología de ejemplo

Perfil: [Informe de Patología DO](StructureDefinition-PathologyReportDO.md)

### Pathology study 

| | |
| :--- | :--- |
| Asunto | María Pérez Female, DoB: 1990-05-15 ( Cédula: 00000000000) |
| Relevant Time | 2026-07-15 |
| Reported | 2026-07-20 12:00:00-0400 |
| Performer | [Centro de Salud DO Ejemplo (Healthcare Provider) (https://digital.msp.gob.do/identifiers/organization#ORG-001)](Organization-OrganizationDOExample.md) |

**Report Details**

* **Code**: [Variante genómica](Observation-PathologyResultDOExample.md)
  * **Valor**: 
  * **Flags**: Final

Carcinoma ductal infiltrante, grado 2. RE positivo, RP positivo, HER2 negativo.

**Coded Conclusions:**

* Grado 2
* Receptor de estrógeno positivo
* Receptor de progesterona positivo
* HER2 negativo



## Resource Content

```json
{
  "resourceType" : "DiagnosticReport",
  "id" : "PathologyReportDOExample",
  "meta" : {
    "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/PathologyReportDO"]
  },
  "status" : "final",
  "code" : {
    "coding" : [{
      "system" : "http://loinc.org",
      "code" : "11526-1",
      "display" : "Pathology study"
    }]
  },
  "subject" : {
    "reference" : "Patient/PatientDOExample"
  },
  "effectiveDateTime" : "2026-07-15",
  "issued" : "2026-07-20T12:00:00-04:00",
  "performer" : [{
    "reference" : "Organization/OrganizationDOExample"
  }],
  "result" : [{
    "reference" : "Observation/PathologyResultDOExample"
  }],
  "conclusion" : "Carcinoma ductal infiltrante, grado 2. RE positivo, RP positivo, HER2 negativo.",
  "conclusionCode" : [{
    "coding" : [{
      "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSResultadosOncoDO",
      "code" : "G2",
      "display" : "Grado 2"
    }]
  },
  {
    "coding" : [{
      "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSResultadosOncoDO",
      "code" : "re-positivo",
      "display" : "Receptor de estrógeno positivo"
    }]
  },
  {
    "coding" : [{
      "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSResultadosOncoDO",
      "code" : "rp-positivo",
      "display" : "Receptor de progesterona positivo"
    }]
  },
  {
    "coding" : [{
      "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSResultadosOncoDO",
      "code" : "her2-negativo",
      "display" : "HER2 negativo"
    }]
  }]
}

```
