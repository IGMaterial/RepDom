# Ejemplo de DocumentReferenceDO - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Ejemplo de DocumentReferenceDO**

## Example DocumentReference: Ejemplo de DocumentReferenceDO

Perfil: [DocumentReferenceDO](StructureDefinition-DocumentReferenceDO.md)

**masterIdentifier**: [Uniform Resource Identifier (URI)](http://terminology.hl7.org/7.5.0/NamingSystem-uri.html)/urn:uuid:document-reference-do-example

**status**: Current

**type**: Summarization of episode note

**subject**: `PatientDO/PatientDOExample`

**date**: 2026-08-19 10:30:00+0000

**custodian**: `OrganizationDO/OrganizationDOExample`

> **content**

### Attachments

| | | |
| :--- | :--- | :--- |
| - | **ContentType** | **Url** |
| * | application/fhir+json | [Bundle: identifier = UUID:bundle-nps-do-example; type = document; timestamp = 2026-08-19 10:30:00+0000](Bundle-BundleTransaccDOExample.md#urn-uuid-bundle-nps-do-example) |




## Resource Content

```json
{
  "resourceType" : "DocumentReference",
  "id" : "DocumentReferenceDOExample",
  "meta" : {
    "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/DocumentReferenceDO"]
  },
  "masterIdentifier" : {
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:uuid:document-reference-do-example"
  },
  "status" : "current",
  "type" : {
    "coding" : [{
      "system" : "http://loinc.org",
      "code" : "34105-7",
      "display" : "Summarization of episode note"
    }]
  },
  "subject" : {
    "reference" : "PatientDO/PatientDOExample"
  },
  "date" : "2026-08-19T10:30:00Z",
  "custodian" : {
    "reference" : "OrganizationDO/OrganizationDOExample"
  },
  "content" : [{
    "attachment" : {
      "contentType" : "application/fhir+json",
      "url" : "urn:uuid:bundle-nps-do-example"
    }
  }]
}

```
