# Referencia documental de laboratorio de ejemplo - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Referencia documental de laboratorio de ejemplo**

## Example DocumentReference: Referencia documental de laboratorio de ejemplo

Perfil: [DocumentReferenceDOLab](StructureDefinition-DocumentReferenceDOLab.md)

**masterIdentifier**: `https://example.org/identifiers/documentos`/LAB-2026-0001

**status**: Current

**type**: Laboratory report

**subject**: [María Pérez Female, DoB: 1990-05-15 ( Cédula: 00000000000)](Patient-PatientDOExample.md)

**date**: 2026-08-19 10:05:00-0400

**author**: [Centro de Salud DO Ejemplo (Healthcare Provider) (https://digital.msp.gob.do/identifiers/organization#ORG-001)](Organization-OrganizationDOExample.md)

**custodian**: [Centro de Salud DO Ejemplo (Healthcare Provider) (https://digital.msp.gob.do/identifiers/organization#ORG-001)](Organization-OrganizationDOExample.md)

> **content**

### Attachments

| | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- |
| - | **ContentType** | **Language** | **Url** | **Title** | **Creation** |
| * | application/fhir+json | Español | [https://example.org/fhir/Bundle/BundleLabDOExample](https://example.org/fhir/Bundle/BundleLabDOExample) | Documento de laboratorio sintetico | 2026-08-19 10:05:00-0400 |




## Resource Content

```json
{
  "resourceType" : "DocumentReference",
  "id" : "DocumentReferenceDOLabExample",
  "meta" : {
    "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/DocumentReferenceDOLab"]
  },
  "masterIdentifier" : {
    "system" : "https://example.org/identifiers/documentos",
    "value" : "LAB-2026-0001"
  },
  "status" : "current",
  "type" : {
    "coding" : [{
      "system" : "http://loinc.org",
      "code" : "11502-2",
      "display" : "Laboratory report"
    }]
  },
  "subject" : {
    "reference" : "Patient/PatientDOExample"
  },
  "date" : "2026-08-19T10:05:00-04:00",
  "author" : [{
    "reference" : "Organization/OrganizationDOExample"
  }],
  "custodian" : {
    "reference" : "Organization/OrganizationDOExample"
  },
  "content" : [{
    "attachment" : {
      "contentType" : "application/fhir+json",
      "language" : "es",
      "url" : "https://example.org/fhir/Bundle/BundleLabDOExample",
      "title" : "Documento de laboratorio sintetico",
      "creation" : "2026-08-19T10:05:00-04:00"
    }
  }]
}

```
