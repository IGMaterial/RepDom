# Referencia de notificación de dengue - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Referencia de notificación de dengue**

## Example DocumentReference: Referencia de notificación de dengue

Perfil: [DocumentReferenceDONotif](StructureDefinition-DocumentReferenceDONotif.md)

**masterIdentifier**: [Uniform Resource Identifier (URI)](http://terminology.hl7.org/7.5.0/NamingSystem-uri.html)/urn:uuid:document-reference-notif-dengue-example

**status**: Current

**type**: Case notification panel

**subject**: [María Pérez Female, DoB: 1990-05-15 ( Cédula: 00000000000)](Patient-PatientDOExample.md)

**date**: 2026-10-26 10:00:00-0400

**custodian**: [Centro de Salud DO Ejemplo (Healthcare Provider) (https://digital.msp.gob.do/identifiers/organization#ORG-001)](Organization-OrganizationDOExample.md)

> **content**

### Attachments

| | | |
| :--- | :--- | :--- |
| - | **ContentType** | **Url** |
| * | application/fhir+json | urn:uuid:bundle-notif-dengue-example |




## Resource Content

```json
{
  "resourceType" : "DocumentReference",
  "id" : "DocumentReferenceDONotifExample",
  "meta" : {
    "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/DocumentReferenceDONotif"]
  },
  "masterIdentifier" : {
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:uuid:document-reference-notif-dengue-example"
  },
  "status" : "current",
  "type" : {
    "coding" : [{
      "system" : "http://loinc.org",
      "code" : "68991-9",
      "display" : "Case notification panel"
    }]
  },
  "subject" : {
    "reference" : "Patient/PatientDOExample"
  },
  "date" : "2026-10-26T10:00:00-04:00",
  "custodian" : {
    "reference" : "Organization/OrganizationDOExample"
  },
  "content" : [{
    "attachment" : {
      "contentType" : "application/fhir+json",
      "url" : "urn:uuid:bundle-notif-dengue-example"
    }
  }]
}

```
