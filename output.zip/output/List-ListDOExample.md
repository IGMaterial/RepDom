# Ejemplo de ListDO - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Ejemplo de ListDO**

## Example List: Ejemplo de ListDO

Perfil: [ListDO](StructureDefinition-ListDO.md)

| | | | |
| :--- | :--- | :--- | :--- |
| Date: 2026-08-19 10:30:00+0000 | Mode: Working List | Status: Current | Code: SubmissionSet as a FHIR List |
| Asunto:`PatientDO/PatientDOExample` | | | |

* **Items**: `DocumentReferenceDO/DocumentReferenceDOExample`



## Resource Content

```json
{
  "resourceType" : "List",
  "id" : "ListDOExample",
  "meta" : {
    "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/ListDO"]
  },
  "extension" : [{
    "url" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/ihe-sourceId",
    "valueIdentifier" : {
      "value" : "urn:oid:1.2.3.4"
    }
  }],
  "status" : "current",
  "mode" : "working",
  "code" : {
    "coding" : [{
      "system" : "https://profiles.ihe.net/ITI/MHD/CodeSystem/MHDlistTypes",
      "code" : "submissionset"
    }]
  },
  "subject" : {
    "reference" : "PatientDO/PatientDOExample"
  },
  "date" : "2026-08-19T10:30:00Z",
  "entry" : [{
    "item" : {
      "reference" : "DocumentReferenceDO/DocumentReferenceDOExample"
    }
  }]
}

```
