# Tratamiento farmacológico de ejemplo - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Tratamiento farmacológico de ejemplo**

## Example MedicationStatement: Tratamiento farmacológico de ejemplo

Perfil: [Tratamiento Farmacológico Oncológico DO](StructureDefinition-CancerMedicationStatementDO.md)

**status**: Active

**medication**: tamoxifen

**subject**: [María Pérez Female, DoB: 1990-05-15 ( Cédula: 00000000000)](Patient-PatientDOExample.md)

**effective**: 2026-09-01 --> (ongoing)

**dateAsserted**: 2026-09-15

**informationSource**: [Centro de Salud DO Ejemplo (Healthcare Provider) (https://digital.msp.gob.do/identifiers/organization#ORG-001)](Organization-OrganizationDOExample.md)

**reasonReference**: [Condition Neoplasia maligna del cuadrante superior externo de la mama](Condition-PrimaryCancerConditionDOExample.md)

### Dosages

| | |
| :--- | :--- |
| - | **Text** |
| * | 20 mg vía oral una vez al día. |



## Resource Content

```json
{
  "resourceType" : "MedicationStatement",
  "id" : "CancerMedicationStatementDOExample",
  "meta" : {
    "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/CancerMedicationStatementDO"]
  },
  "status" : "active",
  "medicationCodeableConcept" : {
    "coding" : [{
      "system" : "http://www.whocc.no/atc",
      "code" : "L02BA01",
      "display" : "tamoxifen"
    }]
  },
  "subject" : {
    "reference" : "Patient/PatientDOExample"
  },
  "effectivePeriod" : {
    "start" : "2026-09-01"
  },
  "dateAsserted" : "2026-09-15",
  "informationSource" : {
    "reference" : "Organization/OrganizationDOExample"
  },
  "reasonReference" : [{
    "reference" : "Condition/PrimaryCancerConditionDOExample"
  }],
  "dosage" : [{
    "text" : "20 mg vía oral una vez al día."
  }]
}

```
