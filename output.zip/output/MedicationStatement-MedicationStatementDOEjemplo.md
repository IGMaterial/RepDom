# Ejemplo de MedicationStatementDO - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Ejemplo de MedicationStatementDO**

## Example MedicationStatement: Ejemplo de MedicationStatementDO

Perfil: [Historial Farmacológico DO](StructureDefinition-MedicationStatementDO.md)

**status**: Active

**medication**: Amoxicillin 500 mg

**subject**: `PatientDO/PatientDOExample`

**effective**: 2026-08-10

**dateAsserted**: 2026-08-10

**informationSource**: `PractitionerDO/PractitionerDOExample`

**note**: 

> 

Historial farmacológico de antibiótico para infección respiratoria.


> **dosage****text**: Tomar una cápsula cada 8 horas durante 7 días.**route**: PO

### DoseAndRates

| | |
| :--- | :--- |
| - | **Dose[x]** |
| * | 500 mg (Details: UCUM codemg = 'mg') |




## Resource Content

```json
{
  "resourceType" : "MedicationStatement",
  "id" : "MedicationStatementDOEjemplo",
  "meta" : {
    "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/MedicationStatementDO"]
  },
  "status" : "active",
  "medicationCodeableConcept" : {
    "coding" : [{
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1049630",
      "display" : "Amoxicillin 500 mg"
    }]
  },
  "subject" : {
    "reference" : "PatientDO/PatientDOExample"
  },
  "effectiveDateTime" : "2026-08-10",
  "dateAsserted" : "2026-08-10",
  "informationSource" : {
    "reference" : "PractitionerDO/PractitionerDOExample"
  },
  "note" : [{
    "text" : "Historial farmacológico de antibiótico para infección respiratoria."
  }],
  "dosage" : [{
    "text" : "Tomar una cápsula cada 8 horas durante 7 días.",
    "route" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/route-codes",
        "code" : "PO"
      }]
    },
    "doseAndRate" : [{
      "doseQuantity" : {
        "value" : 500,
        "unit" : "mg",
        "system" : "http://unitsofmeasure.org",
        "code" : "mg"
      }
    }]
  }]
}

```
