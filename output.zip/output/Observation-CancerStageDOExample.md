# Estadio de ejemplo - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Estadio de ejemplo**

## Example Observation: Estadio de ejemplo

Perfil: [Estadio del Cáncer DO](StructureDefinition-CancerStageDO.md)

**status**: Final

**code**: Estadio del cáncer

**subject**: [María Pérez Female, DoB: 1990-05-15 ( Cédula: 00000000000)](Patient-PatientDOExample.md)

**focus**: [Condition Neoplasia maligna del cuadrante superior externo de la mama](Condition-PrimaryCancerConditionDOExample.md)

**effective**: 2026-07-25

**performer**: [Centro de Salud DO Ejemplo (Healthcare Provider) (https://digital.msp.gob.do/identifiers/organization#ORG-001)](Organization-OrganizationDOExample.md)

**value**: Estadio II

**method**: AJCC TNM 8.ª edición



## Resource Content

```json
{
  "resourceType" : "Observation",
  "id" : "CancerStageDOExample",
  "meta" : {
    "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/CancerStageDO"]
  },
  "status" : "final",
  "code" : {
    "coding" : [{
      "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSObservacionesOncoDO",
      "code" : "estadio",
      "display" : "Estadio del cáncer"
    }]
  },
  "subject" : {
    "reference" : "Patient/PatientDOExample"
  },
  "focus" : [{
    "reference" : "Condition/PrimaryCancerConditionDOExample"
  }],
  "effectiveDateTime" : "2026-07-25",
  "performer" : [{
    "reference" : "Organization/OrganizationDOExample"
  }],
  "valueCodeableConcept" : {
    "coding" : [{
      "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSResultadosOncoDO",
      "code" : "estadio-II",
      "display" : "Estadio II"
    }]
  },
  "method" : {
    "text" : "AJCC TNM 8.ª edición"
  }
}

```
