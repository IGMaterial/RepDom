# Estado de embarazo en caso de dengue - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Estado de embarazo en caso de dengue**

## Example Observation: Estado de embarazo en caso de dengue

Perfil: [Estado de embarazo DO](StructureDefinition-ObservationEstadoEmbarazoDO.md)

**status**: Final

**code**: Pregnancy status

**subject**: [María Pérez Female, DoB: 1990-05-15 ( Cédula: 00000000000)](Patient-PatientDOExample.md)

**effective**: 2026-10-26 09:00:00-0400

**value**: Pregnant

**note**: 

> 

Paciente con embarazo de 18 semanas referido durante la evaluación epidemiológica.




## Resource Content

```json
{
  "resourceType" : "Observation",
  "id" : "ObservationEstadoEmbarazoDOExample",
  "meta" : {
    "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/ObservationEstadoEmbarazoDO"]
  },
  "status" : "final",
  "code" : {
    "coding" : [{
      "system" : "http://loinc.org",
      "code" : "82810-3",
      "display" : "Pregnancy status"
    }]
  },
  "subject" : {
    "reference" : "Patient/PatientDOExample"
  },
  "effectiveDateTime" : "2026-10-26T09:00:00-04:00",
  "valueCodeableConcept" : {
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "code" : "77386006",
      "display" : "Pregnant"
    }]
  },
  "note" : [{
    "text" : "Paciente con embarazo de 18 semanas referido durante la evaluación epidemiológica."
  }]
}

```
