# Signo y síntoma en caso de dengue - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Signo y síntoma en caso de dengue**

## Example Observation: Signo y síntoma en caso de dengue

Perfil: [Signo o síntoma DO](StructureDefinition-ObservationSignoSintomaDO.md)

**status**: Final

**code**: Fever

**subject**: [María Pérez Female, DoB: 1990-05-15 ( Cédula: 00000000000)](Patient-PatientDOExample.md)

**effective**: 2026-10-25 08:00:00-0400

**value**: Present

**note**: 

> 

La paciente refiere fiebre y cefalea de inicio reciente.




## Resource Content

```json
{
  "resourceType" : "Observation",
  "id" : "ObservationSignoSintomaDOExample",
  "meta" : {
    "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/ObservationSignoSintomaDO"]
  },
  "status" : "final",
  "code" : {
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "code" : "386661006",
      "display" : "Fever"
    }]
  },
  "subject" : {
    "reference" : "Patient/PatientDOExample"
  },
  "effectiveDateTime" : "2026-10-25T08:00:00-04:00",
  "valueCodeableConcept" : {
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "code" : "52101004",
      "display" : "Present"
    }]
  },
  "note" : [{
    "text" : "La paciente refiere fiebre y cefalea de inicio reciente."
  }]
}

```
