# Viaje y exposición en caso de dengue - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Viaje y exposición en caso de dengue**

## Example Observation: Viaje y exposición en caso de dengue

Perfil: [Viajes y exposición DO](StructureDefinition-ObservationViajesExposicionDO.md)

**status**: Final

**code**: Travel history

**subject**: [María Pérez Female, DoB: 1990-05-15 ( Cédula: 00000000000)](Patient-PatientDOExample.md)

**effective**: 2026-10-18 --> 2026-10-24

**value**: Viaje a una zona con transmisión de dengue y exposición a picaduras de mosquitos.

**note**: 

> 

La paciente regresó a Santo Domingo un día antes del inicio de los síntomas.




## Resource Content

```json
{
  "resourceType" : "Observation",
  "id" : "ObservationViajesExposicionDOExample",
  "meta" : {
    "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/ObservationViajesExposicionDO"]
  },
  "status" : "final",
  "code" : {
    "coding" : [{
      "system" : "http://loinc.org",
      "code" : "10180-6",
      "display" : "Travel history"
    }]
  },
  "subject" : {
    "reference" : "Patient/PatientDOExample"
  },
  "effectivePeriod" : {
    "start" : "2026-10-18",
    "end" : "2026-10-24"
  },
  "valueString" : "Viaje a una zona con transmisión de dengue y exposición a picaduras de mosquitos.",
  "note" : [{
    "text" : "La paciente regresó a Santo Domingo un día antes del inicio de los síntomas."
  }]
}

```
