# Variante genómica de ejemplo - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Variante genómica de ejemplo**

## Example Observation: Variante genómica de ejemplo

Perfil: [Resultado de Patología DO](StructureDefinition-PathologyResultDO.md)

**status**: Final

**code**: Variante genómica

**subject**: [María Pérez Female, DoB: 1990-05-15 ( Cédula: 00000000000)](Patient-PatientDOExample.md)

**focus**: [Condition Neoplasia maligna del cuadrante superior externo de la mama](Condition-PrimaryCancerConditionDOExample.md)

**effective**: 2026-07-15

**performer**: [Centro de Salud DO Ejemplo (Healthcare Provider) (https://digital.msp.gob.do/identifiers/organization#ORG-001)](Organization-OrganizationDOExample.md)

> **component****code**: Gen**value**: PIK3CA

> **component****code**: Nomenclatura HGVS**value**: NM_006218.4:c.3140A>G



## Resource Content

```json
{
  "resourceType" : "Observation",
  "id" : "PathologyResultDOExample",
  "meta" : {
    "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/PathologyResultDO"]
  },
  "status" : "final",
  "code" : {
    "coding" : [{
      "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSObservacionesOncoDO",
      "code" : "variante-genomica",
      "display" : "Variante genómica"
    }]
  },
  "subject" : {
    "reference" : "Patient/PatientDOExample"
  },
  "focus" : [{
    "reference" : "Condition/PrimaryCancerConditionDOExample"
  }],
  "effectiveDateTime" : "2026-07-15",
  "performer" : [{
    "reference" : "Organization/OrganizationDOExample"
  }],
  "component" : [{
    "code" : {
      "coding" : [{
        "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSObservacionesOncoDO",
        "code" : "gen"
      }]
    },
    "valueCodeableConcept" : {
      "text" : "PIK3CA"
    }
  },
  {
    "code" : {
      "coding" : [{
        "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSObservacionesOncoDO",
        "code" : "hgvs"
      }]
    },
    "valueCodeableConcept" : {
      "text" : "NM_006218.4:c.3140A>G"
    }
  }]
}

```
