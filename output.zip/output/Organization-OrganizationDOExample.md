# Ejemplo de OrganizationDO - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Ejemplo de OrganizationDO**

## Example Organization: Ejemplo de OrganizationDO

Perfil: [Organización DO](StructureDefinition-OrganizationDO.md)

Centro de Salud DO Ejemplo (Healthcare Provider) (https://digital.msp.gob.do/identifiers/organization#ORG-001)

-------

| | |
| :--- | :--- |
| Active: | true |
| Type: | Healthcare Provider |
| Contact Detail | * [+1-809-555-1234](tel:+1-809-555-1234)
* [contacto@centrosaluddo.do](mailto:contacto@centrosaluddo.do)
* Av. Principal 123 Santo Domingo Distrito Nacional 10101 DO 
 |



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "OrganizationDOExample",
  "meta" : {
    "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/OrganizationDO"]
  },
  "identifier" : [{
    "system" : "https://digital.msp.gob.do/identifiers/organization",
    "value" : "ORG-001"
  }],
  "active" : true,
  "type" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/organization-type",
      "code" : "prov",
      "display" : "Healthcare Provider"
    }]
  }],
  "name" : "Centro de Salud DO Ejemplo",
  "telecom" : [{
    "system" : "phone",
    "value" : "+1-809-555-1234"
  },
  {
    "system" : "email",
    "value" : "contacto@centrosaluddo.do"
  }],
  "address" : [{
    "line" : ["Av. Principal 123"],
    "city" : "Santo Domingo",
    "state" : "Distrito Nacional",
    "postalCode" : "10101",
    "country" : "DO"
  }]
}

```
