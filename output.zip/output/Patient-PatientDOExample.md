# Ejemplo de PatientDO - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Ejemplo de PatientDO**

## Example Patient: Ejemplo de PatientDO

Perfil: [Paciente DO](StructureDefinition-PatientDO.md)

María Pérez Female, DoB: 1990-05-15 ( Cédula: 00000000000)

-------

| | |
| :--- | :--- |
| Contact Detail | * [+1-809-555-6789](tel:+1-809-555-6789)
* [maria.perez@example.do](mailto:maria.perez@example.do)
* Calle Principal 456 Santo Domingo Distrito Nacional 10102 DO 
 |



## Resource Content

```json
{
  "resourceType" : "Patient",
  "id" : "PatientDOExample",
  "meta" : {
    "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/PatientDO"]
  },
  "identifier" : [{
    "type" : {
      "coding" : [{
        "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSIdentificadoresPersona",
        "code" : "CED"
      }]
    },
    "system" : "https://digital.msp.gob.do/fhir/sid/cedula",
    "value" : "00000000000"
  }],
  "name" : [{
    "extension" : [{
      "url" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/SegundoApellidoDO",
      "valueString" : "Gómez"
    }],
    "family" : "Pérez",
    "given" : ["María"]
  }],
  "telecom" : [{
    "system" : "phone",
    "value" : "+1-809-555-6789"
  },
  {
    "system" : "email",
    "value" : "maria.perez@example.do"
  }],
  "gender" : "female",
  "birthDate" : "1990-05-15",
  "address" : [{
    "line" : ["Calle Principal 456"],
    "city" : "Santo Domingo",
    "state" : "Distrito Nacional",
    "postalCode" : "10102",
    "country" : "DO"
  }]
}

```
