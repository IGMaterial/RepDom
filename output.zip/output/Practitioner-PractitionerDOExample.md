# Ejemplo de PractitionerDO - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Ejemplo de PractitionerDO**

## Example Practitioner: Ejemplo de PractitionerDO

Perfil: [Profesional DO](StructureDefinition-PractitionerDO.md)

Laura Rodríguez (PRN: PROF-0001)

-------

| | |
| :--- | :--- |
| Contact Detail | * [+1-809-555-9012](tel:+1-809-555-9012)
* [laura.rodriguez@example.do](mailto:laura.rodriguez@example.do)
* Calle Salud 789 Santiago Santiago 51000 DO 
 |
| Qualification: | Medicina general |



## Resource Content

```json
{
  "resourceType" : "Practitioner",
  "id" : "PractitionerDOExample",
  "meta" : {
    "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/PractitionerDO"]
  },
  "identifier" : [{
    "type" : {
      "coding" : [{
        "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSIdentificadoresPersona",
        "code" : "PRN"
      }]
    },
    "value" : "PROF-0001"
  }],
  "name" : [{
    "extension" : [{
      "url" : "http://digital.msp.gob.do/fhir/StructureDefinition/SegundoApellidoDO",
      "valueString" : "Martínez"
    }],
    "family" : "Rodríguez",
    "given" : ["Laura"]
  }],
  "telecom" : [{
    "system" : "phone",
    "value" : "+1-809-555-9012"
  },
  {
    "system" : "email",
    "value" : "laura.rodriguez@example.do"
  }],
  "address" : [{
    "line" : ["Calle Salud 789"],
    "city" : "Santiago",
    "state" : "Santiago",
    "postalCode" : "51000",
    "country" : "DO"
  }],
  "qualification" : [{
    "code" : {
      "coding" : [{
        "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSEspecialidadesMedicas",
        "code" : "MG",
        "display" : "Medicina general"
      }]
    }
  }]
}

```
