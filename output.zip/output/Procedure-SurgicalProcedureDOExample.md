# Cirugía oncológica de ejemplo - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Cirugía oncológica de ejemplo**

## Example Procedure: Cirugía oncológica de ejemplo

Perfil: [Cirugía Oncológica DO](StructureDefinition-SurgicalProcedureDO.md)

**status**: Completed

**category**: Surgical procedure

**code**: Partial mastectomy

**subject**: [María Pérez Female, DoB: 1990-05-15 ( Cédula: 00000000000)](Patient-PatientDOExample.md)

**performed**: 2026-08-05

### Performers

| | |
| :--- | :--- |
| - | **Actor** |
| * | [Centro de Salud DO Ejemplo (Healthcare Provider) (https://digital.msp.gob.do/identifiers/organization#ORG-001)](Organization-OrganizationDOExample.md) |

**reasonReference**: [Condition Neoplasia maligna del cuadrante superior externo de la mama](Condition-PrimaryCancerConditionDOExample.md)



## Resource Content

```json
{
  "resourceType" : "Procedure",
  "id" : "SurgicalProcedureDOExample",
  "meta" : {
    "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/SurgicalProcedureDO"]
  },
  "status" : "completed",
  "category" : {
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "code" : "387713003",
      "display" : "Surgical procedure"
    }]
  },
  "code" : {
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "code" : "64368001",
      "display" : "Partial mastectomy"
    }]
  },
  "subject" : {
    "reference" : "Patient/PatientDOExample"
  },
  "performedDateTime" : "2026-08-05",
  "performer" : [{
    "actor" : {
      "reference" : "Organization/OrganizationDOExample"
    }
  }],
  "reasonReference" : [{
    "reference" : "Condition/PrimaryCancerConditionDOExample"
  }]
}

```
