# Binario DO - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Binario DO**

## Resource Profile: Binario DO 

| | |
| :--- | :--- |
| *Official URL*:https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/BinaryDO | *Version*:0.2.2 |
| Draft as of 2026-11-17 | *Computable Name*:BinaryDO |

 
Perfil para recursos binarios. 

**Usages:**

* Refer to this Perfil: [Documento Clínico Laboratorio](StructureDefinition-CompositionDOLab.md) and [Documento Clínico Notificación de Caso](StructureDefinition-CompositionDONotif.md)
* Examples for this Perfil: [Binary/BinaryDOLabExample](Binary-BinaryDOLabExample.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/msp.fhir.do|current/StructureDefinition/StructureDefinition-BinaryDO.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-BinaryDO.csv), [Excel](StructureDefinition-BinaryDO.xlsx), [Schematron](StructureDefinition-BinaryDO.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "BinaryDO",
  "url" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/BinaryDO",
  "version" : "0.2.2",
  "name" : "BinaryDO",
  "title" : "Binario DO",
  "status" : "draft",
  "date" : "2026-11-17T15:46:26-03:00",
  "publisher" : "Ministerio de Salud Pública y Asistencia Social",
  "contact" : [{
    "name" : "Ministerio de Salud Pública y Asistencia Social",
    "telecom" : [{
      "system" : "url",
      "value" : "https://msp.gob.do"
    }]
  }],
  "description" : "Perfil para recursos binarios.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DO",
      "display" : "Dominican Republic"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Binary",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Binary",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Binary",
      "path" : "Binary"
    },
    {
      "id" : "Binary.contentType",
      "path" : "Binary.contentType",
      "short" : "Tipo de contenido del recurso binario.",
      "mustSupport" : true
    }]
  }
}

```
