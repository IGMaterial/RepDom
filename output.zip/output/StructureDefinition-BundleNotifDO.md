# Bundle de notificación epidemiológica DO - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Bundle de notificación epidemiológica DO**

## Resource Profile: Bundle de notificación epidemiológica DO 

| | |
| :--- | :--- |
| *Official URL*:https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/BundleNotifDO | *Version*:0.2.2 |
| Draft as of 2026-11-17 | *Computable Name*:BundleNotifDO |

 
Documento de notificación individual con la Composition como primera entrada y los recursos referenciados incluidos. 

**Usages:**

* Use this Perfil: [BundleTransaccDO](StructureDefinition-BundleTransaccDO.md)
* Examples for this Perfil: [Bundle/BundleNotifDOExample](Bundle-BundleNotifDOExample.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/msp.fhir.do|current/StructureDefinition/StructureDefinition-BundleNotifDO.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-BundleNotifDO.csv), [Excel](StructureDefinition-BundleNotifDO.xlsx), [Schematron](StructureDefinition-BundleNotifDO.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "BundleNotifDO",
  "url" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/BundleNotifDO",
  "version" : "0.2.2",
  "name" : "BundleNotifDO",
  "title" : "Bundle de notificación epidemiológica DO",
  "status" : "draft",
  "date" : "2026-11-17T15:46:26-03:00",
  "publisher" : "Ministerio de Salud Pública y Asistencia Social",
  "contact" : [{
    "name" : "Ministerio de Salud Pública y Asistencia Social",
    "telecom" : [{
      "system" : "url",
      "value" : "https://msp.gob.do"
    }]
  }],
  "description" : "Documento de notificación individual con la Composition como primera entrada y los recursos referenciados incluidos.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DO",
      "display" : "Dominican Republic"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "cda",
    "uri" : "http://hl7.org/v3/cda",
    "name" : "CDA (R2)"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Bundle",
  "baseDefinition" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/BundleDocDO",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Bundle",
      "path" : "Bundle",
      "constraint" : [{
        "key" : "notif-composition-primera",
        "severity" : "error",
        "human" : "La primera entrada debe ser la Composition del documento.",
        "expression" : "entry.first().resource.is(Composition)",
        "source" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/BundleNotifDO"
      }]
    },
    {
      "id" : "Bundle.identifier",
      "path" : "Bundle.identifier",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Bundle.identifier.system",
      "path" : "Bundle.identifier.system",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Bundle.identifier.value",
      "path" : "Bundle.identifier.value",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Bundle.timestamp",
      "path" : "Bundle.timestamp",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Bundle.entry",
      "path" : "Bundle.entry",
      "min" : 4
    },
    {
      "id" : "Bundle.entry:composition",
      "path" : "Bundle.entry",
      "sliceName" : "composition",
      "short" : "Documento de notificación epidemiológica"
    },
    {
      "id" : "Bundle.entry:composition.resource",
      "path" : "Bundle.entry.resource",
      "type" : [{
        "code" : "Composition",
        "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/CompositionDONotif"]
      }]
    },
    {
      "id" : "Bundle.entry:caso",
      "path" : "Bundle.entry",
      "sliceName" : "caso",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Bundle.entry:caso.resource",
      "path" : "Bundle.entry.resource",
      "type" : [{
        "code" : "Condition",
        "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/ConditionCasoEpidemiologicoDO"]
      }]
    }]
  }
}

```
