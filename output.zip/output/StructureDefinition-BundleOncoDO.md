# Bundle Documento Oncológico - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Bundle Documento Oncológico**

## Resource Profile: Bundle Documento Oncológico 

| | |
| :--- | :--- |
| *Official URL*:https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/BundleOncoDO | *Version*:0.2.2 |
| Draft as of 2026-11-17 | *Computable Name*:BundleOncoDO |

 
Documento del caso para el Registro Nacional de Cáncer. Hereda de BundleDocDO las entradas composition, patient (PatientDO) y organization (OrganizationDO). 

**Usages:**

* Use this Perfil: [BundleTransaccDO](StructureDefinition-BundleTransaccDO.md)
* Examples for this Perfil: [Bundle/BundleOncoDOExample](Bundle-BundleOncoDOExample.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/msp.fhir.do|current/StructureDefinition/StructureDefinition-BundleOncoDO.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-BundleOncoDO.csv), [Excel](StructureDefinition-BundleOncoDO.xlsx), [Schematron](StructureDefinition-BundleOncoDO.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "BundleOncoDO",
  "url" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/BundleOncoDO",
  "version" : "0.2.2",
  "name" : "BundleOncoDO",
  "title" : "Bundle Documento Oncológico",
  "status" : "draft",
  "date" : "2026-11-17T15:46:26-03:00",
  "publisher" : "Ministerio de Salud Pública y Asistencia Social",
  "contact" : [{
    "name" : "Ministerio de Salud Pública y Asistencia Social",
    "telecom" : [{
      "system" : "url",
      "value" : "https://msp.gob.do"
    }]
  }],
  "description" : "Documento del caso para el Registro Nacional de Cáncer. Hereda de BundleDocDO las entradas composition, patient (PatientDO) y organization (OrganizationDO).",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DO",
      "display" : "Dominican Republic"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "cda",
    "uri" : "http://hl7.org/v3/cda",
    "name" : "CDA (R2)"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Bundle",
  "baseDefinition" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/BundleDocDO",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Bundle",
      "path" : "Bundle"
    },
    {
      "id" : "Bundle.entry",
      "path" : "Bundle.entry",
      "min" : 4
    },
    {
      "id" : "Bundle.entry:composition",
      "path" : "Bundle.entry",
      "sliceName" : "composition",
      "short" : "Documento de Notificación Oncológica"
    },
    {
      "id" : "Bundle.entry:composition.resource",
      "path" : "Bundle.entry.resource",
      "type" : [{
        "code" : "Composition",
        "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/CompositionDOOnco"]
      }]
    },
    {
      "id" : "Bundle.entry:primaryCancerCondition",
      "path" : "Bundle.entry",
      "sliceName" : "primaryCancerCondition",
      "short" : "Cáncer primario",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Bundle.entry:primaryCancerCondition.resource",
      "path" : "Bundle.entry.resource",
      "type" : [{
        "code" : "Condition",
        "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/PrimaryCancerConditionDO"]
      }]
    },
    {
      "id" : "Bundle.entry:pathologyReport",
      "path" : "Bundle.entry",
      "sliceName" : "pathologyReport",
      "short" : "Informe de patología",
      "min" : 0,
      "max" : "*",
      "mustSupport" : true
    },
    {
      "id" : "Bundle.entry:pathologyReport.resource",
      "path" : "Bundle.entry.resource",
      "type" : [{
        "code" : "DiagnosticReport",
        "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/PathologyReportDO"]
      }]
    },
    {
      "id" : "Bundle.entry:pathologyResult",
      "path" : "Bundle.entry",
      "sliceName" : "pathologyResult",
      "short" : "Resultado estructurado de patología (Breslow, variante genómica)",
      "min" : 0,
      "max" : "*",
      "mustSupport" : true
    },
    {
      "id" : "Bundle.entry:pathologyResult.resource",
      "path" : "Bundle.entry.resource",
      "type" : [{
        "code" : "Observation",
        "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/PathologyResultDO"]
      }]
    },
    {
      "id" : "Bundle.entry:cancerStage",
      "path" : "Bundle.entry",
      "sliceName" : "cancerStage",
      "short" : "Estadio del cáncer",
      "min" : 0,
      "max" : "*",
      "mustSupport" : true
    },
    {
      "id" : "Bundle.entry:cancerStage.resource",
      "path" : "Bundle.entry.resource",
      "type" : [{
        "code" : "Observation",
        "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/CancerStageDO"]
      }]
    },
    {
      "id" : "Bundle.entry:surgicalProcedure",
      "path" : "Bundle.entry",
      "sliceName" : "surgicalProcedure",
      "short" : "Cirugía oncológica",
      "min" : 0,
      "max" : "*",
      "mustSupport" : true
    },
    {
      "id" : "Bundle.entry:surgicalProcedure.resource",
      "path" : "Bundle.entry.resource",
      "type" : [{
        "code" : "Procedure",
        "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/SurgicalProcedureDO"]
      }]
    },
    {
      "id" : "Bundle.entry:radiotherapyCourse",
      "path" : "Bundle.entry",
      "sliceName" : "radiotherapyCourse",
      "short" : "Curso de radioterapia",
      "min" : 0,
      "max" : "*",
      "mustSupport" : true
    },
    {
      "id" : "Bundle.entry:radiotherapyCourse.resource",
      "path" : "Bundle.entry.resource",
      "type" : [{
        "code" : "Procedure",
        "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/RadiotherapyCourseDO"]
      }]
    },
    {
      "id" : "Bundle.entry:cancerMedication",
      "path" : "Bundle.entry",
      "sliceName" : "cancerMedication",
      "short" : "Tratamiento farmacológico oncológico",
      "min" : 0,
      "max" : "*",
      "mustSupport" : true
    },
    {
      "id" : "Bundle.entry:cancerMedication.resource",
      "path" : "Bundle.entry.resource",
      "type" : [{
        "code" : "MedicationStatement",
        "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/CancerMedicationStatementDO"]
      }]
    }]
  }
}

```
