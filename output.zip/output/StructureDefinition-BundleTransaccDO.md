# BundleTransaccDO - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **BundleTransaccDO**

## Resource Profile: BundleTransaccDO 

| | |
| :--- | :--- |
| *Official URL*:https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/BundleTransaccDO | *Version*:0.2.2 |
| Draft as of 2026-11-17 | *Computable Name*:BundleTransaccDO |

**Usages:**

* Examples for this Perfil: [Bundle/BundleTransaccDOExample](Bundle-BundleTransaccDOExample.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/msp.fhir.do|current/StructureDefinition/StructureDefinition-BundleTransaccDO.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-BundleTransaccDO.csv), [Excel](StructureDefinition-BundleTransaccDO.xlsx), [Schematron](StructureDefinition-BundleTransaccDO.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "BundleTransaccDO",
  "url" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/BundleTransaccDO",
  "version" : "0.2.2",
  "name" : "BundleTransaccDO",
  "status" : "draft",
  "date" : "2026-11-17T15:46:26-03:00",
  "publisher" : "Ministerio de Salud Pública y Asistencia Social",
  "contact" : [{
    "name" : "Ministerio de Salud Pública y Asistencia Social",
    "telecom" : [{
      "system" : "url",
      "value" : "https://msp.gob.do"
    }]
  }],
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DO",
      "display" : "Dominican Republic"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "cda",
    "uri" : "http://hl7.org/v3/cda",
    "name" : "CDA (R2)"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Bundle",
  "baseDefinition" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.Minimal.ProvideBundle",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Bundle",
      "path" : "Bundle"
    },
    {
      "id" : "Bundle.entry",
      "path" : "Bundle.entry",
      "min" : 4
    },
    {
      "id" : "Bundle.entry:SubmissionSet",
      "path" : "Bundle.entry",
      "sliceName" : "SubmissionSet"
    },
    {
      "id" : "Bundle.entry:SubmissionSet.resource",
      "path" : "Bundle.entry.resource",
      "type" : [{
        "code" : "List",
        "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/ListDO"]
      }]
    },
    {
      "id" : "Bundle.entry:DocumentRefs",
      "path" : "Bundle.entry",
      "sliceName" : "DocumentRefs",
      "min" : 1,
      "max" : "1"
    },
    {
      "id" : "Bundle.entry:DocumentRefs.resource",
      "path" : "Bundle.entry.resource",
      "type" : [{
        "code" : "DocumentReference",
        "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/DocumentReferenceDO",
        "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/DocumentReferenceDOOnco",
        "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/DocumentReferenceDONotif",
        "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/DocumentReferenceDOLab"]
      }]
    },
    {
      "id" : "Bundle.entry:FhirDocuments",
      "path" : "Bundle.entry",
      "sliceName" : "FhirDocuments",
      "min" : 1,
      "max" : "1"
    },
    {
      "id" : "Bundle.entry:FhirDocuments.resource",
      "path" : "Bundle.entry.resource",
      "type" : [{
        "code" : "Bundle",
        "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/BundleNPSDO",
        "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/BundleOncoDO",
        "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/BundleNotifDO",
        "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/BundleLabDO"]
      }]
    },
    {
      "id" : "Bundle.entry:Patient",
      "path" : "Bundle.entry",
      "sliceName" : "Patient",
      "min" : 1
    },
    {
      "id" : "Bundle.entry:Patient.resource",
      "path" : "Bundle.entry.resource",
      "type" : [{
        "code" : "Patient",
        "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/PatientDO"]
      }]
    }]
  }
}

```
