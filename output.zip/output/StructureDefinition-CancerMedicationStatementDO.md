# Tratamiento Farmacológico Oncológico DO - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Tratamiento Farmacológico Oncológico DO**

## Resource Profile: Tratamiento Farmacológico Oncológico DO 

| | |
| :--- | :--- |
| *Official URL*:https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/CancerMedicationStatementDO | *Version*:0.2.2 |
| Draft as of 2026-11-17 | *Computable Name*:CancerMedicationStatementDO |

 
Tratamiento sistémico del cáncer primario (quimioterapia, hormonoterapia, inmunoterapia, terapia dirigida). 

**Usages:**

* Use this Perfil: [Bundle Documento Oncológico](StructureDefinition-BundleOncoDO.md)
* Refer to this Perfil: [Documento Clínico Oncologico](StructureDefinition-CompositionDOOnco.md)
* Examples for this Perfil: [MedicationStatement/CancerMedicationStatementDOExample](MedicationStatement-CancerMedicationStatementDOExample.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/msp.fhir.do|current/StructureDefinition/StructureDefinition-CancerMedicationStatementDO.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-CancerMedicationStatementDO.csv), [Excel](StructureDefinition-CancerMedicationStatementDO.xlsx), [Schematron](StructureDefinition-CancerMedicationStatementDO.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "CancerMedicationStatementDO",
  "url" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/CancerMedicationStatementDO",
  "version" : "0.2.2",
  "name" : "CancerMedicationStatementDO",
  "title" : "Tratamiento Farmacológico Oncológico DO",
  "status" : "draft",
  "date" : "2026-11-17T15:46:26-03:00",
  "publisher" : "Ministerio de Salud Pública y Asistencia Social",
  "contact" : [{
    "name" : "Ministerio de Salud Pública y Asistencia Social",
    "telecom" : [{
      "system" : "url",
      "value" : "https://msp.gob.do"
    }]
  }],
  "description" : "Tratamiento sistémico del cáncer primario (quimioterapia, hormonoterapia, inmunoterapia, terapia dirigida).",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DO",
      "display" : "Dominican Republic"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "MedicationStatement",
  "baseDefinition" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/MedicationStatementDO",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "MedicationStatement.informationSource",
      "path" : "MedicationStatement.informationSource",
      "short" : "Establecimiento que informa el tratamiento",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/OrganizationDO"]
      }]
    },
    {
      "id" : "MedicationStatement.reasonReference",
      "path" : "MedicationStatement.reasonReference",
      "short" : "Cáncer primario tratado",
      "min" : 1,
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/PrimaryCancerConditionDO"]
      }],
      "mustSupport" : true
    }]
  }
}

```
