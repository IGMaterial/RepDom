# Estadio del Cáncer DO - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Estadio del Cáncer DO**

## Resource Profile: Estadio del Cáncer DO 

| | |
| :--- | :--- |
| *Official URL*:https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/CancerStageDO | *Version*:0.2.2 |
| Draft as of 2026-11-17 | *Computable Name*:CancerStageDO |

 
Grupo de estadio del cáncer primario. 

**Usages:**

* Use this Perfil: [Bundle Documento Oncológico](StructureDefinition-BundleOncoDO.md)
* Refer to this Perfil: [Documento Clínico Oncologico](StructureDefinition-CompositionDOOnco.md)
* Examples for this Perfil: [Observation/CancerStageDOExample](Observation-CancerStageDOExample.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/msp.fhir.do|current/StructureDefinition/StructureDefinition-CancerStageDO.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-CancerStageDO.csv), [Excel](StructureDefinition-CancerStageDO.xlsx), [Schematron](StructureDefinition-CancerStageDO.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "CancerStageDO",
  "url" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/CancerStageDO",
  "version" : "0.2.2",
  "name" : "CancerStageDO",
  "title" : "Estadio del Cáncer DO",
  "status" : "draft",
  "date" : "2026-11-17T15:46:26-03:00",
  "publisher" : "Ministerio de Salud Pública y Asistencia Social",
  "contact" : [{
    "name" : "Ministerio de Salud Pública y Asistencia Social",
    "telecom" : [{
      "system" : "url",
      "value" : "https://msp.gob.do"
    }]
  }],
  "description" : "Grupo de estadio del cáncer primario.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DO",
      "display" : "Dominican Republic"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "sct-concept",
    "uri" : "http://snomed.info/conceptdomain",
    "name" : "SNOMED CT Concept Domain Binding"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "sct-attr",
    "uri" : "http://snomed.org/attributebinding",
    "name" : "SNOMED CT Attribute Binding"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Observation",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Observation",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Observation.status",
      "path" : "Observation.status",
      "mustSupport" : true
    },
    {
      "id" : "Observation.code",
      "path" : "Observation.code",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSObservacionesOncoDO",
          "code" : "estadio"
        }]
      },
      "mustSupport" : true
    },
    {
      "id" : "Observation.subject",
      "path" : "Observation.subject",
      "min" : 1,
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/PatientDO"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Observation.focus",
      "path" : "Observation.focus",
      "short" : "Cáncer primario estadificado",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/PrimaryCancerConditionDO"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Observation.effective[x]",
      "path" : "Observation.effective[x]",
      "short" : "Fecha de estadificación",
      "min" : 1,
      "type" : [{
        "code" : "dateTime"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Observation.performer",
      "path" : "Observation.performer",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/OrganizationDO"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Observation.value[x]",
      "path" : "Observation.value[x]",
      "min" : 1,
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "mustSupport" : true,
      "binding" : {
        "strength" : "extensible",
        "valueSet" : "https://digital.msp.gob.do/fhir/conectaton/ValueSet/VSEstadioDO"
      }
    },
    {
      "id" : "Observation.method",
      "path" : "Observation.method",
      "short" : "Sistema de estadificación (TNM, FIGO, Ann Arbor, etc.)",
      "mustSupport" : true
    }]
  }
}

```
