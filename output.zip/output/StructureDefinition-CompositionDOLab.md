# Documento Clínico Laboratorio - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Documento Clínico Laboratorio**

## Resource Profile: Documento Clínico Laboratorio 

| | |
| :--- | :--- |
| *Official URL*:https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/CompositionDOLab | *Version*:0.2.2 |
| Draft as of 2026-11-17 | *Computable Name*:CompositionDOLab |

**Usages:**

* Use this Perfil: [BundleLabDO](StructureDefinition-BundleLabDO.md)
* Examples for this Perfil: [Composition/CompositionDOLabExample](Composition-CompositionDOLabExample.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/msp.fhir.do|current/StructureDefinition/StructureDefinition-CompositionDOLab.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-CompositionDOLab.csv), [Excel](StructureDefinition-CompositionDOLab.xlsx), [Schematron](StructureDefinition-CompositionDOLab.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "CompositionDOLab",
  "url" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/CompositionDOLab",
  "version" : "0.2.2",
  "name" : "CompositionDOLab",
  "title" : "Documento Clínico Laboratorio",
  "status" : "draft",
  "date" : "2026-11-17T15:46:26-03:00",
  "publisher" : "Ministerio de Salud Pública y Asistencia Social",
  "contact" : [{
    "name" : "Ministerio de Salud Pública y Asistencia Social",
    "telecom" : [{
      "system" : "url",
      "value" : "https://msp.gob.do"
    }]
  }],
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DO",
      "display" : "Dominican Republic"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "cda",
    "uri" : "http://hl7.org/v3/cda",
    "name" : "CDA (R2)"
  },
  {
    "identity" : "fhirdocumentreference",
    "uri" : "http://hl7.org/fhir/documentreference",
    "name" : "FHIR DocumentReference"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Composition",
  "baseDefinition" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/CompositionDO",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Composition.section",
      "path" : "Composition.section",
      "slicing" : {
        "discriminator" : [{
          "type" : "pattern",
          "path" : "code"
        }],
        "ordered" : false,
        "rules" : "open"
      },
      "short" : "Sección del documento",
      "definition" : "Sección de notificación de datos clínicos.",
      "min" : 2
    },
    {
      "id" : "Composition.section.code",
      "path" : "Composition.section.code",
      "min" : 1,
      "mustSupport" : true,
      "binding" : {
        "strength" : "example",
        "valueSet" : "http://hl7.org/fhir/ValueSet/doc-section-codes"
      }
    },
    {
      "id" : "Composition.section:DiagnosticReport",
      "path" : "Composition.section",
      "sliceName" : "DiagnosticReport",
      "short" : "Sección Informe Laboratorio",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:DiagnosticReport.title",
      "path" : "Composition.section.title",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:DiagnosticReport.code",
      "path" : "Composition.section.code",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "11502-2",
          "display" : "Laboratory report"
        }]
      }
    },
    {
      "id" : "Composition.section:DiagnosticReport.entry",
      "path" : "Composition.section.entry",
      "min" : 1,
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/DiagnosticReportDO"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:DocumentoPDF",
      "path" : "Composition.section",
      "sliceName" : "DocumentoPDF",
      "short" : "Sección Documento PDF",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:DocumentoPDF.title",
      "path" : "Composition.section.title",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:DocumentoPDF.code",
      "path" : "Composition.section.code",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "99999-9"
        }]
      }
    },
    {
      "id" : "Composition.section:DocumentoPDF.entry",
      "path" : "Composition.section.entry",
      "min" : 1,
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/BinaryDO"]
      }],
      "mustSupport" : true
    }]
  }
}

```
