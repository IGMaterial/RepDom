# Documento Clínico IPS DO - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Documento Clínico IPS DO**

## Resource Profile: Documento Clínico IPS DO 

| | |
| :--- | :--- |
| *Official URL*:https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/CompositionDONPS | *Version*:0.2.2 |
| Draft as of 2026-11-17 | *Computable Name*:CompositionDONPS |

 
Perfil para documentos clínicos FHIR. 

**Usages:**

* Use this Perfil: [BundleNPSDO](StructureDefinition-BundleNPSDO.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/msp.fhir.do|current/StructureDefinition/StructureDefinition-CompositionDONPS.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-CompositionDONPS.csv), [Excel](StructureDefinition-CompositionDONPS.xlsx), [Schematron](StructureDefinition-CompositionDONPS.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "CompositionDONPS",
  "url" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/CompositionDONPS",
  "version" : "0.2.2",
  "name" : "CompositionDONPS",
  "title" : "Documento Clínico IPS DO",
  "status" : "draft",
  "date" : "2026-11-17T15:46:26-03:00",
  "publisher" : "Ministerio de Salud Pública y Asistencia Social",
  "contact" : [{
    "name" : "Ministerio de Salud Pública y Asistencia Social",
    "telecom" : [{
      "system" : "url",
      "value" : "https://msp.gob.do"
    }]
  }],
  "description" : "Perfil para documentos clínicos FHIR.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DO",
      "display" : "Dominican Republic"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "cda",
    "uri" : "http://hl7.org/v3/cda",
    "name" : "CDA (R2)"
  },
  {
    "identity" : "fhirdocumentreference",
    "uri" : "http://hl7.org/fhir/documentreference",
    "name" : "FHIR DocumentReference"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Composition",
  "baseDefinition" : "http://hl7.org/fhir/uv/ips/StructureDefinition/Composition-uv-ips",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Composition.subject",
      "path" : "Composition.subject",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/PatientDO"]
      }]
    },
    {
      "id" : "Composition.author",
      "path" : "Composition.author",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/PractitionerDO",
        "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/OrganizationDO"]
      }]
    },
    {
      "id" : "Composition.custodian",
      "path" : "Composition.custodian",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/OrganizationDO"]
      }]
    }]
  }
}

```
