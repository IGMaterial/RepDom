# Documento Clínico Notificación de Caso - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Documento Clínico Notificación de Caso**

## Resource Profile: Documento Clínico Notificación de Caso 

| | |
| :--- | :--- |
| *Official URL*:https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/CompositionDONotif | *Version*:0.2.2 |
| Draft as of 2026-11-17 | *Computable Name*:CompositionDONotif |

 
Notificación individual organizada alrededor de un caso epidemiológico. 

**Usages:**

* Use this Perfil: [Bundle de notificación epidemiológica DO](StructureDefinition-BundleNotifDO.md)
* Examples for this Perfil: [Composition/CompositionDONotifExample](Composition-CompositionDONotifExample.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/msp.fhir.do|current/StructureDefinition/StructureDefinition-CompositionDONotif.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-CompositionDONotif.csv), [Excel](StructureDefinition-CompositionDONotif.xlsx), [Schematron](StructureDefinition-CompositionDONotif.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "CompositionDONotif",
  "url" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/CompositionDONotif",
  "version" : "0.2.2",
  "name" : "CompositionDONotif",
  "title" : "Documento Clínico Notificación de Caso",
  "status" : "draft",
  "date" : "2026-11-17T15:46:26-03:00",
  "publisher" : "Ministerio de Salud Pública y Asistencia Social",
  "contact" : [{
    "name" : "Ministerio de Salud Pública y Asistencia Social",
    "telecom" : [{
      "system" : "url",
      "value" : "https://msp.gob.do"
    }]
  }],
  "description" : "Notificación individual organizada alrededor de un caso epidemiológico.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DO",
      "display" : "Dominican Republic"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "cda",
    "uri" : "http://hl7.org/v3/cda",
    "name" : "CDA (R2)"
  },
  {
    "identity" : "fhirdocumentreference",
    "uri" : "http://hl7.org/fhir/documentreference",
    "name" : "FHIR DocumentReference"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Composition",
  "baseDefinition" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/CompositionDO",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Composition.section",
      "path" : "Composition.section",
      "slicing" : {
        "discriminator" : [{
          "type" : "pattern",
          "path" : "code"
        }],
        "ordered" : false,
        "rules" : "open"
      },
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Composition.section.title",
      "path" : "Composition.section.title",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Composition.section.code",
      "path" : "Composition.section.code",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Composition.section.text",
      "path" : "Composition.section.text",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:DatosEnfermedad",
      "path" : "Composition.section",
      "sliceName" : "DatosEnfermedad",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:DatosEnfermedad.code",
      "path" : "Composition.section.code",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSSeccionesNotificacionDO",
          "code" : "evento"
        }]
      }
    },
    {
      "id" : "Composition.section:DatosEnfermedad.entry",
      "path" : "Composition.section.entry",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/ConditionCasoEpidemiologicoDO"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:Observaciones",
      "path" : "Composition.section",
      "sliceName" : "Observaciones",
      "min" : 0,
      "max" : "*",
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:Observaciones.code",
      "path" : "Composition.section.code",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSSeccionesNotificacionDO",
          "code" : "observaciones"
        }]
      }
    },
    {
      "id" : "Composition.section:Observaciones.entry",
      "path" : "Composition.section.entry",
      "max" : "1",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/ObservationSignoSintomaDO",
        "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/ObservationEstadoEmbarazoDO",
        "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/ObservationViajesExposicionDO"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:Laboratorio",
      "path" : "Composition.section",
      "sliceName" : "Laboratorio",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:Laboratorio.code",
      "path" : "Composition.section.code",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSSeccionesNotificacionDO",
          "code" : "laboratorio"
        }]
      }
    },
    {
      "id" : "Composition.section:Laboratorio.entry",
      "path" : "Composition.section.entry",
      "min" : 1,
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/DiagnosticReportDO"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:Conclusion",
      "path" : "Composition.section",
      "sliceName" : "Conclusion",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:Conclusion.code",
      "path" : "Composition.section.code",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSSeccionesNotificacionDO",
          "code" : "conclusion"
        }]
      }
    },
    {
      "id" : "Composition.section:Conclusion.entry",
      "path" : "Composition.section.entry",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/ConditionConclusionDO"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:DocumentoPDF",
      "path" : "Composition.section",
      "sliceName" : "DocumentoPDF",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:DocumentoPDF.code",
      "path" : "Composition.section.code",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSSeccionesNotificacionDO",
          "code" : "documento-pdf"
        }]
      }
    },
    {
      "id" : "Composition.section:DocumentoPDF.entry",
      "path" : "Composition.section.entry",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/BinaryDO"]
      }],
      "mustSupport" : true
    }]
  }
}

```
