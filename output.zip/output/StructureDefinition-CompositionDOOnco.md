# Documento Clínico Oncologico - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Documento Clínico Oncologico**

## Resource Profile: Documento Clínico Oncologico 

| | |
| :--- | :--- |
| *Official URL*:https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/CompositionDOOnco | *Version*:0.2.2 |
| Draft as of 2026-11-17 | *Computable Name*:CompositionDOOnco |

 
Documento del caso para el Registro Nacional de Cáncer. Todo el contenido clínico se ancla al cáncer primario (PrimaryCancerConditionDO). 

**Usages:**

* Use this Perfil: [Bundle Documento Oncológico](StructureDefinition-BundleOncoDO.md)
* Examples for this Perfil: [Composition/CompositionDOOncoExample](Composition-CompositionDOOncoExample.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/msp.fhir.do|current/StructureDefinition/StructureDefinition-CompositionDOOnco.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-CompositionDOOnco.csv), [Excel](StructureDefinition-CompositionDOOnco.xlsx), [Schematron](StructureDefinition-CompositionDOOnco.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "CompositionDOOnco",
  "url" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/CompositionDOOnco",
  "version" : "0.2.2",
  "name" : "CompositionDOOnco",
  "title" : "Documento Clínico Oncologico",
  "status" : "draft",
  "date" : "2026-11-17T15:46:26-03:00",
  "publisher" : "Ministerio de Salud Pública y Asistencia Social",
  "contact" : [{
    "name" : "Ministerio de Salud Pública y Asistencia Social",
    "telecom" : [{
      "system" : "url",
      "value" : "https://msp.gob.do"
    }]
  }],
  "description" : "Documento del caso para el Registro Nacional de Cáncer. Todo el contenido clínico se ancla al cáncer primario (PrimaryCancerConditionDO).",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DO",
      "display" : "Dominican Republic"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "cda",
    "uri" : "http://hl7.org/v3/cda",
    "name" : "CDA (R2)"
  },
  {
    "identity" : "fhirdocumentreference",
    "uri" : "http://hl7.org/fhir/documentreference",
    "name" : "FHIR DocumentReference"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Composition",
  "baseDefinition" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/CompositionDO",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Composition.author",
      "path" : "Composition.author",
      "short" : "Establecimiento que notifica (fuente del caso)",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/OrganizationDO"]
      }]
    },
    {
      "id" : "Composition.section",
      "path" : "Composition.section",
      "slicing" : {
        "discriminator" : [{
          "type" : "pattern",
          "path" : "code"
        }],
        "ordered" : false,
        "rules" : "open"
      },
      "short" : "Sección del documento",
      "definition" : "Sección de notificación de datos clínicos.",
      "min" : 1
    },
    {
      "id" : "Composition.section.code",
      "path" : "Composition.section.code",
      "min" : 1,
      "mustSupport" : true,
      "binding" : {
        "strength" : "example",
        "valueSet" : "http://hl7.org/fhir/ValueSet/doc-section-codes"
      }
    },
    {
      "id" : "Composition.section:Diagnostico",
      "path" : "Composition.section",
      "sliceName" : "Diagnostico",
      "short" : "Sección Diagnóstico",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:Diagnostico.title",
      "path" : "Composition.section.title",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:Diagnostico.code",
      "path" : "Composition.section.code",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSSeccionesOncoDO",
          "code" : "diagnostico"
        }]
      }
    },
    {
      "id" : "Composition.section:Diagnostico.entry",
      "path" : "Composition.section.entry",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/PrimaryCancerConditionDO"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:Patologia",
      "path" : "Composition.section",
      "sliceName" : "Patologia",
      "short" : "Sección Patología",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:Patologia.title",
      "path" : "Composition.section.title",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:Patologia.code",
      "path" : "Composition.section.code",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "30954-2",
          "display" : "Relevant diagnostic tests/laboratory data Narrative"
        }]
      }
    },
    {
      "id" : "Composition.section:Patologia.entry",
      "path" : "Composition.section.entry",
      "min" : 1,
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/PathologyReportDO"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:Estadificacion",
      "path" : "Composition.section",
      "sliceName" : "Estadificacion",
      "short" : "Sección Estadificación y riesgo",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:Estadificacion.title",
      "path" : "Composition.section.title",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:Estadificacion.code",
      "path" : "Composition.section.code",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSSeccionesOncoDO",
          "code" : "estadificacion"
        }]
      }
    },
    {
      "id" : "Composition.section:Estadificacion.entry",
      "path" : "Composition.section.entry",
      "min" : 1,
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/CancerStageDO"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:Tratamientos",
      "path" : "Composition.section",
      "sliceName" : "Tratamientos",
      "short" : "Sección Tratamientos",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:Tratamientos.title",
      "path" : "Composition.section.title",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:Tratamientos.code",
      "path" : "Composition.section.code",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "47519-4",
          "display" : "History of Procedures Document"
        }]
      }
    },
    {
      "id" : "Composition.section:Tratamientos.entry",
      "path" : "Composition.section.entry",
      "min" : 1,
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/SurgicalProcedureDO",
        "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/RadiotherapyCourseDO",
        "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/CancerMedicationStatementDO"]
      }],
      "mustSupport" : true
    }]
  }
}

```
