# Conclusión epidemiológica DO - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Conclusión epidemiológica DO**

## Resource Profile: Conclusión epidemiológica DO 

| | |
| :--- | :--- |
| *Official URL*:https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/ConditionConclusionDO | *Version*:0.2.2 |
| Draft as of 2026-11-17 | *Computable Name*:ConditionConclusionDO |

 
Conclusión del caso; la clasificación final se registra en code y el estado de confirmación en verificationStatus. 

**Usages:**

* Refer to this Perfil: [Documento Clínico Notificación de Caso](StructureDefinition-CompositionDONotif.md)
* Examples for this Perfil: [Condition/ConditionConclusionDOExample](Condition-ConditionConclusionDOExample.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/msp.fhir.do|current/StructureDefinition/StructureDefinition-ConditionConclusionDO.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-ConditionConclusionDO.csv), [Excel](StructureDefinition-ConditionConclusionDO.xlsx), [Schematron](StructureDefinition-ConditionConclusionDO.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "ConditionConclusionDO",
  "url" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/ConditionConclusionDO",
  "version" : "0.2.2",
  "name" : "ConditionConclusionDO",
  "title" : "Conclusión epidemiológica DO",
  "status" : "draft",
  "date" : "2026-11-17T15:46:26-03:00",
  "publisher" : "Ministerio de Salud Pública y Asistencia Social",
  "contact" : [{
    "name" : "Ministerio de Salud Pública y Asistencia Social",
    "telecom" : [{
      "system" : "url",
      "value" : "https://msp.gob.do"
    }]
  }],
  "description" : "Conclusión del caso; la clasificación final se registra en code y el estado de confirmación en verificationStatus.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DO",
      "display" : "Dominican Republic"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "sct-concept",
    "uri" : "http://snomed.info/conceptdomain",
    "name" : "SNOMED CT Concept Domain Binding"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Condition",
  "baseDefinition" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/ConditionDO",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Condition",
      "path" : "Condition"
    },
    {
      "id" : "Condition.clinicalStatus",
      "path" : "Condition.clinicalStatus",
      "min" : 1
    },
    {
      "id" : "Condition.verificationStatus",
      "path" : "Condition.verificationStatus",
      "min" : 1
    },
    {
      "id" : "Condition.category",
      "path" : "Condition.category",
      "slicing" : {
        "discriminator" : [{
          "type" : "pattern",
          "path" : "$this"
        }],
        "rules" : "open"
      },
      "min" : 1
    },
    {
      "id" : "Condition.category:conclusion",
      "path" : "Condition.category",
      "sliceName" : "conclusion",
      "min" : 1,
      "max" : "1",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSCategoriaNotificacionDO",
          "code" : "conclusion-epidemiologica"
        }]
      },
      "mustSupport" : true
    },
    {
      "id" : "Condition.code",
      "path" : "Condition.code",
      "short" : "Conclusión o clasificación final del caso"
    },
    {
      "id" : "Condition.recordedDate",
      "path" : "Condition.recordedDate",
      "min" : 1
    }]
  }
}

```
