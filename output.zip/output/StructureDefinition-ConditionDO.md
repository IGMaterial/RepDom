# Condición DO - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Condición DO**

## Resource Profile: Condición DO 

| | |
| :--- | :--- |
| *Official URL*:https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/ConditionDO | *Version*:0.2.2 |
| Draft as of 2026-11-17 | *Computable Name*:ConditionDO |

 
Perfil para problemas, diagnósticos y condiciones clínicas. 

**Usages:**

* Derived from this Perfil: [Caso epidemiológico DO](StructureDefinition-ConditionCasoEpidemiologicoDO.md), [Conclusión epidemiológica DO](StructureDefinition-ConditionConclusionDO.md) and [Cáncer Primario DO](StructureDefinition-PrimaryCancerConditionDO.md)
* Examples for this Perfil: [Condition/ConditionDOEjemplo](Condition-ConditionDOEjemplo.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/msp.fhir.do|current/StructureDefinition/StructureDefinition-ConditionDO.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-ConditionDO.csv), [Excel](StructureDefinition-ConditionDO.xlsx), [Schematron](StructureDefinition-ConditionDO.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "ConditionDO",
  "url" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/ConditionDO",
  "version" : "0.2.2",
  "name" : "ConditionDO",
  "title" : "Condición DO",
  "status" : "draft",
  "date" : "2026-11-17T15:46:26-03:00",
  "publisher" : "Ministerio de Salud Pública y Asistencia Social",
  "contact" : [{
    "name" : "Ministerio de Salud Pública y Asistencia Social",
    "telecom" : [{
      "system" : "url",
      "value" : "https://msp.gob.do"
    }]
  }],
  "description" : "Perfil  para problemas, diagnósticos y condiciones clínicas.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DO",
      "display" : "Dominican Republic"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "sct-concept",
    "uri" : "http://snomed.info/conceptdomain",
    "name" : "SNOMED CT Concept Domain Binding"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Condition",
  "baseDefinition" : "http://hl7.org/fhir/uv/ips/StructureDefinition/Condition-uv-ips",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Condition.verificationStatus",
      "path" : "Condition.verificationStatus",
      "mustSupport" : true
    },
    {
      "id" : "Condition.subject",
      "path" : "Condition.subject",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/PatientDO"]
      }]
    },
    {
      "id" : "Condition.encounter",
      "path" : "Condition.encounter",
      "mustSupport" : true
    },
    {
      "id" : "Condition.recordedDate",
      "path" : "Condition.recordedDate",
      "mustSupport" : true
    },
    {
      "id" : "Condition.recorder",
      "path" : "Condition.recorder",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/PractitionerDO"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Condition.note",
      "path" : "Condition.note",
      "mustSupport" : true
    }]
  }
}

```
