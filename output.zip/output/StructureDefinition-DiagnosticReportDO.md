# DiagnosticReportDO - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **DiagnosticReportDO**

## Resource Profile: DiagnosticReportDO 

| | |
| :--- | :--- |
| *Official URL*:https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/DiagnosticReportDO | *Version*:0.2.2 |
| Draft as of 2026-11-17 | *Computable Name*:DiagnosticReportDO |

**Usages:**

* Refer to this Perfil: [Documento Clínico Laboratorio](StructureDefinition-CompositionDOLab.md), [Documento Clínico Notificación de Caso](StructureDefinition-CompositionDONotif.md) and [Caso epidemiológico DO](StructureDefinition-ConditionCasoEpidemiologicoDO.md)
* Examples for this Perfil: [DiagnosticReport/DiagnosticReportDOExample](DiagnosticReport-DiagnosticReportDOExample.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/msp.fhir.do|current/StructureDefinition/StructureDefinition-DiagnosticReportDO.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-DiagnosticReportDO.csv), [Excel](StructureDefinition-DiagnosticReportDO.xlsx), [Schematron](StructureDefinition-DiagnosticReportDO.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "DiagnosticReportDO",
  "url" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/DiagnosticReportDO",
  "version" : "0.2.2",
  "name" : "DiagnosticReportDO",
  "status" : "draft",
  "date" : "2026-11-17T15:46:26-03:00",
  "publisher" : "Ministerio de Salud Pública y Asistencia Social",
  "contact" : [{
    "name" : "Ministerio de Salud Pública y Asistencia Social",
    "telecom" : [{
      "system" : "url",
      "value" : "https://msp.gob.do"
    }]
  }],
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DO",
      "display" : "Dominican Republic"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "DiagnosticReport",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/DiagnosticReport",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "DiagnosticReport",
      "path" : "DiagnosticReport"
    },
    {
      "id" : "DiagnosticReport.code",
      "path" : "DiagnosticReport.code",
      "short" : "Tipo de informe de laboratorio",
      "definition" : "Tipo de informe de laboratorio",
      "mustSupport" : true,
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://digital.msp.gob.do/fhir/conectaton/ValueSet/DiagnosticReportCodeVS"
      }
    },
    {
      "id" : "DiagnosticReport.subject",
      "path" : "DiagnosticReport.subject",
      "min" : 1,
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/PatientDO"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "DiagnosticReport.presentedForm",
      "path" : "DiagnosticReport.presentedForm",
      "short" : "Documento PDF del resultado de Laboratorio",
      "definition" : "Documento PDF del resultado de Laboratorio",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    }]
  }
}

```
