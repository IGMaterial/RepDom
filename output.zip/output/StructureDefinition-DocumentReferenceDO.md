# DocumentReferenceDO - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **DocumentReferenceDO**

## Resource Profile: DocumentReferenceDO 

| | |
| :--- | :--- |
| *Official URL*:https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/DocumentReferenceDO | *Version*:0.2.2 |
| Draft as of 2026-11-17 | *Computable Name*:DocumentReferenceDO |

**Usages:**

* Derived from this Perfil: [DocumentReferenceDOLab](StructureDefinition-DocumentReferenceDOLab.md), [DocumentReferenceDONPS](StructureDefinition-DocumentReferenceDONPS.md), [DocumentReferenceDONotif](StructureDefinition-DocumentReferenceDONotif.md) and [DocumentReferenceDOOnco](StructureDefinition-DocumentReferenceDOOnco.md)
* Use this Perfil: [BundleTransaccDO](StructureDefinition-BundleTransaccDO.md)
* Refer to this Perfil: [ListDO](StructureDefinition-ListDO.md)
* Examples for this Perfil: [DocumentReference/DocumentReferenceDOExample](DocumentReference-DocumentReferenceDOExample.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/msp.fhir.do|current/StructureDefinition/StructureDefinition-DocumentReferenceDO.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-DocumentReferenceDO.csv), [Excel](StructureDefinition-DocumentReferenceDO.xlsx), [Schematron](StructureDefinition-DocumentReferenceDO.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "DocumentReferenceDO",
  "url" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/DocumentReferenceDO",
  "version" : "0.2.2",
  "name" : "DocumentReferenceDO",
  "status" : "draft",
  "date" : "2026-11-17T15:46:26-03:00",
  "publisher" : "Ministerio de Salud Pública y Asistencia Social",
  "contact" : [{
    "name" : "Ministerio de Salud Pública y Asistencia Social",
    "telecom" : [{
      "system" : "url",
      "value" : "https://msp.gob.do"
    }]
  }],
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DO",
      "display" : "Dominican Republic"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "DocumentEntry-Mapping",
    "uri" : "XDS",
    "name" : "XDS and MHD Mapping"
  },
  {
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "fhircomposition",
    "uri" : "http://hl7.org/fhir/composition",
    "name" : "FHIR Composition"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "cda",
    "uri" : "http://hl7.org/v3/cda",
    "name" : "CDA (R2)"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "xds",
    "uri" : "http://ihe.net/xds",
    "name" : "XDS metadata equivalent"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "DocumentReference",
  "baseDefinition" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.Minimal.DocumentReference",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "DocumentReference.status",
      "path" : "DocumentReference.status",
      "short" : "Estado del Documento. Valor Fijo: current",
      "definition" : "Indica el estado del documento.",
      "patternCode" : "current",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.type",
      "path" : "DocumentReference.type",
      "min" : 1
    },
    {
      "id" : "DocumentReference.subject",
      "path" : "DocumentReference.subject",
      "short" : "Representa al paciente.",
      "min" : 1,
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/PatientDO"]
      }]
    },
    {
      "id" : "DocumentReference.subject.reference",
      "path" : "DocumentReference.subject.reference",
      "short" : "Referencia al paciente.",
      "min" : 1
    },
    {
      "id" : "DocumentReference.date",
      "path" : "DocumentReference.date",
      "short" : "Fecha de creación del documento",
      "definition" : "Fecha de creación del documento",
      "min" : 1
    },
    {
      "id" : "DocumentReference.custodian",
      "path" : "DocumentReference.custodian",
      "short" : "Nodo Dominio que custodia el documento.",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/OrganizationDO"]
      }]
    },
    {
      "id" : "DocumentReference.custodian.reference",
      "path" : "DocumentReference.custodian.reference",
      "short" : "URL que referencia al recurso organización."
    },
    {
      "id" : "DocumentReference.content.attachment",
      "path" : "DocumentReference.content.attachment",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.content.attachment.url",
      "path" : "DocumentReference.content.attachment.url",
      "short" : "URL del documento almacenado.",
      "mustSupport" : true
    }]
  }
}

```
