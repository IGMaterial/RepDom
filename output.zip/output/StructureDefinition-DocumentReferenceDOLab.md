# DocumentReferenceDOLab - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **DocumentReferenceDOLab**

## Resource Profile: DocumentReferenceDOLab 

| | |
| :--- | :--- |
| *Official URL*:https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/DocumentReferenceDOLab | *Version*:0.2.2 |
| Draft as of 2026-11-17 | *Computable Name*:DocumentReferenceDOLab |

**Usages:**

* Use this Perfil: [BundleTransaccDO](StructureDefinition-BundleTransaccDO.md)
* Refer to this Perfil: [ListDO](StructureDefinition-ListDO.md)
* Examples for this Perfil: [DocumentReference/DocumentReferenceDOLabExample](DocumentReference-DocumentReferenceDOLabExample.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/msp.fhir.do|current/StructureDefinition/StructureDefinition-DocumentReferenceDOLab.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-DocumentReferenceDOLab.csv), [Excel](StructureDefinition-DocumentReferenceDOLab.xlsx), [Schematron](StructureDefinition-DocumentReferenceDOLab.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "DocumentReferenceDOLab",
  "url" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/DocumentReferenceDOLab",
  "version" : "0.2.2",
  "name" : "DocumentReferenceDOLab",
  "status" : "draft",
  "date" : "2026-11-17T15:46:26-03:00",
  "publisher" : "Ministerio de Salud Pública y Asistencia Social",
  "contact" : [{
    "name" : "Ministerio de Salud Pública y Asistencia Social",
    "telecom" : [{
      "system" : "url",
      "value" : "https://msp.gob.do"
    }]
  }],
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DO",
      "display" : "Dominican Republic"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "DocumentEntry-Mapping",
    "uri" : "XDS",
    "name" : "XDS and MHD Mapping"
  },
  {
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "fhircomposition",
    "uri" : "http://hl7.org/fhir/composition",
    "name" : "FHIR Composition"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "cda",
    "uri" : "http://hl7.org/v3/cda",
    "name" : "CDA (R2)"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "xds",
    "uri" : "http://ihe.net/xds",
    "name" : "XDS metadata equivalent"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "DocumentReference",
  "baseDefinition" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/DocumentReferenceDO",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "DocumentReference.type",
      "path" : "DocumentReference.type",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "11502-2",
          "display" : "Laboratory report"
        }]
      }
    }]
  }
}

```
