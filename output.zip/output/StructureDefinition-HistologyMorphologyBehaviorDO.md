# Morfología y comportamiento histológico DO - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Morfología y comportamiento histológico DO**

## Extension: Morfología y comportamiento histológico DO 

| | |
| :--- | :--- |
| *Official URL*:https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/HistologyMorphologyBehaviorDO | *Version*:0.2.2 |
| Draft as of 2026-11-17 | *Computable Name*:HistologyMorphologyBehaviorDO |

Morfología del cáncer primario en CIE-O-3 (tipo histológico y comportamiento, p. ej. 8500/3). Misma forma que la extensión mcode-histology-morphology-behavior de mCODE, por lo que se mapea 1:1.

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [Cáncer Primario DO](StructureDefinition-PrimaryCancerConditionDO.md)
* Examples for this Extension: [Bundle/BundleOncoDOExample](Bundle-BundleOncoDOExample.md) and [Condition/PrimaryCancerConditionDOExample](Condition-PrimaryCancerConditionDOExample.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/msp.fhir.do|current/StructureDefinition/StructureDefinition-HistologyMorphologyBehaviorDO.json)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-HistologyMorphologyBehaviorDO.csv), [Excel](StructureDefinition-HistologyMorphologyBehaviorDO.xlsx), [Schematron](StructureDefinition-HistologyMorphologyBehaviorDO.sch) 

#### Terminology Bindings

#### Constraints



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "HistologyMorphologyBehaviorDO",
  "url" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/HistologyMorphologyBehaviorDO",
  "version" : "0.2.2",
  "name" : "HistologyMorphologyBehaviorDO",
  "title" : "Morfología y comportamiento histológico DO",
  "status" : "draft",
  "date" : "2026-11-17T15:46:26-03:00",
  "publisher" : "Ministerio de Salud Pública y Asistencia Social",
  "contact" : [{
    "name" : "Ministerio de Salud Pública y Asistencia Social",
    "telecom" : [{
      "system" : "url",
      "value" : "https://msp.gob.do"
    }]
  }],
  "description" : "Morfología del cáncer primario en CIE-O-3 (tipo histológico y comportamiento, p. ej. 8500/3). Misma forma que la extensión mcode-histology-morphology-behavior de mCODE, por lo que se mapea 1:1.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DO",
      "display" : "Dominican Republic"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  }],
  "kind" : "complex-type",
  "abstract" : false,
  "context" : [{
    "type" : "element",
    "expression" : "Condition"
  }],
  "type" : "Extension",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Extension",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Extension",
      "path" : "Extension",
      "short" : "Morfología y comportamiento histológico DO",
      "definition" : "Morfología del cáncer primario en CIE-O-3 (tipo histológico y comportamiento, p. ej. 8500/3). Misma forma que la extensión mcode-histology-morphology-behavior de mCODE, por lo que se mapea 1:1."
    },
    {
      "id" : "Extension.extension",
      "path" : "Extension.extension",
      "max" : "0"
    },
    {
      "id" : "Extension.url",
      "path" : "Extension.url",
      "fixedUri" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/HistologyMorphologyBehaviorDO"
    },
    {
      "id" : "Extension.value[x]",
      "path" : "Extension.value[x]",
      "min" : 1,
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://digital.msp.gob.do/fhir/conectaton/ValueSet/VSCIEO3MorfologiaDO"
      }
    }]
  }
}

```
