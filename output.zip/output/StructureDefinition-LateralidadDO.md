# Lateralidad DO - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Lateralidad DO**

## Extension: Lateralidad DO 

| | |
| :--- | :--- |
| *Official URL*:https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/LateralidadDO | *Version*:0.2.2 |
| Draft as of 2026-11-17 | *Computable Name*:LateralidadDO |

Lateralidad del sitio del cáncer primario.

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [Cáncer Primario DO](StructureDefinition-PrimaryCancerConditionDO.md)
* Examples for this Extension: [Bundle/BundleOncoDOExample](Bundle-BundleOncoDOExample.md) and [Condition/PrimaryCancerConditionDOExample](Condition-PrimaryCancerConditionDOExample.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/msp.fhir.do|current/StructureDefinition/StructureDefinition-LateralidadDO.json)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-LateralidadDO.csv), [Excel](StructureDefinition-LateralidadDO.xlsx), [Schematron](StructureDefinition-LateralidadDO.sch) 

#### Terminology Bindings

#### Constraints



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "LateralidadDO",
  "url" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/LateralidadDO",
  "version" : "0.2.2",
  "name" : "LateralidadDO",
  "title" : "Lateralidad DO",
  "status" : "draft",
  "date" : "2026-11-17T15:46:26-03:00",
  "publisher" : "Ministerio de Salud Pública y Asistencia Social",
  "contact" : [{
    "name" : "Ministerio de Salud Pública y Asistencia Social",
    "telecom" : [{
      "system" : "url",
      "value" : "https://msp.gob.do"
    }]
  }],
  "description" : "Lateralidad del sitio del cáncer primario.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DO",
      "display" : "Dominican Republic"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  }],
  "kind" : "complex-type",
  "abstract" : false,
  "context" : [{
    "type" : "element",
    "expression" : "Condition.bodySite"
  }],
  "type" : "Extension",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Extension",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Extension",
      "path" : "Extension",
      "short" : "Lateralidad DO",
      "definition" : "Lateralidad del sitio del cáncer primario."
    },
    {
      "id" : "Extension.extension",
      "path" : "Extension.extension",
      "max" : "0"
    },
    {
      "id" : "Extension.url",
      "path" : "Extension.url",
      "fixedUri" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/LateralidadDO"
    },
    {
      "id" : "Extension.value[x]",
      "path" : "Extension.value[x]",
      "min" : 1,
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://digital.msp.gob.do/fhir/conectaton/ValueSet/VSLateralidadDO"
      }
    }]
  }
}

```
