# ListDO - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ListDO**

## Resource Profile: ListDO 

| | |
| :--- | :--- |
| *Official URL*:https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/ListDO | *Version*:0.2.2 |
| Draft as of 2026-11-17 | *Computable Name*:ListDO |

**Usages:**

* Use this Perfil: [BundleTransaccDO](StructureDefinition-BundleTransaccDO.md)
* Examples for this Perfil: [List/ListDOExample](List-ListDOExample.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/msp.fhir.do|current/StructureDefinition/StructureDefinition-ListDO.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-ListDO.csv), [Excel](StructureDefinition-ListDO.xlsx), [Schematron](StructureDefinition-ListDO.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "ListDO",
  "url" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/ListDO",
  "version" : "0.2.2",
  "name" : "ListDO",
  "status" : "draft",
  "date" : "2026-11-17T15:46:26-03:00",
  "publisher" : "Ministerio de Salud Pública y Asistencia Social",
  "contact" : [{
    "name" : "Ministerio de Salud Pública y Asistencia Social",
    "telecom" : [{
      "system" : "url",
      "value" : "https://msp.gob.do"
    }]
  }],
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DO",
      "display" : "Dominican Republic"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "SubmissionSet-Mapping",
    "uri" : "XDS",
    "name" : "XDS and MHD Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "List",
  "baseDefinition" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.Minimal.SubmissionSet",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "List.subject",
      "path" : "List.subject",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/PatientDO"]
      }]
    },
    {
      "id" : "List.entry.item",
      "path" : "List.entry.item",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/DocumentReferenceDO",
        "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/DocumentReferenceDOOnco",
        "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/DocumentReferenceDONotif",
        "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/DocumentReferenceDOLab"]
      }]
    }]
  }
}

```
