# Organización DO - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Organización DO**

## Resource Profile: Organización DO 

| | |
| :--- | :--- |
| *Official URL*:https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/OrganizationDO | *Version*:0.2.2 |
| Draft as of 2026-11-17 | *Computable Name*:OrganizationDO |

 
Perfil para establecimientos, instituciones y unidades organizacionales de salud. 

**Usages:**

* Use this Perfil: [BundleDocDO](StructureDefinition-BundleDocDO.md) and [BundleNPSDO](StructureDefinition-BundleNPSDO.md)
* Refer to this Perfil: [Tratamiento Farmacológico Oncológico DO](StructureDefinition-CancerMedicationStatementDO.md), [Estadio del Cáncer DO](StructureDefinition-CancerStageDO.md), [Documento Clínico DO](StructureDefinition-CompositionDO.md), [Documento Clínico IPS DO](StructureDefinition-CompositionDONPS.md)... Show 6 more, [Documento Clínico Oncologico](StructureDefinition-CompositionDOOnco.md), [DocumentReferenceDO](StructureDefinition-DocumentReferenceDO.md), [Informe de Patología DO](StructureDefinition-PathologyReportDO.md), [Resultado de Patología DO](StructureDefinition-PathologyResultDO.md), [Curso de Radioterapia DO](StructureDefinition-RadiotherapyCourseDO.md) and [Cirugía Oncológica DO](StructureDefinition-SurgicalProcedureDO.md)
* Examples for this Perfil: [Centro de Salud DO Ejemplo](Organization-OrganizationDOExample.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/msp.fhir.do|current/StructureDefinition/StructureDefinition-OrganizationDO.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-OrganizationDO.csv), [Excel](StructureDefinition-OrganizationDO.xlsx), [Schematron](StructureDefinition-OrganizationDO.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "OrganizationDO",
  "url" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/OrganizationDO",
  "version" : "0.2.2",
  "name" : "OrganizationDO",
  "title" : "Organización DO",
  "status" : "draft",
  "date" : "2026-11-17T15:46:26-03:00",
  "publisher" : "Ministerio de Salud Pública y Asistencia Social",
  "contact" : [{
    "name" : "Ministerio de Salud Pública y Asistencia Social",
    "telecom" : [{
      "system" : "url",
      "value" : "https://msp.gob.do"
    }]
  }],
  "description" : "Perfil para establecimientos, instituciones y unidades organizacionales de salud.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DO",
      "display" : "Dominican Republic"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "servd",
    "uri" : "http://www.omg.org/spec/ServD/1.0/",
    "name" : "ServD"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Organization",
  "baseDefinition" : "http://hl7.org/fhir/uv/ips/StructureDefinition/Organization-uv-ips",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Organization.identifier",
      "path" : "Organization.identifier",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Organization.identifier.system",
      "path" : "Organization.identifier.system",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Organization.identifier.value",
      "path" : "Organization.identifier.value",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Organization.active",
      "path" : "Organization.active",
      "mustSupport" : true
    },
    {
      "id" : "Organization.type",
      "path" : "Organization.type",
      "mustSupport" : true
    },
    {
      "id" : "Organization.telecom",
      "path" : "Organization.telecom",
      "mustSupport" : true
    },
    {
      "id" : "Organization.address",
      "path" : "Organization.address",
      "mustSupport" : true
    },
    {
      "id" : "Organization.partOf",
      "path" : "Organization.partOf",
      "mustSupport" : true
    }]
  }
}

```
