# Informe de Patología DO - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Informe de Patología DO**

## Resource Profile: Informe de Patología DO 

| | |
| :--- | :--- |
| *Official URL*:https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/PathologyReportDO | *Version*:0.2.2 |
| Draft as of 2026-11-17 | *Computable Name*:PathologyReportDO |

 
Informe de anatomía patológica del cáncer primario. Reúne la biopsia, el grado histológico y los marcadores cualitativos (RE, RP, HER2). Breslow y variantes genómicas van en PathologyResultDO. Deriva de DiagnosticReport y no de DiagnosticReportDO, porque ese perfil exige presentedForm 1..1. 

**Usages:**

* Use this Perfil: [Bundle Documento Oncológico](StructureDefinition-BundleOncoDO.md)
* Refer to this Perfil: [Documento Clínico Oncologico](StructureDefinition-CompositionDOOnco.md) and [Cáncer Primario DO](StructureDefinition-PrimaryCancerConditionDO.md)
* Examples for this Perfil: [DiagnosticReport/PathologyReportDOExample](DiagnosticReport-PathologyReportDOExample.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/msp.fhir.do|current/StructureDefinition/StructureDefinition-PathologyReportDO.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-PathologyReportDO.csv), [Excel](StructureDefinition-PathologyReportDO.xlsx), [Schematron](StructureDefinition-PathologyReportDO.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "PathologyReportDO",
  "url" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/PathologyReportDO",
  "version" : "0.2.2",
  "name" : "PathologyReportDO",
  "title" : "Informe de Patología DO",
  "status" : "draft",
  "date" : "2026-11-17T15:46:26-03:00",
  "publisher" : "Ministerio de Salud Pública y Asistencia Social",
  "contact" : [{
    "name" : "Ministerio de Salud Pública y Asistencia Social",
    "telecom" : [{
      "system" : "url",
      "value" : "https://msp.gob.do"
    }]
  }],
  "description" : "Informe de anatomía patológica del cáncer primario. Reúne la biopsia, el grado histológico y los marcadores cualitativos (RE, RP, HER2). Breslow y variantes genómicas van en PathologyResultDO. Deriva de DiagnosticReport y no de DiagnosticReportDO, porque ese perfil exige presentedForm 1..1.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DO",
      "display" : "Dominican Republic"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "DiagnosticReport",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/DiagnosticReport",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "DiagnosticReport.status",
      "path" : "DiagnosticReport.status",
      "mustSupport" : true
    },
    {
      "id" : "DiagnosticReport.code",
      "path" : "DiagnosticReport.code",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "11526-1",
          "display" : "Pathology study"
        }]
      },
      "mustSupport" : true
    },
    {
      "id" : "DiagnosticReport.subject",
      "path" : "DiagnosticReport.subject",
      "min" : 1,
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/PatientDO"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "DiagnosticReport.effective[x]",
      "path" : "DiagnosticReport.effective[x]",
      "short" : "Fecha de toma de la muestra (biopsia)",
      "min" : 1,
      "type" : [{
        "code" : "dateTime"
      }],
      "mustSupport" : true
    },
    {
      "id" : "DiagnosticReport.issued",
      "path" : "DiagnosticReport.issued",
      "short" : "Fecha de emisión del informe",
      "mustSupport" : true
    },
    {
      "id" : "DiagnosticReport.performer",
      "path" : "DiagnosticReport.performer",
      "short" : "Establecimiento que emite el informe",
      "min" : 1,
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/OrganizationDO"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "DiagnosticReport.result",
      "path" : "DiagnosticReport.result",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/PathologyResultDO"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "DiagnosticReport.conclusion",
      "path" : "DiagnosticReport.conclusion",
      "short" : "Diagnóstico del patólogo en texto libre",
      "mustSupport" : true
    },
    {
      "id" : "DiagnosticReport.conclusionCode",
      "path" : "DiagnosticReport.conclusionCode",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "$this"
        }],
        "rules" : "open"
      },
      "short" : "Grado histológico y marcadores cualitativos",
      "mustSupport" : true
    },
    {
      "id" : "DiagnosticReport.conclusionCode:gradoHistologico",
      "path" : "DiagnosticReport.conclusionCode",
      "sliceName" : "gradoHistologico",
      "short" : "Grado histológico",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true,
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://digital.msp.gob.do/fhir/conectaton/ValueSet/VSGradoHistologicoDO"
      }
    },
    {
      "id" : "DiagnosticReport.conclusionCode:receptorEstrogeno",
      "path" : "DiagnosticReport.conclusionCode",
      "sliceName" : "receptorEstrogeno",
      "short" : "Receptor de estrógeno (RE)",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true,
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://digital.msp.gob.do/fhir/conectaton/ValueSet/VSReceptorEstrogenoDO"
      }
    },
    {
      "id" : "DiagnosticReport.conclusionCode:receptorProgesterona",
      "path" : "DiagnosticReport.conclusionCode",
      "sliceName" : "receptorProgesterona",
      "short" : "Receptor de progesterona (RP)",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true,
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://digital.msp.gob.do/fhir/conectaton/ValueSet/VSReceptorProgesteronaDO"
      }
    },
    {
      "id" : "DiagnosticReport.conclusionCode:her2",
      "path" : "DiagnosticReport.conclusionCode",
      "sliceName" : "her2",
      "short" : "HER2",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true,
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://digital.msp.gob.do/fhir/conectaton/ValueSet/VSHER2DO"
      }
    },
    {
      "id" : "DiagnosticReport.presentedForm",
      "path" : "DiagnosticReport.presentedForm",
      "short" : "Informe original (PDF), opcional",
      "mustSupport" : true
    }]
  }
}

```
