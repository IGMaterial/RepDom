# Resultado de Patología DO - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Resultado de Patología DO**

## Resource Profile: Resultado de Patología DO 

| | |
| :--- | :--- |
| *Official URL*:https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/PathologyResultDO | *Version*:0.2.2 |
| Draft as of 2026-11-17 | *Computable Name*:PathologyResultDO |

 
Resultado estructurado de patología que no cabe en DiagnosticReport.conclusionCode: profundidad de Breslow (mm) o variante genómica. Lo referencia PathologyReportDO.result. 

**Usages:**

* Use this Perfil: [Bundle Documento Oncológico](StructureDefinition-BundleOncoDO.md)
* Refer to this Perfil: [Informe de Patología DO](StructureDefinition-PathologyReportDO.md)
* Examples for this Perfil: [Observation/PathologyResultDOExample](Observation-PathologyResultDOExample.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/msp.fhir.do|current/StructureDefinition/StructureDefinition-PathologyResultDO.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-PathologyResultDO.csv), [Excel](StructureDefinition-PathologyResultDO.xlsx), [Schematron](StructureDefinition-PathologyResultDO.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "PathologyResultDO",
  "url" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/PathologyResultDO",
  "version" : "0.2.2",
  "name" : "PathologyResultDO",
  "title" : "Resultado de Patología DO",
  "status" : "draft",
  "date" : "2026-11-17T15:46:26-03:00",
  "publisher" : "Ministerio de Salud Pública y Asistencia Social",
  "contact" : [{
    "name" : "Ministerio de Salud Pública y Asistencia Social",
    "telecom" : [{
      "system" : "url",
      "value" : "https://msp.gob.do"
    }]
  }],
  "description" : "Resultado estructurado de patología que no cabe en DiagnosticReport.conclusionCode: profundidad de Breslow (mm) o variante genómica. Lo referencia PathologyReportDO.result.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DO",
      "display" : "Dominican Republic"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "sct-concept",
    "uri" : "http://snomed.info/conceptdomain",
    "name" : "SNOMED CT Concept Domain Binding"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "sct-attr",
    "uri" : "http://snomed.org/attributebinding",
    "name" : "SNOMED CT Attribute Binding"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Observation",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Observation",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Observation",
      "path" : "Observation",
      "constraint" : [{
        "key" : "onco-breslow-1",
        "severity" : "error",
        "human" : "Si el resultado es Breslow, el valor debe ser valueQuantity en milímetros (UCUM mm).",
        "expression" : "code.coding.where(code = 'breslow').exists() implies (value.ofType(Quantity).exists() and value.ofType(Quantity).code = 'mm')",
        "source" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/PathologyResultDO"
      },
      {
        "key" : "onco-variante-1",
        "severity" : "error",
        "human" : "Si el resultado es una variante genómica, debe informar el gen en component.",
        "expression" : "code.coding.where(code = 'variante-genomica').exists() implies component.where(code.coding.code = 'gen').exists()",
        "source" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/PathologyResultDO"
      }]
    },
    {
      "id" : "Observation.status",
      "path" : "Observation.status",
      "mustSupport" : true
    },
    {
      "id" : "Observation.code",
      "path" : "Observation.code",
      "mustSupport" : true,
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://digital.msp.gob.do/fhir/conectaton/ValueSet/VSCodigoResultadoPatologiaDO"
      }
    },
    {
      "id" : "Observation.subject",
      "path" : "Observation.subject",
      "min" : 1,
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/PatientDO"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Observation.focus",
      "path" : "Observation.focus",
      "short" : "Cáncer primario al que se refiere el resultado",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/PrimaryCancerConditionDO"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Observation.effective[x]",
      "path" : "Observation.effective[x]",
      "mustSupport" : true
    },
    {
      "id" : "Observation.performer",
      "path" : "Observation.performer",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/OrganizationDO"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Observation.value[x]",
      "path" : "Observation.value[x]",
      "short" : "Breslow: valueQuantity en mm",
      "mustSupport" : true
    },
    {
      "id" : "Observation.component",
      "path" : "Observation.component",
      "slicing" : {
        "discriminator" : [{
          "type" : "pattern",
          "path" : "code"
        }],
        "rules" : "open"
      },
      "mustSupport" : true
    },
    {
      "id" : "Observation.component:gen",
      "path" : "Observation.component",
      "sliceName" : "gen",
      "short" : "Gen (HGNC)",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Observation.component:gen.code",
      "path" : "Observation.component.code",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSObservacionesOncoDO",
          "code" : "gen"
        }]
      }
    },
    {
      "id" : "Observation.component:gen.value[x]",
      "path" : "Observation.component.value[x]",
      "type" : [{
        "code" : "CodeableConcept"
      }]
    },
    {
      "id" : "Observation.component:hgvs",
      "path" : "Observation.component",
      "sliceName" : "hgvs",
      "short" : "Variante en nomenclatura HGVS",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Observation.component:hgvs.code",
      "path" : "Observation.component.code",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSObservacionesOncoDO",
          "code" : "hgvs"
        }]
      }
    },
    {
      "id" : "Observation.component:hgvs.value[x]",
      "path" : "Observation.component.value[x]",
      "type" : [{
        "code" : "CodeableConcept"
      }]
    }]
  }
}

```
