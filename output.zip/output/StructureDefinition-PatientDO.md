# Paciente DO - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Paciente DO**

## Resource Profile: Paciente DO 

| | |
| :--- | :--- |
| *Official URL*:https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/PatientDO | *Version*:0.2.2 |
| Draft as of 2026-11-17 | *Computable Name*:PatientDO |

 
Perfil para representar pacientes. 

**Usages:**

* Use this Perfil: [BundleDocDO](StructureDefinition-BundleDocDO.md), [BundleNPSDO](StructureDefinition-BundleNPSDO.md) and [BundleTransaccDO](StructureDefinition-BundleTransaccDO.md)
* Refer to this Perfil: [Alergia o Intolerancia DO](StructureDefinition-AllergyIntoleranceDO.md), [Estadio del Cáncer DO](StructureDefinition-CancerStageDO.md), [Documento Clínico DO](StructureDefinition-CompositionDO.md), [Documento Clínico IPS DO](StructureDefinition-CompositionDONPS.md)... Show 12 more, [Condición DO](StructureDefinition-ConditionDO.md), [DiagnosticReportDO](StructureDefinition-DiagnosticReportDO.md), [DocumentReferenceDO](StructureDefinition-DocumentReferenceDO.md), [ListDO](StructureDefinition-ListDO.md), [Historial Farmacológico DO](StructureDefinition-MedicationStatementDO.md), [Estado de embarazo DO](StructureDefinition-ObservationEstadoEmbarazoDO.md), [Signo o síntoma DO](StructureDefinition-ObservationSignoSintomaDO.md), [Viajes y exposición DO](StructureDefinition-ObservationViajesExposicionDO.md), [Informe de Patología DO](StructureDefinition-PathologyReportDO.md), [Resultado de Patología DO](StructureDefinition-PathologyResultDO.md), [Curso de Radioterapia DO](StructureDefinition-RadiotherapyCourseDO.md) and [Cirugía Oncológica DO](StructureDefinition-SurgicalProcedureDO.md)
* Examples for this Perfil: [Patient/PatientDOExample](Patient-PatientDOExample.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/msp.fhir.do|current/StructureDefinition/StructureDefinition-PatientDO.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-PatientDO.csv), [Excel](StructureDefinition-PatientDO.xlsx), [Schematron](StructureDefinition-PatientDO.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "PatientDO",
  "url" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/PatientDO",
  "version" : "0.2.2",
  "name" : "PatientDO",
  "title" : "Paciente DO",
  "status" : "draft",
  "date" : "2026-11-17T15:46:26-03:00",
  "publisher" : "Ministerio de Salud Pública y Asistencia Social",
  "contact" : [{
    "name" : "Ministerio de Salud Pública y Asistencia Social",
    "telecom" : [{
      "system" : "url",
      "value" : "https://msp.gob.do"
    }]
  }],
  "description" : "Perfil para representar pacientes.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DO",
      "display" : "Dominican Republic"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "cda",
    "uri" : "http://hl7.org/v3/cda",
    "name" : "CDA (R2)"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "loinc",
    "uri" : "http://loinc.org",
    "name" : "LOINC code for the element"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Patient",
  "baseDefinition" : "http://hl7.org/fhir/uv/ips/StructureDefinition/Patient-uv-ips",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Patient.identifier",
      "path" : "Patient.identifier",
      "min" : 1
    },
    {
      "id" : "Patient.identifier.type",
      "path" : "Patient.identifier.type",
      "min" : 1,
      "mustSupport" : true,
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://digital.msp.gob.do/fhir/conectaton/ValueSet/VSTipoIdentifPacDO"
      }
    },
    {
      "id" : "Patient.identifier.value",
      "path" : "Patient.identifier.value",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Patient.name.extension:segundoApellido",
      "path" : "Patient.name.extension",
      "sliceName" : "segundoApellido",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/SegundoApellidoDO"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Patient.name.family",
      "path" : "Patient.name.family",
      "min" : 1
    },
    {
      "id" : "Patient.name.given",
      "path" : "Patient.name.given",
      "min" : 1
    },
    {
      "id" : "Patient.address.city",
      "path" : "Patient.address.city",
      "mustSupport" : true
    },
    {
      "id" : "Patient.address.state",
      "path" : "Patient.address.state",
      "mustSupport" : true
    },
    {
      "id" : "Patient.address.country",
      "path" : "Patient.address.country",
      "mustSupport" : true
    }]
  }
}

```
