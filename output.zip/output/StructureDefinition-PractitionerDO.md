# Profesional DO - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Profesional DO**

## Resource Profile: Profesional DO 

| | |
| :--- | :--- |
| *Official URL*:https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/PractitionerDO | *Version*:0.2.2 |
| Draft as of 2026-11-17 | *Computable Name*:PractitionerDO |

 
Perfil para profesionales de salud. 

**Usages:**

* Use this Perfil: [BundleNPSDO](StructureDefinition-BundleNPSDO.md)
* Refer to this Perfil: [Alergia o Intolerancia DO](StructureDefinition-AllergyIntoleranceDO.md), [Documento Clínico DO](StructureDefinition-CompositionDO.md), [Documento Clínico IPS DO](StructureDefinition-CompositionDONPS.md) and [Condición DO](StructureDefinition-ConditionDO.md)
* Examples for this Perfil: [Practitioner/PractitionerDOExample](Practitioner-PractitionerDOExample.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/msp.fhir.do|current/StructureDefinition/StructureDefinition-PractitionerDO.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-PractitionerDO.csv), [Excel](StructureDefinition-PractitionerDO.xlsx), [Schematron](StructureDefinition-PractitionerDO.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "PractitionerDO",
  "url" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/PractitionerDO",
  "version" : "0.2.2",
  "name" : "PractitionerDO",
  "title" : "Profesional DO",
  "status" : "draft",
  "date" : "2026-11-17T15:46:26-03:00",
  "publisher" : "Ministerio de Salud Pública y Asistencia Social",
  "contact" : [{
    "name" : "Ministerio de Salud Pública y Asistencia Social",
    "telecom" : [{
      "system" : "url",
      "value" : "https://msp.gob.do"
    }]
  }],
  "description" : "Perfil para profesionales de salud.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DO",
      "display" : "Dominican Republic"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "servd",
    "uri" : "http://www.omg.org/spec/ServD/1.0/",
    "name" : "ServD"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Practitioner",
  "baseDefinition" : "http://hl7.org/fhir/uv/ips/StructureDefinition/Practitioner-uv-ips",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Practitioner.identifier",
      "path" : "Practitioner.identifier",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Practitioner.identifier.type",
      "path" : "Practitioner.identifier.type",
      "mustSupport" : true,
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://digital.msp.gob.do/fhir/conectaton/ValueSet/VSTipoIdentifProfDO"
      }
    },
    {
      "id" : "Practitioner.identifier.value",
      "path" : "Practitioner.identifier.value",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Practitioner.name.extension:segundoApellido",
      "path" : "Practitioner.name.extension",
      "sliceName" : "segundoApellido",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/SegundoApellidoDO"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Practitioner.name.family",
      "path" : "Practitioner.name.family",
      "min" : 1
    },
    {
      "id" : "Practitioner.name.given",
      "path" : "Practitioner.name.given",
      "min" : 1
    },
    {
      "id" : "Practitioner.qualification",
      "path" : "Practitioner.qualification",
      "mustSupport" : true
    },
    {
      "id" : "Practitioner.qualification.identifier",
      "path" : "Practitioner.qualification.identifier",
      "mustSupport" : true
    },
    {
      "id" : "Practitioner.qualification.code",
      "path" : "Practitioner.qualification.code",
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://digital.msp.gob.do/fhir/conectaton/ValueSet/VSEspecialidadDO"
      }
    }]
  }
}

```
