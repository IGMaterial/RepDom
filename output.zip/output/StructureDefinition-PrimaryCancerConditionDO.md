# Cáncer Primario DO - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Cáncer Primario DO**

## Resource Profile: Cáncer Primario DO 

| | |
| :--- | :--- |
| *Official URL*:https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/PrimaryCancerConditionDO | *Version*:0.2.2 |
| Draft as of 2026-11-17 | *Computable Name*:PrimaryCancerConditionDO |

 
Cáncer primario del caso registrado. Es el ancla del documento oncológico: patología, estadificación y tratamientos lo referencian. 

**Usages:**

* Use this Perfil: [Bundle Documento Oncológico](StructureDefinition-BundleOncoDO.md)
* Refer to this Perfil: [Tratamiento Farmacológico Oncológico DO](StructureDefinition-CancerMedicationStatementDO.md), [Estadio del Cáncer DO](StructureDefinition-CancerStageDO.md), [Documento Clínico Oncologico](StructureDefinition-CompositionDOOnco.md), [Resultado de Patología DO](StructureDefinition-PathologyResultDO.md)... Show 2 more, [Curso de Radioterapia DO](StructureDefinition-RadiotherapyCourseDO.md) and [Cirugía Oncológica DO](StructureDefinition-SurgicalProcedureDO.md)
* Examples for this Perfil: [Condition/PrimaryCancerConditionDOExample](Condition-PrimaryCancerConditionDOExample.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/msp.fhir.do|current/StructureDefinition/StructureDefinition-PrimaryCancerConditionDO.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-PrimaryCancerConditionDO.csv), [Excel](StructureDefinition-PrimaryCancerConditionDO.xlsx), [Schematron](StructureDefinition-PrimaryCancerConditionDO.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "PrimaryCancerConditionDO",
  "url" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/PrimaryCancerConditionDO",
  "version" : "0.2.2",
  "name" : "PrimaryCancerConditionDO",
  "title" : "Cáncer Primario DO",
  "status" : "draft",
  "date" : "2026-11-17T15:46:26-03:00",
  "publisher" : "Ministerio de Salud Pública y Asistencia Social",
  "contact" : [{
    "name" : "Ministerio de Salud Pública y Asistencia Social",
    "telecom" : [{
      "system" : "url",
      "value" : "https://msp.gob.do"
    }]
  }],
  "description" : "Cáncer primario del caso registrado. Es el ancla del documento oncológico: patología, estadificación y tratamientos lo referencian.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DO",
      "display" : "Dominican Republic"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "sct-concept",
    "uri" : "http://snomed.info/conceptdomain",
    "name" : "SNOMED CT Concept Domain Binding"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Condition",
  "baseDefinition" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/ConditionDO",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Condition.extension",
      "path" : "Condition.extension",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "url"
        }],
        "ordered" : false,
        "rules" : "open"
      }
    },
    {
      "id" : "Condition.extension:morfologia",
      "path" : "Condition.extension",
      "sliceName" : "morfologia",
      "short" : "Morfología CIE-O-3 (p. ej. 8500/3)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/HistologyMorphologyBehaviorDO"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Condition.code",
      "path" : "Condition.code",
      "short" : "Diagnóstico CIE-10",
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://digital.msp.gob.do/fhir/conectaton/ValueSet/VSCIE10DO"
      }
    },
    {
      "id" : "Condition.bodySite",
      "path" : "Condition.bodySite",
      "short" : "Topografía CIE-O-3 (p. ej. C50.4)",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true,
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://digital.msp.gob.do/fhir/conectaton/ValueSet/VSCIEO3TopografiaDO"
      }
    },
    {
      "id" : "Condition.bodySite.extension:lateralidad",
      "path" : "Condition.bodySite.extension",
      "sliceName" : "lateralidad",
      "short" : "Lateralidad del sitio primario",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/LateralidadDO"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Condition.onset[x]",
      "path" : "Condition.onset[x]",
      "short" : "Fecha de diagnóstico",
      "min" : 1,
      "type" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/elementdefinition-type-must-support",
          "valueBoolean" : true
        }],
        "code" : "dateTime"
      }]
    },
    {
      "id" : "Condition.evidence",
      "path" : "Condition.evidence",
      "mustSupport" : true
    },
    {
      "id" : "Condition.evidence.detail",
      "path" : "Condition.evidence.detail",
      "short" : "Informe de patología que respalda el diagnóstico",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/PathologyReportDO"]
      }],
      "mustSupport" : true
    }]
  }
}

```
