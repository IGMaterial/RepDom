# Segundo Apellido DO - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Segundo Apellido DO**

## Extension: Segundo Apellido DO 

| | |
| :--- | :--- |
| *Official URL*:https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/SegundoApellidoDO | *Version*:0.2.2 |
| Draft as of 2026-11-17 | *Computable Name*:SegundoApellidoDO |

Extensión para representar el segundo apellido cuando se requiere conservarlo separado de HumanName.family.

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [Paciente DO](StructureDefinition-PatientDO.md) and [Profesional DO](StructureDefinition-PractitionerDO.md)
* Examples for this Extension: [Bundle/BundleLabDOExample](Bundle-BundleLabDOExample.md), [Bundle/BundleNPSDOExample](Bundle-BundleNPSDOExample.md), [Bundle/BundleNotifDOExample](Bundle-BundleNotifDOExample.md), [Bundle/BundleOncoDOExample](Bundle-BundleOncoDOExample.md)... Show 2 more, [Bundle/BundleTransaccDOExample](Bundle-BundleTransaccDOExample.md) and [Patient/PatientDOExample](Patient-PatientDOExample.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/msp.fhir.do|current/StructureDefinition/StructureDefinition-SegundoApellidoDO.json)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-SegundoApellidoDO.csv), [Excel](StructureDefinition-SegundoApellidoDO.xlsx), [Schematron](StructureDefinition-SegundoApellidoDO.sch) 

#### Constraints



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "SegundoApellidoDO",
  "url" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/SegundoApellidoDO",
  "version" : "0.2.2",
  "name" : "SegundoApellidoDO",
  "title" : "Segundo Apellido DO",
  "status" : "draft",
  "date" : "2026-11-17T15:46:26-03:00",
  "publisher" : "Ministerio de Salud Pública y Asistencia Social",
  "contact" : [{
    "name" : "Ministerio de Salud Pública y Asistencia Social",
    "telecom" : [{
      "system" : "url",
      "value" : "https://msp.gob.do"
    }]
  }],
  "description" : "Extensión para representar el segundo apellido cuando se requiere conservarlo separado de HumanName.family.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DO",
      "display" : "Dominican Republic"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  }],
  "kind" : "complex-type",
  "abstract" : false,
  "context" : [{
    "type" : "element",
    "expression" : "Element"
  }],
  "type" : "Extension",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Extension",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Extension",
      "path" : "Extension",
      "short" : "Segundo Apellido DO",
      "definition" : "Extensión para representar el segundo apellido cuando se requiere conservarlo separado de HumanName.family."
    },
    {
      "id" : "Extension.extension",
      "path" : "Extension.extension",
      "max" : "0"
    },
    {
      "id" : "Extension.url",
      "path" : "Extension.url",
      "fixedUri" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/SegundoApellidoDO"
    },
    {
      "id" : "Extension.value[x]",
      "path" : "Extension.value[x]",
      "min" : 1,
      "type" : [{
        "code" : "string"
      }]
    }]
  }
}

```
