# Tipos de informe de laboratorio - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Tipos de informe de laboratorio**

## ValueSet: Tipos de informe de laboratorio 

| | |
| :--- | :--- |
| *Official URL*:https://digital.msp.gob.do/fhir/conectaton/ValueSet/DiagnosticReportCodeVS | *Version*:0.2.2 |
| Draft as of 2026-11-17 | *Computable Name*:DiagnosticReportCodeVS |

 
Conjunto de valores para los tipos de informe de laboratorio. 

 **References** 

* [DiagnosticReportDO](StructureDefinition-DiagnosticReportDO.md)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "DiagnosticReportCodeVS",
  "url" : "https://digital.msp.gob.do/fhir/conectaton/ValueSet/DiagnosticReportCodeVS",
  "version" : "0.2.2",
  "name" : "DiagnosticReportCodeVS",
  "title" : "Tipos de informe de laboratorio",
  "status" : "draft",
  "date" : "2026-11-17T15:46:26-03:00",
  "publisher" : "Ministerio de Salud Pública y Asistencia Social",
  "contact" : [{
    "name" : "Ministerio de Salud Pública y Asistencia Social",
    "telecom" : [{
      "system" : "url",
      "value" : "https://msp.gob.do"
    }]
  }],
  "description" : "Conjunto de valores para los tipos de informe de laboratorio.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DO",
      "display" : "Dominican Republic"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "http://loinc.org",
      "concept" : [{
        "code" : "11502-2",
        "display" : "Laboratory report"
      },
      {
        "code" : "18748-4",
        "display" : "Laboratory report"
      },
      {
        "code" : "10524-7",
        "display" : "Citología cervical"
      },
      {
        "code" : "11526-1",
        "display" : "Informe de patología"
      },
      {
        "code" : "11545-1",
        "display" : "Baciloscopia BAAR en esputo"
      },
      {
        "code" : "20507-0",
        "display" : "RPR"
      },
      {
        "code" : "2160-0",
        "display" : "Creatinina"
      },
      {
        "code" : "23201-7",
        "display" : "Leptospira IgM por inmunoensayo"
      },
      {
        "code" : "2345-7",
        "display" : "Glucosa"
      },
      {
        "code" : "24110-9",
        "display" : "Anticuerpos contra Treponema pallidum"
      },
      {
        "code" : "24113-3",
        "display" : "Anti-HBc IgM"
      },
      {
        "code" : "24605-8",
        "display" : "Mamografía diagnóstica"
      },
      {
        "code" : "2857-1",
        "display" : "PSA total"
      },
      {
        "code" : "29663-2",
        "display" : "Dengue anticuerpos IgM"
      },
      {
        "code" : "38379-4",
        "display" : "ADN del complejo Mycobacterium tuberculosis"
      },
      {
        "code" : "4548-4",
        "display" : "Hemoglobina glicosilada HbA1c"
      },
      {
        "code" : "5196-1",
        "display" : "HBsAg"
      },
      {
        "code" : "56888-1",
        "display" : "VIH 1+2 anticuerpos y antígeno p24"
      },
      {
        "code" : "58410-2",
        "display" : "Hemograma completo por recuento automatizado"
      },
      {
        "code" : "82675-0",
        "display" : "VPH de alto riesgo"
      },
      {
        "code" : "91064-6",
        "display" : "Antígeno NS1 dengue"
      }]
    }]
  }
}

```
