# Identificadores de Paciente - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Identificadores de Paciente**

## ValueSet: Identificadores de Paciente 

| | |
| :--- | :--- |
| *Official URL*:https://digital.msp.gob.do/fhir/conectaton/ValueSet/VSTipoIdentifPacDO | *Version*:0.2.2 |
| Active as of 2026-11-17 | *Computable Name*:VSTipoIdentifPacDO |

 
Conjunto de valores para los Identificadores de Paciente. 

 **References** 

* [Paciente DO](StructureDefinition-PatientDO.md)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "VSTipoIdentifPacDO",
  "url" : "https://digital.msp.gob.do/fhir/conectaton/ValueSet/VSTipoIdentifPacDO",
  "version" : "0.2.2",
  "name" : "VSTipoIdentifPacDO",
  "title" : "Identificadores de Paciente",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-11-17T15:46:26-03:00",
  "publisher" : "Ministerio de Salud Pública y Asistencia Social",
  "contact" : [{
    "name" : "Ministerio de Salud Pública y Asistencia Social",
    "telecom" : [{
      "system" : "url",
      "value" : "https://msp.gob.do"
    }]
  }],
  "description" : "Conjunto de valores para los Identificadores de Paciente.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DO",
      "display" : "Dominican Republic"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "https://digital.msp.gob.do/fhir/conectaton/CodeSystem/CSIdentificadoresPersona",
      "concept" : [{
        "code" : "CED",
        "display" : "Cédula de Identidad"
      },
      {
        "code" : "PAS",
        "display" : "Pasaporte"
      },
      {
        "code" : "NSS",
        "display" : "Número de Seguridad Social"
      },
      {
        "code" : "RN",
        "display" : "Registro Nacional"
      },
      {
        "code" : "MR",
        "display" : "Record médico"
      }]
    }]
  }
}

```
