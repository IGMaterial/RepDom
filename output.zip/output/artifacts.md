# Artifacts Summary - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* **Artifacts Summary**

## Artifacts Summary

This page provides a list of the FHIR artifacts defined as part of this implementation guide.

### Structures: Resource Profiles 

These define constraints on FHIR resources for systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [Alergia o Intolerancia DO](StructureDefinition-AllergyIntoleranceDO.md) | Perfil para alergias, intolerancias y reacciones adversas. |
| [Binario DO](StructureDefinition-BinaryDO.md) | Perfil para recursos binarios. |
| [Bundle Documento Oncológico](StructureDefinition-BundleOncoDO.md) | Documento del caso para el Registro Nacional de Cáncer. Hereda de BundleDocDO las entradas composition, patient (PatientDO) y organization (OrganizationDO). |
| [Bundle de notificación epidemiológica DO](StructureDefinition-BundleNotifDO.md) | Documento de notificación individual con la Composition como primera entrada y los recursos referenciados incluidos. |
| [BundleDocDO](StructureDefinition-BundleDocDO.md) |  |
| [BundleLabDO](StructureDefinition-BundleLabDO.md) |  |
| [BundleNPSDO](StructureDefinition-BundleNPSDO.md) |  |
| [BundleTransaccDO](StructureDefinition-BundleTransaccDO.md) |  |
| [Caso epidemiológico DO](StructureDefinition-ConditionCasoEpidemiologicoDO.md) | Evento o enfermedad principal que motiva la notificación individual. |
| [Cirugía Oncológica DO](StructureDefinition-SurgicalProcedureDO.md) | Procedimiento quirúrgico de tratamiento del cáncer primario. |
| [Conclusión epidemiológica DO](StructureDefinition-ConditionConclusionDO.md) | Conclusión del caso; la clasificación final se registra en code y el estado de confirmación en verificationStatus. |
| [Condición DO](StructureDefinition-ConditionDO.md) | Perfil para problemas, diagnósticos y condiciones clínicas. |
| [Curso de Radioterapia DO](StructureDefinition-RadiotherapyCourseDO.md) | Curso de radioterapia del cáncer primario, con su fecha de inicio y de término. |
| [Cáncer Primario DO](StructureDefinition-PrimaryCancerConditionDO.md) | Cáncer primario del caso registrado. Es el ancla del documento oncológico: patología, estadificación y tratamientos lo referencian. |
| [DiagnosticReportDO](StructureDefinition-DiagnosticReportDO.md) |  |
| [DocumentReferenceDO](StructureDefinition-DocumentReferenceDO.md) |  |
| [DocumentReferenceDOLab](StructureDefinition-DocumentReferenceDOLab.md) |  |
| [DocumentReferenceDONPS](StructureDefinition-DocumentReferenceDONPS.md) |  |
| [DocumentReferenceDONotif](StructureDefinition-DocumentReferenceDONotif.md) |  |
| [DocumentReferenceDOOnco](StructureDefinition-DocumentReferenceDOOnco.md) |  |
| [Documento Clínico DO](StructureDefinition-CompositionDO.md) |  |
| [Documento Clínico IPS DO](StructureDefinition-CompositionDONPS.md) | Perfil para documentos clínicos FHIR. |
| [Documento Clínico Laboratorio](StructureDefinition-CompositionDOLab.md) |  |
| [Documento Clínico Notificación de Caso](StructureDefinition-CompositionDONotif.md) | Notificación individual organizada alrededor de un caso epidemiológico. |
| [Documento Clínico Oncologico](StructureDefinition-CompositionDOOnco.md) | Documento del caso para el Registro Nacional de Cáncer. Todo el contenido clínico se ancla al cáncer primario (PrimaryCancerConditionDO). |
| [Estadio del Cáncer DO](StructureDefinition-CancerStageDO.md) | Grupo de estadio del cáncer primario. |
| [Estado de embarazo DO](StructureDefinition-ObservationEstadoEmbarazoDO.md) | Estado de embarazo en la fecha de evaluación. |
| [Historial Farmacológico DO](StructureDefinition-MedicationStatementDO.md) | Perfil para medicamentos declarados o en uso por el paciente. |
| [Informe de Patología DO](StructureDefinition-PathologyReportDO.md) | Informe de anatomía patológica del cáncer primario. Reúne la biopsia, el grado histológico y los marcadores cualitativos (RE, RP, HER2). Breslow y variantes genómicas van en PathologyResultDO. Deriva de DiagnosticReport y no de DiagnosticReportDO, porque ese perfil exige presentedForm 1..1. |
| [ListDO](StructureDefinition-ListDO.md) |  |
| [Organización DO](StructureDefinition-OrganizationDO.md) | Perfil para establecimientos, instituciones y unidades organizacionales de salud. |
| [Paciente DO](StructureDefinition-PatientDO.md) | Perfil para representar pacientes. |
| [Profesional DO](StructureDefinition-PractitionerDO.md) | Perfil para profesionales de salud. |
| [Resultado de Patología DO](StructureDefinition-PathologyResultDO.md) | Resultado estructurado de patología que no cabe en DiagnosticReport.conclusionCode: profundidad de Breslow (mm) o variante genómica. Lo referencia PathologyReportDO.result. |
| [Signo o síntoma DO](StructureDefinition-ObservationSignoSintomaDO.md) | Hallazgo clínico del caso epidemiológico. |
| [Tratamiento Farmacológico Oncológico DO](StructureDefinition-CancerMedicationStatementDO.md) | Tratamiento sistémico del cáncer primario (quimioterapia, hormonoterapia, inmunoterapia, terapia dirigida). |
| [Viajes y exposición DO](StructureDefinition-ObservationViajesExposicionDO.md) | Antecedente de viaje o exposición relevante para el caso epidemiológico. |

### Structures: Extension Definitions 

These define constraints on FHIR data types for systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [Lateralidad DO](StructureDefinition-LateralidadDO.md) | Lateralidad del sitio del cáncer primario. |
| [Morfología y comportamiento histológico DO](StructureDefinition-HistologyMorphologyBehaviorDO.md) | Morfología del cáncer primario en CIE-O-3 (tipo histológico y comportamiento, p. ej. 8500/3). Misma forma que la extensión mcode-histology-morphology-behavior de mCODE, por lo que se mapea 1:1. |
| [Segundo Apellido DO](StructureDefinition-SegundoApellidoDO.md) | Extensión para representar el segundo apellido cuando se requiere conservarlo separado de HumanName.family. |

### Terminology: Value Sets 

These define sets of codes used by systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [Diagnósticos CIE-10](ValueSet-VSCIE10DO.md) | Códigos de diagnóstico CIE-10 para el cáncer primario. |
| [Especialidades Profesionales DO](ValueSet-VSEspecialidadDO.md) | Conjunto de valores para las Especialidades Profesionales DO. |
| [Grado histológico](ValueSet-VSGradoHistologicoDO.md) | Grado histológico del tumor. |
| [Grupo de estadio](ValueSet-VSEstadioDO.md) | Grupo de estadio del cáncer primario. |
| [Grupo de riesgo infantil](ValueSet-VSRiesgoInfantilDO.md) | Clasificación de riesgo del cáncer infantil. |
| [HER2](ValueSet-VSHER2DO.md) | Resultado cualitativo de HER2. |
| [Identificadores de Paciente](ValueSet-VSTipoIdentifPacDO.md) | Conjunto de valores para los Identificadores de Paciente. |
| [Identificadores de Profesional](ValueSet-VSTipoIdentifProfDO.md) | Conjunto de valores para los Identificadores de Profesional. |
| [Lateralidad](ValueSet-VSLateralidadDO.md) | Lateralidad del sitio del cáncer primario. |
| [Medicamentos DO](ValueSet-medicamentos-do-vs.md) | ValueSet para medicamentos. Debe sustituirse o complementarse con catálogo nacional de medicamentos. |
| [Morfología CIE-O-3](ValueSet-VSCIEO3MorfologiaDO.md) | Códigos de morfología CIE-O-3 (tipo histológico y comportamiento, p. ej. 8500/3). |
| [Receptor de estrógeno](ValueSet-VSReceptorEstrogenoDO.md) | Resultado cualitativo del receptor de estrógeno. |
| [Receptor de progesterona](ValueSet-VSReceptorProgesteronaDO.md) | Resultado cualitativo del receptor de progesterona. |
| [Resultados estructurados de patología](ValueSet-VSCodigoResultadoPatologiaDO.md) | Resultados de patología que no caben en DiagnosticReport.conclusionCode. |
| [Tipos de informe de laboratorio](ValueSet-DiagnosticReportCodeVS.md) | Conjunto de valores para los tipos de informe de laboratorio. |
| [Topografía CIE-O-3](ValueSet-VSCIEO3TopografiaDO.md) | Códigos de topografía CIE-O-3 (Cxx.x) para el sitio del cáncer primario. |

### Terminology: Code Systems 

These define new code systems used by systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [Categorías de condiciones de notificación](CodeSystem-CSCategoriaNotificacionDO.md) | Categorías locales propuestas; no constituyen un catálogo nacional aprobado. |
| [Especialidades Profesionales DO](CodeSystem-CSEspecialidadDO.md) | Catálogo inicial de especialidades profesionales para Practitioner. |
| [Observaciones oncológicas](CodeSystem-CSObservacionesOncoDO.md) | Códigos locales para el nombre de las observaciones oncológicas y sus componentes. |
| [Resultados oncológicos](CodeSystem-CSResultadosOncoDO.md) | Códigos locales para valores cualitativos de patología, estadificación y riesgo. |
| [Secciones de notificación epidemiológica](CodeSystem-CSSeccionesNotificacionDO.md) | Códigos locales propuestos para organizar la notificación individual. |
| [Secciones del documento oncológico](CodeSystem-CSSeccionesOncoDO.md) | Códigos locales para las secciones del documento oncológico que no tienen un código LOINC acordado. |
| [Tipo de Identificación DO](CodeSystem-CSTipoIdentificacionDO.md) | Tipos de documentos de identificación usados en República Dominicana o por la implementación nacional. |

### Example: Example Instances 

These are example instances that show what data produced and consumed by systems conforming with this implementation guide might look like.

| | |
| :--- | :--- |
| [Bundle de laboratorio de ejemplo](Bundle-BundleLabDOExample.md) | Documento sintetico con Composition como primera entrada, paciente, organizacion, informe y metadatos del PDF. Las URLs example.org son ilustrativas. |
| [Bundle de notificación de caso de dengue](Bundle-BundleNotifDOExample.md) | Bundle documental sintético que reúne todos los recursos del caso de dengue notificado. |
| [Bundle oncológico de ejemplo](Bundle-BundleOncoDOExample.md) | Documento sintético del caso con Composition como primera entrada y todo el contenido clínico anclado al cáncer primario. Las URLs example.org son ilustrativas. |
| [Caso epidemiológico de dengue](Condition-ConditionCasoEpidemiologicoDOExample.md) | Ejemplo sintético de un caso de dengue para notificación epidemiológica. |
| [Cirugía oncológica de ejemplo](Procedure-SurgicalProcedureDOExample.md) | Mastectomía parcial izquierda. Caso sintético. |
| [Conclusión epidemiológica de dengue](Condition-ConditionConclusionDOExample.md) | Ejemplo sintético de conclusión epidemiológica para el caso de dengue. |
| [Cáncer primario de ejemplo](Condition-PrimaryCancerConditionDOExample.md) | Carcinoma ductal infiltrante de la mama izquierda, cuadrante superior externo. Caso sintético. |
| [Documento de laboratorio de ejemplo](Composition-CompositionDOLabExample.md) | Documento sintetico con las secciones de informe de laboratorio y PDF. |
| [Documento oncológico de ejemplo](Composition-CompositionDOOncoExample.md) | Documento del caso con las secciones de diagnóstico, patología, estadificación y tratamientos. Caso sintético. |
| [Ejemplo de AllergyIntoleranceDO](AllergyIntolerance-AllergyIntoleranceDOExample.md) | Ejemplo de alergia o intolerancia para el perfil AllergyIntoleranceDO. |
| [Ejemplo de Bundle transaccional DO](Bundle-BundleTransaccDOExample.md) | Ejemplo de envío transaccional MHD con paciente, documento, submission set y documento clínico. |
| [Ejemplo de BundleNPSDO](Bundle-BundleNPSDOExample.md) | Ejemplo de documento clínico IPS DO empaquetado. |
| [Ejemplo de CompositionDO](Composition-CompositionDOExample.md) | Ejemplo de composición clínica para el documento IPS DO. |
| [Ejemplo de ConditionDO](Condition-ConditionDOEjemplo.md) | Ejemplo para una condición clínica del paciente. |
| [Ejemplo de DocumentReferenceDO](DocumentReference-DocumentReferenceDOExample.md) | Ejemplo de referencia al documento clínico del paciente. |
| [Ejemplo de ListDO](List-ListDOExample.md) | Ejemplo de conjunto de documentos enviados para un paciente. |
| [Ejemplo de MedicationStatementDO](MedicationStatement-MedicationStatementDOEjemplo.md) | Ejemplo de historial farmacológico del paciente. |
| [Ejemplo de OrganizationDO](Organization-OrganizationDOExample.md) | Ejemplo de organización sanitaria para el perfil OrganizationDO. |
| [Ejemplo de PatientDO](Patient-PatientDOExample.md) | Ejemplo de paciente DO con identificador, nombre, género y datos de contacto. |
| [Ejemplo de PractitionerDO](Practitioner-PractitionerDOExample.md) | Ejemplo de profesional de salud para el perfil PractitionerDO. |
| [Estadio de ejemplo](Observation-CancerStageDOExample.md) | Estadio II del cáncer primario de ejemplo. Caso sintético. |
| [Estado de embarazo en caso de dengue](Observation-ObservationEstadoEmbarazoDOExample.md) | Ejemplo sintético de estado de embarazo documentado durante la evaluación del caso de dengue. |
| [Informe de laboratorio de ejemplo](DiagnosticReport-DiagnosticReportDOExample.md) | Informe sintetico final con referencia al PDF representado por BinaryDOLabExample. |
| [Informe de patología de ejemplo](DiagnosticReport-PathologyReportDOExample.md) | Biopsia de mama con grado histológico y marcadores RE, RP y HER2. Caso sintético. |
| [Metadatos del PDF de laboratorio](Binary-BinaryDOLabExample.md) | Ejemplo sintetico de Binary para un PDF. Se omite data; para intercambiar un PDF real debe incorporarse su contenido en base64. |
| [Notificación individual de caso de dengue](Composition-CompositionDONotifExample.md) | Documento sintético de notificación epidemiológica de un caso confirmado de dengue en una paciente embarazada. |
| [Referencia de notificación de dengue](DocumentReference-DocumentReferenceDONotifExample.md) | Metadatos del documento FHIR de notificación individual del caso sintético de dengue. |
| [Referencia documental de laboratorio de ejemplo](DocumentReference-DocumentReferenceDOLabExample.md) | Indice del documento sintetico BundleLabDOExample. La URL example.org es ilustrativa. |
| [Signo y síntoma en caso de dengue](Observation-ObservationSignoSintomaDOExample.md) | Ejemplo sintético de fiebre y cefalea asociados a un caso de dengue. |
| [Tratamiento farmacológico de ejemplo](MedicationStatement-CancerMedicationStatementDOExample.md) | Hormonoterapia con tamoxifeno. Caso sintético. |
| [Variante genómica de ejemplo](Observation-PathologyResultDOExample.md) | Variante PIK3CA detectada en el tumor. Caso sintético. |
| [Viaje y exposición en caso de dengue](Observation-ObservationViajesExposicionDOExample.md) | Ejemplo sintético de antecedente de viaje y exposición relevante para un caso de dengue. |

