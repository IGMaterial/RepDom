# Home - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:https://digital.msp.gob.do/fhir/conectaton/ImplementationGuide/msp.fhir.do | *Version*:0.2.2 |
| Draft as of 2026-11-17 | *Computable Name*:fhir-ig-do |

# Guía de Implementación FHIR — Conectatón República Dominicana 2026

La presente **Guía de Implementación FHIR** establece las especificaciones técnicas que utilizarán los equipos participantes en la **Primera Conectatón Nacional de Interoperabilidad en Salud de la República Dominicana 2026**.

Su propósito es proporcionar una base común para la preparación, implementación y validación de los intercambios de información que serán probados durante la Conectatón, utilizando **HL7® FHIR® R4** y los perfiles, terminologías, reglas de validación y mecanismos de intercambio definidos para cada escenario.

La guía está dirigida principalmente a los equipos técnicos de las instituciones participantes y a sus proveedores o responsables de sistemas de información.

A través de sus diferentes secciones se especifica **qué información deberá ser capaz de generar o consumir cada sistema, cómo deberá representarse utilizando FHIR y cuáles serán las condiciones que deberán cumplirse para completar satisfactoriamente las pruebas**.

-------

## Objetivo de la guía

La Conectatón busca comprobar que sistemas desarrollados y operados por organizaciones diferentes puedan **intercambiar información utilizando una interpretación común de los estándares**.

Por esta razón, esta guía funciona como el **contrato técnico común de la Conectatón**.

Los participantes podrán utilizar sus propios sistemas, arquitecturas, lenguajes de programación, servidores FHIR y herramientas de integración. La Conectatón no evalúa la tecnología utilizada internamente por cada institución, sino la capacidad de sus soluciones para:

* generar información conforme a las especificaciones definidas;
* intercambiarla utilizando los mecanismos establecidos;
* recibir información proveniente de otros participantes;
* interpretar correctamente la información recibida; y
* completar los escenarios de interoperabilidad definidos para el ejercicio.

-------

## Alcance

Esta versión de la guía contiene los artefactos comunes y las especificaciones necesarias para implementar y probar los escenarios definidos para la Conectatón 2026.

Incluye:

* perfiles FHIR comunes utilizados por los diferentes tracks;
* reglas para la representación de pacientes, profesionales, organizaciones y otros actores;
* perfiles para información clínica y documentos;
* identificadores y extensiones requeridas;
* terminologías y conjuntos de valores;
* mecanismos de intercambio de información;
* ejemplos de recursos e interacciones;
* reglas y herramientas de validación;
* requerimientos aplicables al entorno de pruebas; y
* especificaciones particulares de cada track de la Conectatón.

> **Importante:** Los requerimientos establecidos en esta guía corresponden al entorno de prueba de la Conectatón. Su cumplimiento durante el ejercicio no implica, por sí mismo, autorización para utilizar estos mismos mecanismos o configuraciones en ambientes productivos.

—## Tracks de la Conectatón

La Conectatón 2026 se organiza en tres tracks de interoperabilidad.

### Track 1 — Intercambio de documentos clínicos

Este track evalúa la capacidad de los sistemas participantes para generar, publicar, consultar, recuperar y consumir información clínica mediante documentos estructurados e intercambios basados en estándares FHIR.

El escenario utiliza como referencia el **International Patient Summary (IPS)** y los mecanismos definidos para el intercambio de documentos clínicos.

### Track 2 — Registro Nacional de Cáncer (RENAC)

Este track evalúa el intercambio de información relacionada con casos oncológicos hacia el Registro Nacional de Cáncer, de acuerdo con los perfiles y reglas definidos por el MISPAS.

### Track 3 — Vigilancia epidemiológica

Este track evalúa la capacidad de los sistemas de los prestadores para generar y transmitir información estructurada relacionada con eventos de interés epidemiológico hacia los sistemas nacionales de vigilancia.

## Cada track contiene sus propios escenarios, actores, requisitos, perfiles, operaciones y criterios de validación.

## Especificaciones comunes

Los diferentes tracks reutilizan un conjunto de artefactos comunes definidos en esta guía.

Estos componentes permiten que conceptos fundamentales sean representados de la misma forma independientemente del escenario en que sean utilizados.

### Base

Incluye los perfiles utilizados para representar elementos comunes como:

* pacientes;
* profesionales de salud;
* organizaciones;
* establecimientos de salud; y
* otros actores requeridos por los intercambios.

### Información clínica

Contiene los perfiles necesarios para representar información clínica estructurada utilizada por los diferentes escenarios.

### Documentos

Define los artefactos requeridos para representar documentos clínicos y su contenido utilizando FHIR.

### MHD

Incluye las especificaciones utilizadas para la publicación, consulta y recuperación de documentos cuando el escenario requiera mecanismos basados en **Mobile access to Health Documents (MHD)**.

### Terminologías

Contiene los `CodeSystem`, `ValueSet` y demás artefactos semánticos utilizados por los perfiles de esta guía.

-------

## ¿Qué deberá poder hacer un equipo participante?

Dependiendo del track y del rol asumido dentro del escenario, un equipo podrá actuar como **productor, consumidor o ambos**.

Durante la preparación y ejecución de la Conectatón, deberá demostrar las capacidades que correspondan a su escenario, incluyendo:

1. representar información utilizando los perfiles FHIR definidos;
1. generar recursos e instancias válidas;
1. utilizar correctamente identificadores y terminologías;
1. ejecutar las operaciones e interacciones requeridas;
1. publicar o transmitir información cuando corresponda;
1. consultar o recuperar información desde otros sistemas;
1. procesar la información recibida;
1. identificar y manejar respuestas de error; y
1. completar el flujo de interoperabilidad definido para la prueba.

No todos los equipos deberán implementar todas las operaciones. Los requerimientos específicos dependerán del **track, escenario y rol asignado**.

-------

## Principio de capacidad demostrable

La Conectatón está basada en el principio de **capacidad demostrable**.

Esto significa que el cumplimiento de una prueba no se determinará únicamente por la existencia de una API, un servidor FHIR o un recurso sintácticamente válido.

El objetivo es demostrar que sistemas independientes pueden ejecutar correctamente un **flujo de interoperabilidad de extremo a extremo (End-to-End)**.

De manera general, una prueba podrá involucrar la siguiente secuencia:

**Sistema origen → Representación FHIR → Intercambio → Sistema receptor → Validación → Uso de la información**

Las pruebas parciales serán útiles durante la preparación y el Pre-Conectatón para identificar errores y avanzar progresivamente. Sin embargo, la validación del escenario se realizará conforme a los criterios definidos para cada track.

-------

## Cómo utilizar esta guía

Antes de iniciar la implementación, cada equipo deberá identificar:

* el track o los tracks en los que participará;
* el escenario que deberá ejecutar; y
* el rol que asumirá dentro del intercambio.

A partir de esta definición, se recomienda seguir la siguiente secuencia:

1. revisar la descripción funcional del escenario;
1. identificar los actores y roles involucrados;
1. identificar los perfiles FHIR requeridos;
1. revisar las cardinalidades y restricciones de cada perfil;
1. implementar los identificadores y terminologías correspondientes;
1. revisar los ejemplos publicados;
1. configurar las operaciones o mecanismos de intercambio;
1. generar o consumir los recursos requeridos;
1. validar las instancias contra esta guía;
1. ejecutar las pruebas preparatorias; y
1. completar durante la Conectatón las pruebas definidas con otros participantes.

-------

## Validación

Los recursos utilizados durante las pruebas deberán cumplir con los perfiles correspondientes de esta Guía de Implementación.

Cuando aplique, las instancias deberán declarar explícitamente el perfil que implementan mediante:

## Validación

Los recursos intercambiados durante la Conectatón deberán cumplir con los perfiles correspondientes definidos por esta Guía de Implementación.

Cuando corresponda, las instancias deberán declarar explícitamente el perfil que implementan mediante `meta.profile`.

Ejemplo:

```
{
  "resourceType": "Patient",
  "meta": {
    "profile": [
      "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/PatientDO"
    ]
  }
}

```

La validación podrá considerar diferentes niveles.

### Validación sintáctica

Verifica que el recurso pueda ser interpretado correctamente como una instancia FHIR válida.

### Validación estructural

Comprueba:

* cardinalidades;
* tipos de datos;
* restricciones;
* referencias;
* elementos obligatorios; y
* conformidad con el perfil declarado.

### Validación semántica

Comprueba:

* `CodeSystem`;
* `ValueSet`;
* códigos;
* `bindings`;
* identificadores; y
* terminologías requeridas.

### Validación funcional

Comprueba que el sistema sea capaz de utilizar correctamente el recurso dentro del escenario de interoperabilidad.

> Un recurso técnicamente válido **no implica necesariamente que la prueba haya sido completada satisfactoriamente**.

La evaluación final dependerá de la ejecución del escenario completo y de los criterios definidos para cada prueba.

-------

## Datos de Prueba

La Conectatón se realizará utilizando **datos de prueba** preparados específicamente para los escenarios definidos.

No deberán utilizarse datos reales de pacientes.

Los participantes trabajarán con:

* pacientes ficticios;
* identificadores de prueba;
* profesionales ficticios cuando corresponda;
* organizaciones y establecimientos definidos para las pruebas;
* información clínica simulada;
* registros de vacunación de prueba;
* eventos epidemiológicos simulados; y
* documentos clínicos preparados para los escenarios.

Los datasets serán utilizados de manera consistente entre los participantes para facilitar la reproducción y validación de los resultados.

-------

## Entornos de Ejecución

Las pruebas serán realizadas en ambientes controlados.

Cada participante podrá utilizar:

* ambientes de prueba de sus sistemas institucionales;
* servidores FHIR propios;
* servidores FHIR habilitados para el ejercicio;
* middleware;
* adaptadores;
* motores de integración;
* herramientas de transformación; o
* componentes desarrollados específicamente para la Conectatón.

La arquitectura interna de cada participante no será evaluada.

Lo relevante será su capacidad para cumplir las interfaces, perfiles y reglas definidas por esta guía.

-------

## Qué No Define esta Guía

Esta guía no pretende definir:

* la arquitectura interna de los sistemas participantes;
* un producto tecnológico obligatorio;
* un proveedor específico;
* un lenguaje de programación;
* una plataforma FHIR determinada;
* un HIS, EHR, LIS u otro sistema específico;
* los requisitos completos para ambientes productivos;
* todos los futuros casos de uso de interoperabilidad en salud del país; ni
* las políticas institucionales internas de cada participante.

La conformidad durante la Conectatón se evalúa sobre los **artefactos, interfaces, operaciones y capacidades requeridas por los escenarios de prueba**.

-------

## Público Objetivo

Esta guía está dirigida principalmente a:

* desarrolladores de sistemas de información en salud;
* integradores;
* arquitectos de soluciones;
* especialistas en interoperabilidad;
* equipos responsables de APIs e integración;
* proveedores de HIS, EHR y LIS;
* equipos técnicos de prestadores de servicios de salud;
* equipos técnicos del Ministerio de Salud Pública y Asistencia Social;
* equipos técnicos de los sistemas nacionales involucrados;
* especialistas responsables de terminologías;
* monitores técnicos de la Conectatón; y
* demás actores responsables de implementar o validar los escenarios de prueba.

-------

## Estructura de la Guía

La documentación se organiza en diferentes bloques según su función dentro de la Conectatón.

### Base

Contiene los perfiles fundamentales reutilizados por los diferentes escenarios:

* Paciente.
* Profesional.
* Organización.

### Información Clínica

Contiene perfiles relacionados con información clínica requerida por los tracks.

### Documentos

Contiene perfiles utilizados para construir documentos clínicos:

* `Composition`;
* `DocumentReference`;
* `Bundle` documental.

### MHD

Contiene artefactos relacionados con el intercambio de documentos:

* `List`;
* `DocumentReference`;
* `Bundle` transaccional; y
* operaciones requeridas por los escenarios MHD.

### Terminologías

Contiene:

* `CodeSystem`;
* `ValueSet`;
* identificadores;
* catálogos; y
* reglas de codificación.

### Conectatón 2026

Contiene la documentación específica del ejercicio:

* tracks;
* escenarios;
* detalles de las pruebas;
* flujo de intercambio;
* seguridad;
* validación;
* datos de prueba; y
* comunicación y soporte.

### Artefactos

Incluye las páginas generadas por el Implementation Guide:

* perfiles;
* extensiones;
* terminologías;
* ejemplos;
* artefactos computables; y
* descargas.

-------

## Dependencias Técnicas

Esta Guía de Implementación utiliza las siguientes especificaciones y herramientas:

| | |
| :--- | :--- |
| HL7® FHIR® R4 | Estándar base para representación e intercambio de información |
| International Patient Summary (IPS) | Referencia para escenarios de resumen clínico |
| IHE MHD | Intercambio de documentos cuando corresponda |
| Terminologías clínicas | Codificación estandarizada de conceptos |
| FHIR Shorthand / SUSHI | Definición de perfiles y artefactos |
| HL7 IG Publisher | Generación y publicación de la Guía de Implementación |

Las dependencias adicionales requeridas por un track deberán declararse en su sección correspondiente.

-------

## Estado de la Guía

Esta es una **versión de trabajo** de la Guía de Implementación utilizada para la preparación de la **Primera Conectatón Nacional de Interoperabilidad en Salud de la República Dominicana 2026**.

Durante el período previo al evento podrán publicarse nuevas versiones con el propósito de:

* corregir errores;
* aclarar requerimientos;
* incorporar ajustes derivados de las pruebas;
* actualizar perfiles;
* actualizar terminologías;
* incorporar nuevos ejemplos;
* mejorar los criterios de validación; o
* resolver hallazgos identificados durante las actividades preparatorias y el Pre-Conectatón.

Cada publicación deberá estar identificada mediante un número de versión y su correspondiente historial de cambios.

Los participantes deberán verificar que están utilizando la **versión vigente de la guía** antes de ejecutar las pruebas oficiales.

-------

## Convenciones

Los perfiles y artefactos definidos específicamente para la República Dominicana utilizan, cuando corresponde, el sufijo:

`DO`

Por ejemplo:

* `PatientDO`
* `PractitionerDO`
* `OrganizationDO`
* `ConditionDO`
* `CompositionDO`

La URL canónica de los artefactos deberá corresponder con las URLs publicadas en esta Guía de Implementación.

Los implementadores **no deberán construir manualmente las URLs canónicas** de los `StructureDefinition`, `CodeSystem`, `ValueSet` u otros artefactos. Deberán utilizar las URLs declaradas en cada recurso publicado por la guía.

-------

## Consideración Final

Esta Guía de Implementación debe entenderse como la **especificación técnica de referencia para la Conectatón República Dominicana 2026**.

Su objetivo no es definir cómo deben construirse internamente los sistemas de información de salud, sino establecer un lenguaje, un conjunto de perfiles y reglas comunes que permitan comprobar que sistemas independientes pueden **intercambiar, interpretar y utilizar información de manera interoperable**.

El resultado esperado de la Conectatón no es únicamente demostrar que dos sistemas pueden establecer una conexión técnica o intercambiar un recurso FHIR válido.

El objetivo es demostrar, mediante escenarios reproducibles y verificables, que distintos actores pueden implementar consistentemente las especificaciones definidas y completar **flujos de interoperabilidad de extremo a extremo**.



## Resource Content

```json
{
  "resourceType" : "ImplementationGuide",
  "id" : "msp.fhir.do",
  "language" : "es",
  "url" : "https://digital.msp.gob.do/fhir/conectaton/ImplementationGuide/msp.fhir.do",
  "version" : "0.2.2",
  "name" : "fhir-ig-do",
  "title" : "Guía FHIR DO - Conectaton Nacional República Dominicana",
  "status" : "draft",
  "date" : "2026-11-17T15:46:26-03:00",
  "publisher" : "Ministerio de Salud Pública y Asistencia Social",
  "contact" : [{
    "name" : "Ministerio de Salud Pública y Asistencia Social",
    "telecom" : [{
      "system" : "url",
      "value" : "https://msp.gob.do"
    }]
  }],
  "description" : "Guía Conectaton Nacional de República Dominicana para recursos, extensiones, terminologías y patrones comunes de interoperabilidad FHIR.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DO",
      "display" : "Dominican Republic"
    }]
  }],
  "packageId" : "msp.fhir.do",
  "license" : "CC-BY-4.0",
  "fhirVersion" : ["4.0.1"],
  "dependsOn" : [{
    "id" : "hl7tx",
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
      "valueMarkdown" : "Automatically added as a dependency - all IGs depend on HL7 Terminology"
    }],
    "uri" : "http://terminology.hl7.org/ImplementationGuide/hl7.terminology",
    "packageId" : "hl7.terminology.r4",
    "version" : "7.5.0"
  },
  {
    "id" : "hl7ext",
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
      "valueMarkdown" : "Automatically added as a dependency - all IGs depend on the HL7 Extension Pack"
    }],
    "uri" : "http://hl7.org/fhir/extensions/ImplementationGuide/hl7.fhir.uv.extensions",
    "packageId" : "hl7.fhir.uv.extensions.r4",
    "version" : "5.4.0"
  },
  {
    "id" : "hl7_fhir_uv_ips",
    "uri" : "http://hl7.org/fhir/uv/ips/ImplementationGuide/hl7.fhir.uv.ips",
    "packageId" : "hl7.fhir.uv.ips",
    "version" : "2.0.0-ballot"
  },
  {
    "id" : "ihe_iti_mhd",
    "uri" : "https://profiles.ihe.net/ITI/MHD/ImplementationGuide/ihe.iti.mhd",
    "packageId" : "ihe.iti.mhd",
    "version" : "4.2.2"
  }],
  "definition" : {
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-internal-dependency",
      "valueCode" : "hl7.fhir.uv.tools.r4#1.3.0"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "copyrightyear"
      },
      {
        "url" : "value",
        "valueString" : "2026"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "releaselabel"
      },
      {
        "url" : "value",
        "valueString" : "ci-build"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "show-inherited-invariants"
      },
      {
        "url" : "value",
        "valueString" : "false"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-contact"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "excludettl"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "excludexml"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "excludemap"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "autoload-resources"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "template/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "input/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-qa"
      },
      {
        "url" : "value",
        "valueString" : "temp/qa"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-temp"
      },
      {
        "url" : "value",
        "valueString" : "temp/pages"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-output"
      },
      {
        "url" : "value",
        "valueString" : "output"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-suppressed-warnings"
      },
      {
        "url" : "value",
        "valueString" : "input/ignoreWarnings.txt"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-history"
      },
      {
        "url" : "value",
        "valueString" : "https://digital.msp.gob.do/fhir/conectaton/history.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "template-html"
      },
      {
        "url" : "value",
        "valueString" : "template-page.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "template-md"
      },
      {
        "url" : "value",
        "valueString" : "template-page-md.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-context"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-copyright"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-jurisdiction"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-license"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-publisher"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-version"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-wg"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "active-tables"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "fmm-definition"
      },
      {
        "url" : "value",
        "valueString" : "http://hl7.org/fhir/versions.html#maturity"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "propagate-status"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "excludelogbinaryformat"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "tabbed-snapshots"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    }],
    "resource" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-AllergyIntoleranceDO.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/AllergyIntoleranceDO"
      },
      "name" : "Alergia o Intolerancia DO",
      "description" : "Perfil para alergias, intolerancias y reacciones adversas.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-BinaryDO.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/BinaryDO"
      },
      "name" : "Binario DO",
      "description" : "Perfil para recursos binarios.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-BundleLabDOExample.html"
      }],
      "reference" : {
        "reference" : "Bundle/BundleLabDOExample"
      },
      "name" : "Bundle de laboratorio de ejemplo",
      "description" : "Documento sintetico con Composition como primera entrada, paciente, organizacion, informe y metadatos del PDF. Las URLs example.org son ilustrativas.",
      "exampleCanonical" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/BundleLabDO"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-BundleNotifDOExample.html"
      }],
      "reference" : {
        "reference" : "Bundle/BundleNotifDOExample"
      },
      "name" : "Bundle de notificación de caso de dengue",
      "description" : "Bundle documental sintético que reúne todos los recursos del caso de dengue notificado.",
      "exampleCanonical" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/BundleNotifDO"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-BundleNotifDO.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/BundleNotifDO"
      },
      "name" : "Bundle de notificación epidemiológica DO",
      "description" : "Documento de notificación individual con la Composition como primera entrada y los recursos referenciados incluidos.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-BundleOncoDO.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/BundleOncoDO"
      },
      "name" : "Bundle Documento Oncológico",
      "description" : "Documento del caso para el Registro Nacional de Cáncer. Hereda de BundleDocDO las entradas composition, patient (PatientDO) y organization (OrganizationDO).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-BundleOncoDOExample.html"
      }],
      "reference" : {
        "reference" : "Bundle/BundleOncoDOExample"
      },
      "name" : "Bundle oncológico de ejemplo",
      "description" : "Documento sintético del caso con Composition como primera entrada y todo el contenido clínico anclado al cáncer primario. Las URLs example.org son ilustrativas.",
      "exampleCanonical" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/BundleOncoDO"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-BundleDocDO.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/BundleDocDO"
      },
      "name" : "BundleDocDO",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-BundleLabDO.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/BundleLabDO"
      },
      "name" : "BundleLabDO",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-BundleNPSDO.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/BundleNPSDO"
      },
      "name" : "BundleNPSDO",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-BundleTransaccDO.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/BundleTransaccDO"
      },
      "name" : "BundleTransaccDO",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-ConditionCasoEpidemiologicoDOExample.html"
      }],
      "reference" : {
        "reference" : "Condition/ConditionCasoEpidemiologicoDOExample"
      },
      "name" : "Caso epidemiológico de dengue",
      "description" : "Ejemplo sintético de un caso de dengue para notificación epidemiológica.",
      "exampleCanonical" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/ConditionCasoEpidemiologicoDO"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ConditionCasoEpidemiologicoDO.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ConditionCasoEpidemiologicoDO"
      },
      "name" : "Caso epidemiológico DO",
      "description" : "Evento o enfermedad principal que motiva la notificación individual.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-CSCategoriaNotificacionDO.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/CSCategoriaNotificacionDO"
      },
      "name" : "Categorías de condiciones de notificación",
      "description" : "Categorías locales propuestas; no constituyen un catálogo nacional aprobado.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-SurgicalProcedureDOExample.html"
      }],
      "reference" : {
        "reference" : "Procedure/SurgicalProcedureDOExample"
      },
      "name" : "Cirugía oncológica de ejemplo",
      "description" : "Mastectomía parcial izquierda. Caso sintético.",
      "exampleCanonical" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/SurgicalProcedureDO"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-SurgicalProcedureDO.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/SurgicalProcedureDO"
      },
      "name" : "Cirugía Oncológica DO",
      "description" : "Procedimiento quirúrgico de tratamiento del cáncer primario.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-ConditionConclusionDOExample.html"
      }],
      "reference" : {
        "reference" : "Condition/ConditionConclusionDOExample"
      },
      "name" : "Conclusión epidemiológica de dengue",
      "description" : "Ejemplo sintético de conclusión epidemiológica para el caso de dengue.",
      "exampleCanonical" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/ConditionConclusionDO"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ConditionConclusionDO.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ConditionConclusionDO"
      },
      "name" : "Conclusión epidemiológica DO",
      "description" : "Conclusión del caso; la clasificación final se registra en code y el estado de confirmación en verificationStatus.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ConditionDO.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ConditionDO"
      },
      "name" : "Condición DO",
      "description" : "Perfil  para problemas, diagnósticos y condiciones clínicas.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-RadiotherapyCourseDO.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/RadiotherapyCourseDO"
      },
      "name" : "Curso de Radioterapia DO",
      "description" : "Curso de radioterapia del cáncer primario, con su fecha de inicio y de término.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-PrimaryCancerConditionDOExample.html"
      }],
      "reference" : {
        "reference" : "Condition/PrimaryCancerConditionDOExample"
      },
      "name" : "Cáncer primario de ejemplo",
      "description" : "Carcinoma ductal infiltrante de la mama izquierda, cuadrante superior externo. Caso sintético.",
      "exampleCanonical" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/PrimaryCancerConditionDO"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-PrimaryCancerConditionDO.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/PrimaryCancerConditionDO"
      },
      "name" : "Cáncer Primario DO",
      "description" : "Cáncer primario del caso registrado. Es el ancla del documento oncológico: patología, estadificación y tratamientos lo referencian.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DiagnosticReportDO.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DiagnosticReportDO"
      },
      "name" : "DiagnosticReportDO",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VSCIE10DO.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VSCIE10DO"
      },
      "name" : "Diagnósticos CIE-10",
      "description" : "Códigos de diagnóstico CIE-10 para el cáncer primario.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-CompositionDO.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/CompositionDO"
      },
      "name" : "Documento Clínico DO",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-CompositionDONPS.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/CompositionDONPS"
      },
      "name" : "Documento Clínico IPS DO",
      "description" : "Perfil para documentos clínicos FHIR.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-CompositionDOLab.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/CompositionDOLab"
      },
      "name" : "Documento Clínico Laboratorio",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-CompositionDONotif.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/CompositionDONotif"
      },
      "name" : "Documento Clínico Notificación de Caso",
      "description" : "Notificación individual organizada alrededor de un caso epidemiológico.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-CompositionDOOnco.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/CompositionDOOnco"
      },
      "name" : "Documento Clínico Oncologico",
      "description" : "Documento del caso para el Registro Nacional de Cáncer. Todo el contenido clínico se ancla al cáncer primario (PrimaryCancerConditionDO).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Composition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Composition-CompositionDOLabExample.html"
      }],
      "reference" : {
        "reference" : "Composition/CompositionDOLabExample"
      },
      "name" : "Documento de laboratorio de ejemplo",
      "description" : "Documento sintetico con las secciones de informe de laboratorio y PDF.",
      "exampleCanonical" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/CompositionDOLab"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Composition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Composition-CompositionDOOncoExample.html"
      }],
      "reference" : {
        "reference" : "Composition/CompositionDOOncoExample"
      },
      "name" : "Documento oncológico de ejemplo",
      "description" : "Documento del caso con las secciones de diagnóstico, patología, estadificación y tratamientos. Caso sintético.",
      "exampleCanonical" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/CompositionDOOnco"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DocumentReferenceDO.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DocumentReferenceDO"
      },
      "name" : "DocumentReferenceDO",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DocumentReferenceDOLab.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DocumentReferenceDOLab"
      },
      "name" : "DocumentReferenceDOLab",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DocumentReferenceDONotif.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DocumentReferenceDONotif"
      },
      "name" : "DocumentReferenceDONotif",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DocumentReferenceDONPS.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DocumentReferenceDONPS"
      },
      "name" : "DocumentReferenceDONPS",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DocumentReferenceDOOnco.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DocumentReferenceDOOnco"
      },
      "name" : "DocumentReferenceDOOnco",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "AllergyIntolerance"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "AllergyIntolerance-AllergyIntoleranceDOExample.html"
      }],
      "reference" : {
        "reference" : "AllergyIntolerance/AllergyIntoleranceDOExample"
      },
      "name" : "Ejemplo de AllergyIntoleranceDO",
      "description" : "Ejemplo de alergia o intolerancia para el perfil AllergyIntoleranceDO.",
      "exampleCanonical" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/AllergyIntoleranceDO"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-BundleTransaccDOExample.html"
      }],
      "reference" : {
        "reference" : "Bundle/BundleTransaccDOExample"
      },
      "name" : "Ejemplo de Bundle transaccional DO",
      "description" : "Ejemplo de envío transaccional MHD con paciente, documento, submission set y documento clínico.",
      "exampleCanonical" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/BundleTransaccDO"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-BundleNPSDOExample.html"
      }],
      "reference" : {
        "reference" : "Bundle/BundleNPSDOExample"
      },
      "name" : "Ejemplo de BundleNPSDO",
      "description" : "Ejemplo de documento clínico IPS DO empaquetado.",
      "exampleCanonical" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/BundleNPSDO"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Composition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Composition-CompositionDOExample.html"
      }],
      "reference" : {
        "reference" : "Composition/CompositionDOExample"
      },
      "name" : "Ejemplo de CompositionDO",
      "description" : "Ejemplo de composición clínica para el documento IPS DO.",
      "exampleCanonical" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/CompositionDO"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-ConditionDOEjemplo.html"
      }],
      "reference" : {
        "reference" : "Condition/ConditionDOEjemplo"
      },
      "name" : "Ejemplo de ConditionDO",
      "description" : "Ejemplo para una condición clínica del paciente.",
      "exampleCanonical" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/ConditionDO"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DocumentReference"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DocumentReference-DocumentReferenceDOExample.html"
      }],
      "reference" : {
        "reference" : "DocumentReference/DocumentReferenceDOExample"
      },
      "name" : "Ejemplo de DocumentReferenceDO",
      "description" : "Ejemplo de referencia al documento clínico del paciente.",
      "exampleCanonical" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/DocumentReferenceDO"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "List"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "List-ListDOExample.html"
      }],
      "reference" : {
        "reference" : "List/ListDOExample"
      },
      "name" : "Ejemplo de ListDO",
      "description" : "Ejemplo de conjunto de documentos enviados para un paciente.",
      "exampleCanonical" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/ListDO"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationStatement-MedicationStatementDOEjemplo.html"
      }],
      "reference" : {
        "reference" : "MedicationStatement/MedicationStatementDOEjemplo"
      },
      "name" : "Ejemplo de MedicationStatementDO",
      "description" : "Ejemplo de historial farmacológico del paciente.",
      "exampleCanonical" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/MedicationStatementDO"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Organization-OrganizationDOExample.html"
      }],
      "reference" : {
        "reference" : "Organization/OrganizationDOExample"
      },
      "name" : "Ejemplo de OrganizationDO",
      "description" : "Ejemplo de organización sanitaria para el perfil OrganizationDO.",
      "exampleCanonical" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/OrganizationDO"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-PatientDOExample.html"
      }],
      "reference" : {
        "reference" : "Patient/PatientDOExample"
      },
      "name" : "Ejemplo de PatientDO",
      "description" : "Ejemplo de paciente DO con identificador, nombre, género y datos de contacto.",
      "exampleCanonical" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/PatientDO"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Practitioner"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Practitioner-PractitionerDOExample.html"
      }],
      "reference" : {
        "reference" : "Practitioner/PractitionerDOExample"
      },
      "name" : "Ejemplo de PractitionerDO",
      "description" : "Ejemplo de profesional de salud para el perfil PractitionerDO.",
      "exampleCanonical" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/PractitionerDO"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VSEspecialidadDO.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VSEspecialidadDO"
      },
      "name" : "Especialidades Profesionales DO",
      "description" : "Conjunto de valores para las Especialidades Profesionales DO.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-CSEspecialidadDO.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/CSEspecialidadDO"
      },
      "name" : "Especialidades Profesionales DO",
      "description" : "Catálogo inicial de especialidades profesionales para Practitioner.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-CancerStageDOExample.html"
      }],
      "reference" : {
        "reference" : "Observation/CancerStageDOExample"
      },
      "name" : "Estadio de ejemplo",
      "description" : "Estadio II del cáncer primario de ejemplo. Caso sintético.",
      "exampleCanonical" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/CancerStageDO"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-CancerStageDO.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/CancerStageDO"
      },
      "name" : "Estadio del Cáncer DO",
      "description" : "Grupo de estadio del cáncer primario.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ObservationEstadoEmbarazoDO.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ObservationEstadoEmbarazoDO"
      },
      "name" : "Estado de embarazo DO",
      "description" : "Estado de embarazo en la fecha de evaluación.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-ObservationEstadoEmbarazoDOExample.html"
      }],
      "reference" : {
        "reference" : "Observation/ObservationEstadoEmbarazoDOExample"
      },
      "name" : "Estado de embarazo en caso de dengue",
      "description" : "Ejemplo sintético de estado de embarazo documentado durante la evaluación del caso de dengue.",
      "exampleCanonical" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/ObservationEstadoEmbarazoDO"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VSGradoHistologicoDO.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VSGradoHistologicoDO"
      },
      "name" : "Grado histológico",
      "description" : "Grado histológico del tumor.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VSEstadioDO.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VSEstadioDO"
      },
      "name" : "Grupo de estadio",
      "description" : "Grupo de estadio del cáncer primario.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VSRiesgoInfantilDO.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VSRiesgoInfantilDO"
      },
      "name" : "Grupo de riesgo infantil",
      "description" : "Clasificación de riesgo del cáncer infantil.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VSHER2DO.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VSHER2DO"
      },
      "name" : "HER2",
      "description" : "Resultado cualitativo de HER2.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-MedicationStatementDO.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/MedicationStatementDO"
      },
      "name" : "Historial Farmacológico DO",
      "description" : "Perfil para medicamentos declarados o en uso por el paciente.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VSTipoIdentifPacDO.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VSTipoIdentifPacDO"
      },
      "name" : "Identificadores de Paciente",
      "description" : "Conjunto de valores para los Identificadores de Paciente.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VSTipoIdentifProfDO.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VSTipoIdentifProfDO"
      },
      "name" : "Identificadores de Profesional",
      "description" : "Conjunto de valores para los Identificadores de Profesional.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DiagnosticReport"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DiagnosticReport-DiagnosticReportDOExample.html"
      }],
      "reference" : {
        "reference" : "DiagnosticReport/DiagnosticReportDOExample"
      },
      "name" : "Informe de laboratorio de ejemplo",
      "description" : "Informe sintetico final con referencia al PDF representado por BinaryDOLabExample.",
      "exampleCanonical" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/DiagnosticReportDO"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DiagnosticReport"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DiagnosticReport-PathologyReportDOExample.html"
      }],
      "reference" : {
        "reference" : "DiagnosticReport/PathologyReportDOExample"
      },
      "name" : "Informe de patología de ejemplo",
      "description" : "Biopsia de mama con grado histológico y marcadores RE, RP y HER2. Caso sintético.",
      "exampleCanonical" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/PathologyReportDO"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-PathologyReportDO.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/PathologyReportDO"
      },
      "name" : "Informe de Patología DO",
      "description" : "Informe de anatomía patológica del cáncer primario. Reúne la biopsia, el grado histológico y los marcadores cualitativos (RE, RP, HER2). Breslow y variantes genómicas van en PathologyResultDO. Deriva de DiagnosticReport y no de DiagnosticReportDO, porque ese perfil exige presentedForm 1..1.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VSLateralidadDO.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VSLateralidadDO"
      },
      "name" : "Lateralidad",
      "description" : "Lateralidad del sitio del cáncer primario.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-LateralidadDO.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/LateralidadDO"
      },
      "name" : "Lateralidad DO",
      "description" : "Lateralidad del sitio del cáncer primario.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ListDO.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ListDO"
      },
      "name" : "ListDO",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-medicamentos-do-vs.html"
      }],
      "reference" : {
        "reference" : "ValueSet/medicamentos-do-vs"
      },
      "name" : "Medicamentos DO",
      "description" : "ValueSet para medicamentos. Debe sustituirse o complementarse con catálogo nacional de medicamentos.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Binary-BinaryDOLabExample.html"
      }],
      "reference" : {
        "reference" : "Binary/BinaryDOLabExample"
      },
      "name" : "Metadatos del PDF de laboratorio",
      "description" : "Ejemplo sintetico de Binary para un PDF. Se omite data; para intercambiar un PDF real debe incorporarse su contenido en base64.",
      "exampleCanonical" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/BinaryDO"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VSCIEO3MorfologiaDO.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VSCIEO3MorfologiaDO"
      },
      "name" : "Morfología CIE-O-3",
      "description" : "Códigos de morfología CIE-O-3 (tipo histológico y comportamiento, p. ej. 8500/3).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-HistologyMorphologyBehaviorDO.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/HistologyMorphologyBehaviorDO"
      },
      "name" : "Morfología y comportamiento histológico DO",
      "description" : "Morfología del cáncer primario en CIE-O-3 (tipo histológico y comportamiento, p. ej. 8500/3). Misma forma que la extensión mcode-histology-morphology-behavior de mCODE, por lo que se mapea 1:1.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Composition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Composition-CompositionDONotifExample.html"
      }],
      "reference" : {
        "reference" : "Composition/CompositionDONotifExample"
      },
      "name" : "Notificación individual de caso de dengue",
      "description" : "Documento sintético de notificación epidemiológica de un caso confirmado de dengue en una paciente embarazada.",
      "exampleCanonical" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/CompositionDONotif"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-CSObservacionesOncoDO.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/CSObservacionesOncoDO"
      },
      "name" : "Observaciones oncológicas",
      "description" : "Códigos locales para el nombre de las observaciones oncológicas y sus componentes.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-OrganizationDO.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/OrganizationDO"
      },
      "name" : "Organización DO",
      "description" : "Perfil para establecimientos, instituciones y unidades organizacionales de salud.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-PatientDO.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/PatientDO"
      },
      "name" : "Paciente DO",
      "description" : "Perfil para representar pacientes.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-PractitionerDO.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/PractitionerDO"
      },
      "name" : "Profesional DO",
      "description" : "Perfil para profesionales de salud.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VSReceptorEstrogenoDO.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VSReceptorEstrogenoDO"
      },
      "name" : "Receptor de estrógeno",
      "description" : "Resultado cualitativo del receptor de estrógeno.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VSReceptorProgesteronaDO.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VSReceptorProgesteronaDO"
      },
      "name" : "Receptor de progesterona",
      "description" : "Resultado cualitativo del receptor de progesterona.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DocumentReference"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DocumentReference-DocumentReferenceDONotifExample.html"
      }],
      "reference" : {
        "reference" : "DocumentReference/DocumentReferenceDONotifExample"
      },
      "name" : "Referencia de notificación de dengue",
      "description" : "Metadatos del documento FHIR de notificación individual del caso sintético de dengue.",
      "exampleCanonical" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/DocumentReferenceDONotif"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DocumentReference"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DocumentReference-DocumentReferenceDOLabExample.html"
      }],
      "reference" : {
        "reference" : "DocumentReference/DocumentReferenceDOLabExample"
      },
      "name" : "Referencia documental de laboratorio de ejemplo",
      "description" : "Indice del documento sintetico BundleLabDOExample. La URL example.org es ilustrativa.",
      "exampleCanonical" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/DocumentReferenceDOLab"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-PathologyResultDO.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/PathologyResultDO"
      },
      "name" : "Resultado de Patología DO",
      "description" : "Resultado estructurado de patología que no cabe en DiagnosticReport.conclusionCode: profundidad de Breslow (mm) o variante genómica. Lo referencia PathologyReportDO.result.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VSCodigoResultadoPatologiaDO.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VSCodigoResultadoPatologiaDO"
      },
      "name" : "Resultados estructurados de patología",
      "description" : "Resultados de patología que no caben en DiagnosticReport.conclusionCode.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-CSResultadosOncoDO.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/CSResultadosOncoDO"
      },
      "name" : "Resultados oncológicos",
      "description" : "Códigos locales para valores cualitativos de patología, estadificación y riesgo.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-CSSeccionesNotificacionDO.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/CSSeccionesNotificacionDO"
      },
      "name" : "Secciones de notificación epidemiológica",
      "description" : "Códigos locales propuestos para organizar la notificación individual.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-CSSeccionesOncoDO.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/CSSeccionesOncoDO"
      },
      "name" : "Secciones del documento oncológico",
      "description" : "Códigos locales para las secciones del documento oncológico que no tienen un código LOINC acordado.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-SegundoApellidoDO.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/SegundoApellidoDO"
      },
      "name" : "Segundo Apellido DO",
      "description" : "Extensión para representar el segundo apellido cuando se requiere conservarlo separado de HumanName.family.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ObservationSignoSintomaDO.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ObservationSignoSintomaDO"
      },
      "name" : "Signo o síntoma DO",
      "description" : "Hallazgo clínico del caso epidemiológico.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-ObservationSignoSintomaDOExample.html"
      }],
      "reference" : {
        "reference" : "Observation/ObservationSignoSintomaDOExample"
      },
      "name" : "Signo y síntoma en caso de dengue",
      "description" : "Ejemplo sintético de fiebre y cefalea asociados a un caso de dengue.",
      "exampleCanonical" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/ObservationSignoSintomaDO"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-CSTipoIdentificacionDO.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/CSTipoIdentificacionDO"
      },
      "name" : "Tipo de Identificación DO",
      "description" : "Tipos de documentos de identificación usados en República Dominicana o por la implementación nacional.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-DiagnosticReportCodeVS.html"
      }],
      "reference" : {
        "reference" : "ValueSet/DiagnosticReportCodeVS"
      },
      "name" : "Tipos de informe de laboratorio",
      "description" : "Conjunto de valores para los tipos de informe de laboratorio.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VSCIEO3TopografiaDO.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VSCIEO3TopografiaDO"
      },
      "name" : "Topografía CIE-O-3",
      "description" : "Códigos de topografía CIE-O-3 (Cxx.x) para el sitio del cáncer primario.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationStatement-CancerMedicationStatementDOExample.html"
      }],
      "reference" : {
        "reference" : "MedicationStatement/CancerMedicationStatementDOExample"
      },
      "name" : "Tratamiento farmacológico de ejemplo",
      "description" : "Hormonoterapia con tamoxifeno. Caso sintético.",
      "exampleCanonical" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/CancerMedicationStatementDO"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-CancerMedicationStatementDO.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/CancerMedicationStatementDO"
      },
      "name" : "Tratamiento Farmacológico Oncológico DO",
      "description" : "Tratamiento sistémico del cáncer primario (quimioterapia, hormonoterapia, inmunoterapia, terapia dirigida).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-PathologyResultDOExample.html"
      }],
      "reference" : {
        "reference" : "Observation/PathologyResultDOExample"
      },
      "name" : "Variante genómica de ejemplo",
      "description" : "Variante PIK3CA detectada en el tumor. Caso sintético.",
      "exampleCanonical" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/PathologyResultDO"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-ObservationViajesExposicionDOExample.html"
      }],
      "reference" : {
        "reference" : "Observation/ObservationViajesExposicionDOExample"
      },
      "name" : "Viaje y exposición en caso de dengue",
      "description" : "Ejemplo sintético de antecedente de viaje y exposición relevante para un caso de dengue.",
      "exampleCanonical" : "https://digital.msp.gob.do/fhir/conectaton/StructureDefinition/ObservationViajesExposicionDO"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ObservationViajesExposicionDO.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ObservationViajesExposicionDO"
      },
      "name" : "Viajes y exposición DO",
      "description" : "Antecedente de viaje o exposición relevante para el caso epidemiológico.",
      "exampleBoolean" : false
    }],
    "page" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
        "valueUrl" : "toc.html"
      }],
      "nameUrl" : "toc.html",
      "title" : "Table of Contents",
      "generation" : "html",
      "page" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "index.html"
        }],
        "nameUrl" : "index.html",
        "title" : "Home",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "conectaton.html"
        }],
        "nameUrl" : "conectaton.html",
        "title" : "Conectaton",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "descargas.html"
        }],
        "nameUrl" : "descargas.html",
        "title" : "Descargas",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "notificacionepidemiologica.html"
        }],
        "nameUrl" : "notificacionepidemiologica.html",
        "title" : "Notificacionepidemiologica",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "reportelaboratorio.html"
        }],
        "nameUrl" : "reportelaboratorio.html",
        "title" : "Reportelaboratorio",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "resumenoncologico.html"
        }],
        "nameUrl" : "resumenoncologico.html",
        "title" : "Resumenoncologico",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "resumenpaciente.html"
        }],
        "nameUrl" : "resumenpaciente.html",
        "title" : "Resumenpaciente",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "terminologias.html"
        }],
        "nameUrl" : "terminologias.html",
        "title" : "Terminologias",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "validacion.html"
        }],
        "nameUrl" : "validacion.html",
        "title" : "Validacion",
        "generation" : "markdown"
      }]
    },
    "parameter" : [{
      "code" : "path-resource",
      "value" : "input/capabilities"
    },
    {
      "code" : "path-resource",
      "value" : "input/examples"
    },
    {
      "code" : "path-resource",
      "value" : "input/extensions"
    },
    {
      "code" : "path-resource",
      "value" : "input/models"
    },
    {
      "code" : "path-resource",
      "value" : "input/operations"
    },
    {
      "code" : "path-resource",
      "value" : "input/profiles"
    },
    {
      "code" : "path-resource",
      "value" : "input/resources"
    },
    {
      "code" : "path-resource",
      "value" : "input/vocabulary"
    },
    {
      "code" : "path-resource",
      "value" : "input/maps"
    },
    {
      "code" : "path-resource",
      "value" : "input/testing"
    },
    {
      "code" : "path-resource",
      "value" : "input/history"
    },
    {
      "code" : "path-resource",
      "value" : "fsh-generated/resources"
    },
    {
      "code" : "path-pages",
      "value" : "template/config"
    },
    {
      "code" : "path-pages",
      "value" : "input/images"
    },
    {
      "code" : "path-tx-cache",
      "value" : "input-cache/txcache"
    }]
  }
}

```
