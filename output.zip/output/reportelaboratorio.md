# Reportelaboratorio - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* **Reportelaboratorio**

## Reportelaboratorio

### Introducción

En esta página, se documenta todos los recursos involucrados para representar la reporte de laboratorio.

-------

### Perfiles

En esta sección se describen los perfiles especpificos:

1️⃣ Perfil de **Document Reference Laboratorio** para representar el indice de documento de Laboratorio. [DocumentReference Laboratorio](StructureDefinition-DocumentReferenceDOLab.md).

2️⃣ Perfil de **Bundle Document Laboratorio** para representar la información de notificación epidemiológica. [Bundle Document Laboratorio](StructureDefinition-BundleLabDO.md).

3️⃣ Perfil de **Composition** Documento de Laborarotio: [Composition Laboratorio](StructureDefinition-CompositionDOLab.md).

4️⃣ Perfil de **DiagnosticReport** Diagnostic Report: [DiagnosticReportDO](StructureDefinition-DiagnosticReportDO.md).

-------

### Detalle de Secciones:

En este apartado se describen las diferentes secciones incluidas en el documento **Compostion** para poder representar tanto de antecedendentes del paciente, asi como detalles de la atención:

1️⃣ Seccion que contiene todos los antecedentes de salud del paciente:

| | | |
| :--- | :--- | :--- |
| ✅**Reporte de Laboratorio** | [DiagnosticReportDO](StructureDefinition-DiagnosticReportDO.md). | Estructura que representa el reporte de laboratorio |
| ✅**Documento PDF** | [Documento PDF](StructureDefinition-BinaryDO.md). | Representa el documento PDF del resultado de Laboratorio para poder visualizarlo |

### Representación gráfica de la notificación

Diagrama de recursos involucrados:

