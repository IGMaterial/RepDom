# Resumenoncologico - Guía FHIR DO - Conectaton Nacional República Dominicana v0.2.2

* [**Table of Contents**](toc.md)
* **Resumenoncologico**

## Resumenoncologico

### Introducción

Esta página describe los perfiles FHIR utilizados para representar el resumen oncológico del paciente y notificar un caso al Registro Nacional de Cáncer.

-------

### Perfiles del documento

| | |
| :--- | :--- |
| [DocumentReference Resumen Oncológico](StructureDefinition-DocumentReferenceDOOnco.md) | Índice del documento oncológico. |
| [Bundle Documento Oncológico](StructureDefinition-BundleOncoDO.md) | Agrupa la composición y los recursos clínicos del caso. |
| [Composition Documento Oncológico](StructureDefinition-CompositionDOOnco.md) | Organiza la información clínica en secciones de diagnóstico, patología, estadificación y tratamientos. |

### Perfiles clínicos oncológicos

| | |
| :--- | :--- |
| [Cáncer Primario](StructureDefinition-PrimaryCancerConditionDO.md) | Diagnóstico del cáncer primario, con su código CIE-10, topografía CIE-O-3 y fecha de diagnóstico. Es la referencia central para los demás datos oncológicos. |
| [Informe de Patología](StructureDefinition-PathologyReportDO.md) | Informe anatomopatológico, con grado histológico y marcadores como receptores de estrógeno, receptores de progesterona y HER2. |
| [Resultado de Patología](StructureDefinition-PathologyResultDO.md) | Resultado estructurado de patología, por ejemplo, profundidad de Breslow o variante genómica. |
| [Estadio del Cáncer](StructureDefinition-CancerStageDO.md) | Estadio del cáncer primario, con fecha y sistema de estadificación. |
| [Cirugía Oncológica](StructureDefinition-SurgicalProcedureDO.md) | Procedimiento quirúrgico realizado para tratar el cáncer primario. |
| [Curso de Radioterapia](StructureDefinition-RadiotherapyCourseDO.md) | Curso de radioterapia, con período de tratamiento y sitio irradiado. |
| [Tratamiento Farmacológico Oncológico](StructureDefinition-CancerMedicationStatementDO.md) | Tratamiento sistémico del cáncer, como quimioterapia, hormonoterapia, inmunoterapia o terapia dirigida. |
| [Tutor del Paciente](StructureDefinition-RelatedPersonTutorDO.md) | Tutor o responsable legal; se utiliza para casos de cáncer infantil. |

-------

### Detalle de secciones

Todas las secciones requieren código, título y narrativa. La cardinalidad de la sección indica cuántas veces puede aparecer en la `Composition`; la cardinalidad de las entradas se aplica cuando la sección está presente.

| | | | |
| :--- | :--- | :--- | :--- |
| **Diagnóstico**(`Diagnostico`) | `1..1` | `1..1` | [Cáncer Primario](StructureDefinition-PrimaryCancerConditionDO.md) |
| **Patología**(`Patologia`) | `0..1` | `1..*` | [Informe de Patología](StructureDefinition-PathologyReportDO.md) |
| **Estadificación y riesgo**(`Estadificacion`) | `0..1` | `1..*` | [Estadio del Cáncer](StructureDefinition-CancerStageDO.md) |
| **Tratamientos**(`Tratamientos`) | `0..1` | `1..*` | [Cirugía Oncológica](StructureDefinition-SurgicalProcedureDO.md)o[Curso de Radioterapia](StructureDefinition-RadiotherapyCourseDO.md)o[Tratamiento Farmacológico Oncológico](StructureDefinition-CancerMedicationStatementDO.md) |

La sección **Documento PDF** está prevista en el diseño, pero actualmente no está activa en `CompositionDOOnco`; por tanto, no forma parte de las secciones obligatorias ni opcionales de este perfil.

El [Bundle Documento Oncológico](StructureDefinition-BundleOncoDO.md) agrupa estos recursos y puede incluir un tutor del paciente en casos de cáncer infantil.

### Representación gráfica de la notificación

Diagrama de recursos involucrados:

